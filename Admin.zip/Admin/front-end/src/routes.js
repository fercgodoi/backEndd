import React from "react";
import { BrowserRouter, Route, Switch} from "react-router-dom";

import AlterarSenha from "./pages/AlterarSenha";
import CadastroConcluido from "./pages/CadastroConcluido";
import CadastroShopping from "./pages/CadastroShopping";
import CadastroFuncionario from "./pages/CadastroFuncionario";
import Calendario from "./pages/Calendario";
import DetalhesPet from "./pages/DetalhesPet";
import EditarPerfil from "./pages/EditarPerfil";
import EsqueciSenha from "./pages/EsqueciSenha";
import Funcionarios from "./pages/Funcionario";
import Home from "./pages/Home";
import Horarios from "./pages/Horarios";
import Shopping from "./pages/Shopping";
import Login from "./pages/Login";
import Codigo from "./pages/Codigo";
import Prontuarios from "./pages/Prontuarios";
import Medicacao from "./pages/Medicação";
import Vacina from "./pages/Vacina";
import CadastroVacina from "./pages/CadastroVacina";
import CadastroMedicacao from "./pages/CadastroMedicacao";
import VisualizarVacina from "./pages/VisualizarVacina";
import VisualizarMedicacao from "./pages/VisualizarMedicacao";
import VisualizarProntuario from "./pages/VisualizarProntuario";
import EditarFuncionario from "./pages/EditarFuncionario";
import EditarProduto from "./pages/EditarProduto";
import CadastroProntuario from "./pages/CadastroProntuario";
import CadastroPrimeiro from "./pages/CadastroPrimeiro";
import CadastroSegundo from "./pages/CadastroSegundo";
import CadastroTerceiro from "./pages/CadastroTerceiro";
import CadastroQuatro from "./pages/CadastroQuatro";
import CadastroCinco from "./pages/CadastroCinco";

const Routes = () => (
    <BrowserRouter>
      <Switch>

          <Route exact path="/VisualizarProntuario"  component={VisualizarProntuario} />

          <Route exact path="/CadastroPrimeiro"  component={CadastroPrimeiro} />

          <Route exact path="/CadastroSegundo"  component={CadastroSegundo} />

          <Route exact path="/CadastroQuatro"  component={CadastroQuatro} />

          <Route exact path="/CadastroCinco"  component={CadastroCinco} />

          <Route exact path="/CadastroTerceiro"  component={CadastroTerceiro} />

          <Route exact path="/CadastroProntuario"  component={CadastroProntuario} />

          <Route exact path="/EditarFuncionario"  component={EditarFuncionario} />

          <Route exact path="/EditarProduto"  component={EditarProduto} /> 

          <Route exact path="/VisualizarVacina"  component={VisualizarVacina} />

          <Route exact path="/VisualizarMedicacao"  component={VisualizarMedicacao} /> 
           
          <Route exact path="/CadastroVacina"  component={CadastroVacina} />

          <Route exact path="/CadastroMedicacao"  component={CadastroMedicacao} />        
          
          <Route exact path="/Vacina"  component={Vacina} />

          <Route exact path="/Prontuarios"  component={Prontuarios} />

          <Route exact path="/Medicacao"  component={Medicacao} />

          <Route exact path="/Codigo"  component={Codigo} />

          <Route exact path="/AlterarSenha"  component={AlterarSenha} />

          <Route exact path="/CadastroConcluido"  component={CadastroConcluido} />

          <Route exact path="/CadastroFuncionario"  component={CadastroFuncionario} />
  
          <Route exact path="/CadastroShopping"  component={CadastroShopping} />
  
          <Route exact path="/Calendario"  component={Calendario} />
  
          <Route exact path="/DetalhesPet"  component={DetalhesPet} />
  
          <Route exact path="/EditarPerfil"  component={EditarPerfil} />
  
          <Route exact path="/EsqueciSenha"  component={EsqueciSenha} />
  
          <Route exact path="/Funcionarios"  component={Funcionarios} />
  
          <Route exact path="/DetalhesPet"  component={DetalhesPet} />
  
          <Route exact path="/Home"  component={Home} />
  
          <Route exact path="/Horarios"  component={Horarios} />
  
          <Route exact path="/Funcionarios"  component={Funcionarios} />
          
          <Route exact path="/Shopping"  component={Shopping} />
  
          <Route exact path="/"  component={Login} />
  
      </Switch>
    </BrowserRouter>
  );
  
  export default Routes;