import React from 'react';
import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";

import api from '../services/api.js';

export default function VisualizarProntuario(){

    async function Aparecer(){

        var erro = document.getElementById("valida");
        var id= localStorage.getItem('Codigo');

        if(id === "" || id === null || id=== undefined){
            erro.innerText = "Tente Novamente";
        }
        else{

            let response="";
            try {
                response = await api.post('/Prontuario/BuscarInfo', {idConst:id});
            } catch (error) {
                console.log(error);               
            }  

            console.log(response)

            if(response.data.response){
                var produto = response.data.response.Prontuario;
                var nomePrest= document.getElementById("nomePrest");
                var nomeFunc= document.getElementById("nomeFunc");
                var rgPet= document.getElementById("rgPet");
                var nomePet= document.getElementById("nomePet");
                var nomeVacina= document.getElementById("nomeVacina");
                var qntDoseVacina= document.getElementById("qntDoseVacina");
                var loteVacina= document.getElementById("loteVacina");
                var observacaoVacina= document.getElementById("observacaoVacina");
                var nomeVetVacina= document.getElementById("nomeVetVacina");
                var emailVetVacina= document.getElementById("emailVetVacina");
                var crmvVetVacina= document.getElementById("crmvVetVacina");
                var dataConst= document.getElementById("dataConst");
                var dataProxVacina= document.getElementById("dataProxVacina");
                var dataApliVacina= document.getElementById("dataApliVacina");
                var nomeMed= document.getElementById("nomeMed");
                var doseMed= document.getElementById("doseMed");
                var loteMed= document.getElementById("loteMed");
                var observacaoMed= document.getElementById("observacaoMed");
                var rotinaMed= document.getElementById("rotinaMed");
                var nomeEstbMed= document.getElementById("nomeEstbMed");
                var emailEstbMed= document.getElementById("emailEstbMed");
                var dataIniMed= document.getElementById("dataIniMed");
                var dataFinMed= document.getElementById("dataFinMed");


                var Medicacao = document.getElementById("Medicacao");
                var Vacina = document.getElementById("Vacina");
                var Exame = document.getElementById("Exame");

                var dateInicio= "";
                var dateCorreto= "";
                var dateInicioApliMed= "";
                var dateCorretoApliMed =   "";             
                var dateInicioProxMed= "";
                var dateCorretoProxMed = "";
                var dateInicioProxVac= "";
                var dateCorretoProxVac ="";
                var dateInicioApliVac= "";
                var dateCorretoApliVac = "";

                if(produto[0].idVacina !== "Não" && produto[0].idMed === "Não"){
                    
                    nomePrest.value = produto[0].nomePrest;                    
                    nomeFunc.value = produto[0].nomeFunc;                    
                    rgPet.value = produto[0].rgPet;                    
                    nomePet.value = produto[0].nomePet;                   
                    nomeVacina.value = produto[0].nomeVacina;                    
                    qntDoseVacina.value = produto[0].qntDoseVacina;                    
                    loteVacina.value = produto[0].loteVacina;                    
                    observacaoVacina.value = produto[0].observacaoVacina;                    
                    nomeVetVacina.value = produto[0].nomeVetVacina;                    
                    emailVetVacina.value = produto[0].emailVetVacina;                    
                    crmvVetVacina.value = produto[0].crmvVetVacina;

                   
                    dateInicio= produto[0].dataConst.split('', 10);
                    dateCorreto = dateInicio[0] + dateInicio[1] + dateInicio[2] + dateInicio[3] + dateInicio[4] + dateInicio[5] + dateInicio[6] + dateInicio[7] + dateInicio[8] + dateInicio[9];
                    dataConst.value = dateCorreto;
                    
                    dateInicioProxVac= produto[0].dataProxVacina.split('', 10);
                    dateCorretoProxVac = dateInicioProxVac[0] + dateInicioProxVac[1] + dateInicioProxVac[2] + dateInicioProxVac[3] + dateInicioProxVac[4] + dateInicioProxVac[5] + dateInicioProxVac[6] + dateInicioProxVac[7] + dateInicioProxVac[8] + dateInicioProxVac[9];
                    dataProxVacina.value = dateCorretoProxVac;
                    
                    dateInicioApliVac= produto[0].dataApliVacina.split('', 10);
                    dateCorretoApliVac = dateInicioApliVac[0] + dateInicioApliVac[1] + dateInicioApliVac[2] + dateInicioApliVac[3] + dateInicioApliVac[4] + dateInicioApliVac[5] + dateInicioApliVac[6] + dateInicioApliVac[7] + dateInicioApliVac[8] + dateInicioApliVac[9];
                    dataApliVacina.value = dateCorretoApliVac;

                
                    Medicacao.style.display="none";
                    Vacina.style.display="block";
                    Exame.style.display="none";

                }
                else if(produto[0].idVacina === "Não" && produto[0].idMed !== "Não"){     
                    nomePrest.value = produto[0].nomePrest;
                    nomeFunc.value = produto[0].nomeFunc;
                    rgPet.value = produto[0].rgPet;
                    nomePet.value = produto[0].nomePet;
                    nomeMed.value = produto[0].nomeMed;
                    doseMed.value = produto[0].doseMed;
                    loteMed.value = produto[0].loteMed;
                    observacaoMed.value = produto[0].observacaoMed;
                    rotinaMed.value = produto[0].rotinaMed;
                    nomeEstbMed.value = produto[0].nomeEstbMed;

                    
                    dateInicio= produto[0].dataConst.split('', 10);
                    dateCorreto = dateInicio[0] + dateInicio[1] + dateInicio[2] + dateInicio[3] + dateInicio[4] + dateInicio[5] + dateInicio[6] + dateInicio[7] + dateInicio[8] + dateInicio[9];
                    dataConst.value = dateCorreto;
                   
                    
                    dateInicioApliMed= produto[0].dataIniMed.split('', 10);
                    dateCorretoApliMed = dateInicioApliMed[0] + dateInicioApliMed[1] + dateInicioApliMed[2] + dateInicioApliMed[3] + dateInicioApliMed[4] + dateInicioApliMed[5] + dateInicioApliMed[6] + dateInicioApliMed[7] + dateInicioApliMed[8] + dateInicioApliMed[9];
                    dataIniMed.value = dateCorretoApliMed;

                    
                    dateInicioProxMed= produto[0].dataFinMed.split('', 10);
                    dateCorretoProxMed = dateInicioProxMed[0] + dateInicioProxMed[1] + dateInicioProxMed[2] + dateInicioProxMed[3] + dateInicioProxMed[4] + dateInicioProxMed[5] + dateInicioProxMed[6] + dateInicioProxMed[7] + dateInicioProxMed[8] + dateInicioProxMed[9];
                    dataFinMed.value = dateCorretoProxMed;
                   
                    
                    Medicacao.style.display="block";
                    Vacina.style.display="none";
                    Exame.style.display="none";

                }
                else if(produto[0].idVacina !== "Não" && produto[0].idMed !== "Não"){   
                    nomePrest.value = produto[0].nomePrest;
                    nomeFunc.value = produto[0].nomeFunc;
                    rgPet.value = produto[0].rgPet;
                    nomePet.value = produto[0].nomePet;
                    nomeMed.value = produto[0].nomeMed;
                    doseMed.value = produto[0].doseMed;
                    loteMed.value = produto[0].loteMed;
                    observacaoMed.value = produto[0].observacaoMed;
                    rotinaMed.value = produto[0].rotinaMed;
                    nomeEstbMed.value = produto[0].nomeEstbMed;
                    emailEstbMed.value = produto[0].emailEstbMed; 
                    nomeVacina.value = produto[0].nomeVacina;
                    qntDoseVacina.value = produto[0].qntDoseVacina;
                    loteVacina.value = produto[0].loteVacina;
                    observacaoVacina.value = produto[0].observacaoVacina;
                    nomeVetVacina.value = produto[0].nomeVetVacina;
                    emailVetVacina.value = produto[0].emailVetVacina;
                    crmvVetVacina.value = produto[0].crmvVetVacina;

                    
                    dateInicio= produto[0].dataConst.split('', 10);
                    dateCorreto = dateInicio[0] + dateInicio[1] + dateInicio[2] + dateInicio[3] + dateInicio[4] + dateInicio[5] + dateInicio[6] + dateInicio[7] + dateInicio[8] + dateInicio[9];
                    dataConst.value = dateCorreto;

                    dateInicioProxVac= produto[0].dataProxVacina.split('', 10);
                    dateCorretoProxVac = dateInicioProxVac[0] + dateInicioProxVac[1] + dateInicioProxVac[2] + dateInicioProxVac[3] + dateInicioProxVac[4] + dateInicioProxVac[5] + dateInicioProxVac[6] + dateInicioProxVac[7] + dateInicioProxVac[8] + dateInicioProxVac[9];
                    dataProxVacina.value = dateCorretoProxVac;

                   
                    dateInicioApliVac= produto[0].dataApliVacina.split('', 10);
                    dateCorretoApliVac = dateInicioApliVac[0] + dateInicioApliVac[1] + dateInicioApliVac[2] + dateInicioApliVac[3] + dateInicioApliVac[4] + dateInicioApliVac[5] + dateInicioApliVac[6] + dateInicioApliVac[7] + dateInicioApliVac[8] + dateInicioApliVac[9];
                    dataApliVacina.value = dateCorretoApliVac;

                
                    dateInicioApliMed= produto[0].dataIniMed.split('', 10);
                    dateCorretoApliMed = dateInicioApliMed[0] + dateInicioApliMed[1] + dateInicioApliMed[2] + dateInicioApliMed[3] + dateInicioApliMed[4] + dateInicioApliMed[5] + dateInicioApliMed[6] + dateInicioApliMed[7] + dateInicioApliMed[8] + dateInicioApliMed[9];
                    dataIniMed.value = dateCorretoApliMed;

                  
                    dateInicioProxMed= produto[0].dataFinMed.split('', 10);
                    dateCorretoProxMed = dateInicioProxMed[0] + dateInicioProxMed[1] + dateInicioProxMed[2] + dateInicioProxMed[3] + dateInicioProxMed[4] + dateInicioProxMed[5] + dateInicioProxMed[6] + dateInicioProxMed[7] + dateInicioProxMed[8] + dateInicioProxMed[9];
                    dataFinMed.value = dateCorretoProxMed;
                   
            
                    Medicacao.style.display="block";
                    Vacina.style.display="block";
                    Exame.style.display="none";
                           
                }
                else{   
                    nomePrest.value = produto[0].nomePrest;
                    nomeFunc.value = produto[0].nomeFunc;

               
                    dateInicio= produto[0].dataConst.split('', 10);
                    dateCorreto = dateInicio[0] + dateInicio[1] + dateInicio[2] + dateInicio[3] + dateInicio[4] + dateInicio[5] + dateInicio[6] + dateInicio[7] + dateInicio[8] + dateInicio[9];
                    dataConst.value = dateCorreto;

                    rgPet.value = produto[0].rgPet;
                    nomePet.value = produto[0].nomePet;

                    Medicacao.style.display="none";
                    Vacina.style.display="none";
                    Exame.style.display="none";
                }
            
            }else{
                erro.value = "Tente Novamente";
            }

            if(response.data.error){
                if(response.data.error === "error"){
                    erro.value = "Tente Novamente";
                }else{
                    erro.value = "Tente Novamente";
                }
            }

            if(response.data.message){
                if(response.data.message === "Prontuario com vacina nao encontrado"){
                    erro.value = "Tente Novamente";
                }else{
                    if(response.data.message === "Prontuario com medicacao nao encontrado"){
                        erro.value = "Tente Novamente";
                    }else{
                        if(response.data.message === "Prontuario ambos nao encontrado"){
                            erro.value = "Tente Novamente";                
                        }
                        else{
                            if(response.data.message === "Prontuario nao encontrado"){
                                erro.value = "Tente Novamente";                
                            }
                            else{
                                erro.value = "Tente Novamente"; 
                            }
                        }
                    }
                    
                }
            }
        }

    }

    setTimeout(() => {Aparecer()}, 1000);
    return(
        
        <div>
        <div class="wrapper ">
            <div class="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                <div class="logo">
                    <a  class="simple-text logo-normal">
                        <img src={rodape} class="ImagemLogo" align="left" alt="" />            
                    </a>
                    <a  class="simple-text logo-normal">
                        <p class="NomePrest">Cantos dos Bichos</p>
                        <p class="TipoPrest">PetShop</p>
                    </a>
                </div>
                <div class="sidebar-wrapper">
                    <ul class="nav">
                        <li class="nav-item active  ">
                            <a class="nav-link" href="./dashboard.html">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./user.html">
                            <i class="material-icons">event</i>
                            <p>Calendário</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./tables.html">
                            <i class="material-icons">assignment_ind</i>
                            <p>Funcionários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./typography.html">
                            <i class="material-icons">shopping_cart</i>
                            <p>Shopping</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./icons.html">
                            <i class="material-icons">alarm</i>
                            <p>Horários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./map.html">
                            <i class="material-icons">account_circle</i>
                            <p>Editar Perfil</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./notifications.html">
                            <i class="material-icons">assignment</i>
                            <p>Prontuários</p>
                            </a>
                        </li>
                        <li class="nav-item active-pro ">
                            <a class="nav-link" style={{background:'none'}}>
                                <table>
                                    <tr>
                                        <td style={{width: '20%'}}>
                                            <img src={rodape2} class="material-icons" alt="" />
                                        </td>
                                        <td style={{width: '80%'}}>
                                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                                        </td>
                                    </tr>
                                </table>            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>    
            <div class="main-panel">
                <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                    <div class="container-fluid">
                        <div class="navbar-wrapper">
                            <a class="navbar-brand" href="#pablo" style={{fontSize:'21px'}}>Visualizar Prontuários</a>
                        </div>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-end">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">notifications</i>
                                        <span class="notification">5</span>
                                        <p class="d-lg-none d-md-block">
                                            Some Actions
                                        </p>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item" href="#">Mike John responded to your email</a>
                                        <a class="dropdown-item" href="#">You have 5 new tasks</a>
                                        <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                                        <a class="dropdown-item" href="#">Another Notification</a>
                                        <a class="dropdown-item" href="#">Another One</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#pablo">
                                        <i class="material-icons">help_outline</i>
                                        <p class="d-lg-none d-md-block">
                                            Stats
                                        </p>
                                    </a>
                                </li>                                
                                <li class="nav-item dropdown">
                                    <a >
                                        <img src={rodape} class="iconLogo" align="right" alt="" />      
                                    </a>                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header card-header-blue">
                                        <h4 class="card-title">Prontuários</h4>
                                    </div>
                                    <div class="card-body">
                                            <div class="col-md-12">
                                                <p style={{color:'red',fontWeight:'200',marginBottom:'0px',textAlign: 'center'}} id="valida"></p>                                                 
                                            </div>
                                            <div class="row">
                                            <div class="col-md-3">
                                                    <div class="form-group">
                                                    <label style={{color:'#009fe3'}}>Nome do Animal</label>
                                                        <input type="text" class="form-control" id="nomePet" placeholder="Nome do Animal"/>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                    <label style={{color:'#009fe3'}}>RG do Animal</label>
                                                        <input type="text" class="form-control" id="rgPet" placeholder="RG do Animal"/>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form-group">
                                                        <label style={{color:'#009fe3',visibility:'hidden'}}>RG do Animal</label>
                                                        <input type="text" className="form-control" placeholder="Data"  disabled/>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form-group">
                                                    <label style={{color:'#009fe3',visibility:'hidden'}}>RG do Animal</label>
                                                        <input type="date" className="form-control" id="dataConst" disabled/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                    <label style={{color:'#009fe3'}}>Clinica Veterinaria</label>
                                                        <input type="text" class="form-control" id="nomePrest" placeholder="Clinica Veterinaria"/>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                    <label style={{color:'#009fe3'}}>Veterinario Responsavel</label>
                                                        <input type="text" class="form-control" id="nomeFunc" placeholder="Veterinario Responsavel"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/>
                                            <div id="Medicacao" style={{display:"none"}}>                                                
                                                <div class="row">                                                    
                                                    <div class="col-md-12">
                                                        <label class="bmd-label-floating" style={{    color:"#009fe3",textAlign: "center", width: '100%',fontSize: '20px',fontWeight: '500',}}>Medicações</label>                                                
                                                        <div id="Med">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                            <label style={{color:'#009fe3'}}>Nome da Medicação</label>
                                                                            <input type="text" class="form-control" placeholder="Nome" disabled style={{borderBottom:    '1px solid #009fe3'}} id="nomeMed"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Dosagem</label>
                                                                        <input type="email" class="form-control" placeholder="Dose" disabled style={{borderBottom:    '1px solid #009fe3'}} id="doseMed"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Rotina</label>
                                                                        <input type="email" class="form-control" placeholder="Rotina" disabled style={{borderBottom:    '1px solid #009fe3'}} id="rotinaMed"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br/>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Lote</label>
                                                                        <input type="text" class="form-control" placeholder="Lote" disabled style={{borderBottom:    '1px solid #009fe3'}} id="loteMed"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Observações</label>
                                                                        <input type="text" class="form-control" placeholder="Observação" disabled style={{borderBottom:    '1px solid #009fe3'}} id="observacaoMed"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br/>   
                                                            <div class="row">
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" placeholder="Data Aplicada"  disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="date" className="form-control" id="dataIniMed" disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" placeholder="Proxima Aplicação"  disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="date" className="form-control" id="dataFinMed" disabled/>
                                                                    </div>
                                                                </div>
                                                            </div>  
                                                            <br/>   
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Nome do Aplicador</label>
                                                                        <input type="text" class="form-control" placeholder="Nome do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}} id="nomeEstbMed"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Email do Aplicador</label>
                                                                        <input type="text" class="form-control" placeholder="Email do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}} id="emailEstbMed"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br/> 
                                                        </div>
                                                    </div>                                                
                                                </div>
                                            <br/>
                                            <br/>
                                            </div>  
                                           
                                            <div id="Vacina" style={{display:"none"}}>    
                                                <div className="row">
                                                    <div className="col-md-12">
                                                        <label class="bmd-label-floating" style={{   color:"#009fe3",textAlign: "center", width: '100%',fontSize: '20px',fontWeight: '500'}}>Vacina</label>      
                                                        <div id="Vacina">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                            <label style={{color:'#009fe3'}}>Nome da Vacina</label>
                                                                            <input type="text" class="form-control" placeholder="Nome" disabled style={{borderBottom:    '1px solid #009fe3'}} id="nomeVacina"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Dosagem</label>
                                                                        <input type="email" class="form-control" placeholder="Dose" disabled style={{borderBottom:    '1px solid #009fe3'}} id="qntDoseVacina"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3">
                                                                    <div class="form-group">
                                                                    <label style={{color:'#009fe3'}}>Lote</label>
                                                                        <input type="text" class="form-control" placeholder="Lote" disabled style={{borderBottom:    '1px solid #009fe3'}} id="loteVacina"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br/>  
                                                            <div class="row">
                                                            <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" placeholder="Data Aplicada"  disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="date" className="form-control" id="dataApliVacina" disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" placeholder="Proxima Aplicação"  disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="date" className="form-control" id="dataProxVacina" disabled/>
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <br/> 
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                <label style={{color:'#009fe3'}}>Observações</label>
                                                                        <input type="text" class="form-control" placeholder="Observações" disabled style={{borderBottom:    '1px solid #009fe3'}} id="observacaoVacina"/>
                                                                </div>
                                                            </div>  
                                                            <br/>
                                                            <div class="row">
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Nome do Aplicador</label>
                                                                        <input type="text" class="form-control" placeholder="Nome do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}} id="nomeVetVacina" />
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>Email do Aplicador</label>
                                                                        <input type="text" class="form-control" placeholder="Email do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}}  id="emailVetVacina"/>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label style={{color:'#009fe3'}}>CRMV  do Aplicador</label>
                                                                        <input type="text" class="form-control" placeholder="CRMV  do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}}  id="crmvVetVacina"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <br/>   
                                            <br/> 
                                            </div>
                                              
                                            <div id="Exame" style={{display:"none"}}>    
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <label class="bmd-label-floating" style={{    color:"#009fe3",textAlign: "center", width: '100%',fontSize: '20px',fontWeight: '500',}}>Exames</label>   
                                                        <div className="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label style={{color:'#009fe3'}}>Nome</label>
                                                                    <input type="text" class="form-control" placeholder="Nome" disabled style={{borderBottom:    '1px solid #009fe3'}} value="Urina"/>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label style={{color:'#009fe3'}}>Observação</label>
                                                                    <input type="text" class="form-control" placeholder="Observação" disabled style={{borderBottom:    '1px solid #009fe3'}} value="Um pouco de sangue"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="row">
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label style={{color:'#009fe3'}}>Fezes</label>
                                                                    <input type="text" class="form-control" placeholder="Nome" disabled style={{borderBottom:    '1px solid #009fe3'}} value="Urina"/>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label style={{color:'#009fe3'}}>Observação</label>
                                                                    <input type="text" class="form-control" placeholder="Observação" disabled style={{borderBottom:    '1px solid #009fe3'}} value="Um pouco de sangue"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                            <br/>
                                            <br/>                                          
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div> 
            </div>
        </div>
    </div>
    )
}