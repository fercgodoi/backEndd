import React from 'react';
import "../css/material-dashboard.css";
import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";
import Confrimar from  "../img/Icon/yes.png";
import Negar from  "../img/Icon/no.png";
import Calendar from 'react-calendar';

export default function Calendario(){
    return(
        <div>
       
  <div class="wrapper ">
    <div class="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
          <div class="logo">
        <a  class="simple-text logo-normal">
          <img src={rodape} class="ImagemLogo" align="left" />            
        </a>
        <a  class="simple-text logo-normal">
          <p class="NomePrest">Cantos dos Bichos</p>
          <p class="TipoPrest">PetShop</p>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="./dashboard.html">
              <i class="material-icons">dashboard</i>
              <p>Inicio</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./user.html">
              <i class="material-icons">event</i>
              <p>Calendário</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./tables.html">
              <i class="material-icons">assignment_ind</i>
              <p>Funcionários</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./typography.html">
              <i class="material-icons">shopping_cart</i>
              <p>Shopping</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./icons.html">
              <i class="material-icons">alarm</i>
              <p>Horários</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./map.html">
              <i class="material-icons">account_circle</i>
              <p>Editar Perfil</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./notifications.html">
              <i class="material-icons">assignment</i>
              <p>Prontuários</p>
            </a>
          </li>
          <li class="nav-item active-pro ">
            <a class="nav-link" style={{background:'none'}}>
                <table>
                    <tr>
                        <td style={{width: '20%'}}>
                            <img src={rodape2} class="material-icons"/>
                        </td>
                        <td style={{width: '80%'}}>
                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                        </td>
                    </tr>
                </table>
            
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="#pablo">Calendário</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
               <li class="nav-item dropdown">
                <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">notifications</i>
                  <span class="notification">5</span>
                  <p class="d-lg-none d-md-block">
                    Some Actions
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Mike John responded to your email</a>
                  <a class="dropdown-item" href="#">You have 5 new tasks</a>
                  <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                  <a class="dropdown-item" href="#">Another Notification</a>
                  <a class="dropdown-item" href="#">Another One</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#pablo">
                  <i class="material-icons">help_outline</i>
                  <p class="d-lg-none d-md-block">
                    Stats
                  </p>
                </a>
              </li>
             
              <li class="nav-item dropdown">
                <a >
                    <img src={rodape} class="iconLogo" align="right" />      
                </a>
              </li>
            </ul>
          </div>
      </div>
      </nav>
   
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-6 col-md-12">
              <div class="card" >
                <div class="card-body">
                  <div class="tab-content">
                    <div class="tab-pane active" id="profile">
                      {/* <table class="table">
                        <tbody>
                        <tr style={{width: '100%'}}>
                          
                          <td style={{width: '20%'}} ><img src={rodape2} class="ImagemTabGrand"/></td>
                          <td style={{width: '55%'}}>
                          <p className="TituloTabGrand" >   
                             Joana da Silva Silvana
                          </p>
                              <a className="ParagTabGrand">
                                <i class="material-icons">shopping_cart</i>
                                São Bernado  
                              </a>
                              &nbsp;&nbsp;
                              <a className="ParagTabGrand">
                              <i class="material-icons">dashboard</i>
                              Tosa Completa
                              </a>
                              &nbsp;&nbsp;
                              <a className="ParagTabGrand">
                              <i class="material-icons">event</i>
                              10/03/10 - 18  horas
                              </a>
                          </td>
                          <td style={{width: '25%'}}>
                              <p className="DonoTabGrand">Juliano Santos</p>
                              <p className="TipoPagTabGrand">Pagamento via APP</p>

                              <div style={{width: '100%',textAlignLast: 'right'}}>
                                <a><img src={Confrimar} class="ButtonTabGrand" />  </a>
                              <a><img src={Negar} class="ButtonTabGrand" />  </a>
                              </div>
                              
                             
                          </td>
                        </tr>
                        </tbody>
                      </table> */}
                      <Calendar />
                    </div>
                  </div>
                </div>
              </div>

              
              <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-success card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">content_copy</i>
                        </div>
                        <p class="card-category">Contagem de Agendamentos Dia</p>
                        <h3 class="card-title">21     </h3>
                         
                        </div> 
                        <div class="card-footer">
                       
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-warning card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">store</i>
                        </div>
                        <p class="card-category">Contagem de Agendamentos Mês</p>
                        <h3 class="card-title">21     </h3>
                        </div>
                        <div class="card-footer">
                       
                        </div>
                    </div>
                </div>
                </div>

            </div>
            <div class="col-lg-6 col-md-12">
              <div class="card">               
                <div class="card-body table-responsive">
                  <table class="table table-hover">
                    <tbody>
                      <tr style={{width: '100%'}}>
                          
                        <td style={{width: '20%'}} ><img src={rodape2} class="ImagemTabelaCalender"/></td>
                        <td style={{width: '40%'}}>
                        <p className="TutuloTabela" style={{marginBottom:'0px'}}> 
                           Joana da Silva Silvana
                        </p>
                            <p className="ParagTabela" style={{marginBottom:'0px'}}>
                              <i class="material-icons">shopping_cart</i>
                              São Bernado  
                            </p>
                            <p className="ParagTabela" style={{marginBottom:'0px'}}>
                            <i class="material-icons">shopping_cart</i>
                            Tosa Completa
                            </p>
                            <p className="ParagTabela" style={{marginBottom:'0px'}}>
                            <i class="material-icons">shopping_cart</i>
                            10/03/10 - 18  horas
                            </p>
                        </td>
                        <td style={{width: '33%'}}>
                            <p style={{color:' #009fe3',
    fontWeight: 'bold',
    fontSize: 'small'}}>Juliano Santos</p>
                            <p style={{color:'#009fe2',fontSize:'10px'}}>Pagamento via APP</p>
                            
                        </td>
                      </tr>
                      <tr style={{width: '100%'}}>
                          
                          <td style={{width: '20%'}} ><img src={rodape2} class="ImagemTabelaCalender"/></td>
                          <td style={{width: '40%'}}>
                          <p className="TutuloTabela" style={{marginBottom:'0px'}}> 
                             Joana da Silva Silvana
                          </p>
                              <p className="ParagTabela" style={{marginBottom:'0px'}}>
                                <i class="material-icons">shopping_cart</i>
                                São Bernado  
                              </p>
                              <p className="ParagTabela" style={{marginBottom:'0px'}}>
                              <i class="material-icons">shopping_cart</i>
                              Tosa Completa
                              </p>
                              <p className="ParagTabela" style={{marginBottom:'0px'}}>
                              <i class="material-icons">shopping_cart</i>
                              10/03/10 - 18  horas
                              </p>
                          </td>
                          <td style={{width: '33%'}}>
                              <p style={{color:' #009fe3',
      fontWeight: 'bold',
      fontSize: 'small'}}>Juliano Santos</p>
                              <p style={{color:'#009fe2',fontSize:'10px'}}>Pagamento via APP</p>
                              
                          </td>
                        </tr>
                        <tr style={{width: '100%'}}>
                          
                          <td style={{width: '20%'}} ><img src={rodape2} class="ImagemTabelaCalender"/></td>
                          <td style={{width: '40%'}}>
                          <p className="TutuloTabela" style={{marginBottom:'0px'}}> 
                             Joana da Silva Silvana
                          </p>
                              <p className="ParagTabela" style={{marginBottom:'0px'}}>
                                <i class="material-icons">shopping_cart</i>
                                São Bernado  
                              </p>
                              <p className="ParagTabela" style={{marginBottom:'0px'}}>
                              <i class="material-icons">shopping_cart</i>
                              Tosa Completa
                              </p>
                              <p className="ParagTabela" style={{marginBottom:'0px'}}>
                              <i class="material-icons">shopping_cart</i>
                              10/03/10 - 18  horas
                              </p>
                          </td>
                          <td style={{width: '33%'}}>
                              <p style={{color:' #009fe3',
      fontWeight: 'bold',
      fontSize: 'small'}}>Juliano Santos</p>
                              <p style={{color:'#009fe2',fontSize:'10px'}}>Pagamento via APP</p>
                              
                          </td>
                        </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>       
    </div>
  </div>
    </div>
    )
}