import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import gatinho from "../img/Icon/gatinho.png";

export default function CadastroCinco(){

    var ButtonEmergenciaSim = "Não";
    var ButtonEmergenciaNao = "Não";
    var ButtonConta= "Não";
    var ButtonCielo= "Não";
    var ButtonWibx= "Não";
    var ButtonCorrente= "Não";
    var ButtonPoupanca= "Não";

    async function Proximo(){
        var erro = document.getElementById("valida");
        var Foto = document.getElementById("Foto").value;

        if(ButtonEmergenciaSim === "Não" && ButtonEmergenciaNao === "Não")
        {
            erro.innerHTML = "Selecione se você é 24horas.";
        }else{
            if (Foto === "" || Foto === null || Foto === undefined) {
    
                erro.innerHTML = "Preencha o campo Logo";
            }
            else{
                if( ButtonConta === "Não" && ButtonCielo === "Não" && ButtonWibx === "Não")
                {
                    erro.innerHTML = "Escolha um tipo de conta";
                }
                else{
                    if(ButtonConta === "Sim"){
                        var Banco = document.getElementById("Banco").value;
                        var Agencia = document.getElementById("Agencia").value;
                        var Conta = document.getElementById("NumConta").value;

                        if (Banco === "" || Banco === null || Banco === undefined) {
    
                            erro.innerHTML = "Preencha o campo Banco";
                        }
                        else{
                            if (Agencia === "" || Agencia === null || Agencia === undefined) {
    
                                erro.innerHTML = "Preencha o campo Agencia";
                            }
                            else{
                                if (Conta === "" || Conta === null || Conta === undefined) {
    
                                    erro.innerHTML = "Preencha o campo Conta";
                                }
                                else{
                                    if(ButtonCorrente === "Não" && ButtonPoupanca === "Não")
                                    {
                                        erro.innerHTML = "Selecione um tipo de conta";
                                    }
                                    else{
                                        erro.innerHTML = "";
                                        alert('ooi')
                                    }
                                }
                            }
                        }
                    }

                    if(ButtonCielo === "Sim"){
                        var CodCielo = document.getElementById("CodCielo").value;

                        if (CodCielo === "" || CodCielo === null || CodCielo === undefined) {
    
                            erro.innerHTML = "Preencha o campo do Codigo da Cielo";
                        }
                        else{
                            erro.innerHTML = "";
                            alert('ooi')
                        }
                    }

                    if(ButtonWibx === "Sim"){
                        var CodWibx = document.getElementById("CodWibx").value;

                        if (CodWibx === "" || CodWibx === null || CodWibx === undefined) {
    
                            erro.innerHTML = "Preencha o campo do Codigo da Wibx";
                        }
                        else{
                            erro.innerHTML = "";
                            alert('ooi')
                        }
                    }
                }
            }
        }
    }

    function EmergenciaSim(){
        var button = document.getElementById("EmergenciaSim");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonEmergenciaSim="Sim";

        var buttonNao = document.getElementById("EmergenciaNao");
        buttonNao.style.backgroundColor="#fff";
        buttonNao.style.border="1px solid #009fe3"; 
        buttonNao.style.color="#009fe3";
        ButtonEmergenciaNao="Não";
    }
    function EmergenciaNao(){
        var button = document.getElementById("EmergenciaNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonEmergenciaNao="Sim";


        var buttonSim = document.getElementById("EmergenciaSim");
        buttonSim.style.backgroundColor="#fff";
        buttonSim.style.border="1px solid #009fe3"; 
        buttonSim.style.color="#009fe3";
        ButtonEmergenciaSim="Não";
    }

    function Conta(){
        var erro = document.getElementById("valida");
        erro.innerHTML = "";

        var button = document.getElementById("Conta");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonConta="Sim";
        var div=document.getElementById("DivConta");
        div.style.display="block";

        var buttonCielo = document.getElementById("Cielo");
        buttonCielo.style.backgroundColor="#fff";
        buttonCielo.style.border="1px solid #009fe3"; 
        buttonCielo.style.color="#009fe3";
        ButtonCielo="Não";
        var divCielo=document.getElementById("DivCielo");
        divCielo.style.display="none";

        var buttonWibx = document.getElementById("Wibx");
        buttonWibx.style.backgroundColor="#fff";
        buttonWibx.style.border="1px solid #009fe3"; 
        buttonWibx.style.color="#009fe3";
        ButtonWibx="Não";
        var divWibx=document.getElementById("DivWibx");
        divWibx.style.display="none";

    }

    function Corrente(){
        var button = document.getElementById("Corrente");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCorrente="Sim";

        var buttonPoupa = document.getElementById("Poupanca");
        buttonPoupa.style.backgroundColor="#fff";
        buttonPoupa.style.border="1px solid #009fe3"; 
        buttonPoupa.style.color="#009fe3";
        ButtonPoupanca="Não";
    }
    function Poupanca(){
        var button = document.getElementById("Poupanca");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonPoupanca="Sim";

        var buttonCorrent = document.getElementById("Corrente");
        buttonCorrent.style.backgroundColor="#fff";
        buttonCorrent.style.border="1px solid #009fe3"; 
        buttonCorrent.style.color="#009fe3";
        ButtonCorrente="Não";
    }

    function Cielo(){
        var erro = document.getElementById("valida");
        erro.innerHTML = "";

        var button = document.getElementById("Cielo");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCielo="Sim";
        var div=document.getElementById("DivCielo");
        div.style.display="block";


        var buttonConta = document.getElementById("Conta");
        buttonConta.style.backgroundColor="#fff";
        buttonConta.style.border="1px solid #009fe3"; 
        buttonConta.style.color="#009fe3";
        ButtonConta="Não";
        var divConta=document.getElementById("DivConta");
        divConta.style.display="none";

        var buttonWibx = document.getElementById("Wibx");
        buttonWibx.style.backgroundColor="#fff";
        buttonWibx.style.border="1px solid #009fe3"; 
        buttonWibx.style.color="#009fe3";
        ButtonWibx="Não";
        var divWibx=document.getElementById("DivWibx");
        divWibx.style.display="none";
    }

    function Wibx(){
        var erro = document.getElementById("valida");
        erro.innerHTML = "";

        var button = document.getElementById("Wibx");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonWibx="Sim";
        var div=document.getElementById("DivWibx");
        div.style.display="block";

        var buttonCielo = document.getElementById("Cielo");
        buttonCielo.style.backgroundColor="#fff";
        buttonCielo.style.border="1px solid #009fe3"; 
        buttonCielo.style.color="#009fe3";
        ButtonCielo="Não";
        var divCielo=document.getElementById("DivCielo");
        divCielo.style.display="none";

        var buttonConta = document.getElementById("Conta");
        buttonConta.style.backgroundColor="#fff";
        buttonConta.style.border="1px solid #009fe3"; 
        buttonConta.style.color="#009fe3";
        ButtonConta="Não";
        var divConta=document.getElementById("DivConta");
        divConta.style.display="none";
    }

    return(
    <div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style={{padding:'0px',margin:'0px'}}>

                    <div class="card-header card-header-blue" style={{background:'#009fe3'}}>
                        <h4 class="card-title" style={{fontWeight:'300',color:'#fff',textAlign: '-webkit-center'}}>Passo 5</h4>
                    </div>
                    <div class="card-body">
                       
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img alt="" src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Fica aberto 24h?</a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">                                                 
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={EmergenciaSim} id="EmergenciaSim" >Sim</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-6">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={EmergenciaNao} id="EmergenciaNao" >Não</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img alt="" src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Ótimo! Precisamos do Logo da sua empresa!</a>
                                        <input type="text" class="form-control" placeholder="Foto" id="Foto" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                       
                        <div class="row">
                            <div class="col-md-12">
                            <img alt="" src={gatinho} style={{width:'30px'}}></img> 
                                <a style={{marginLeft:'5px',color:'#000000'}}>Show de bola! Agora precisamos saber, qual será a sua conta para recebimentos!</a>    <br/>             
                                <a style={{marginLeft:'35px',color:'#000000',fontWeight:'400'}}>OBS: A conta cadastrada precisa ser a mesma do titular do CNPJ.</a>   
                            </div>
                        </div>
                        <div class="row" id="DivCartao">
                            <div class="col-md-4">                                                 
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Conta} id="Conta">Conta</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-4">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Cielo} id="Cielo">ID Cielo</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-4">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Wibx} id="Wibx">Wibx</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                        </div>                        
                        <br/>   
                        <div id="DivConta" style={{display:'none'}}>
                        <div class="row" >
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Banco" id="Banco" style={{color:'#009fe3'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Agência" id="Agencia" style={{color:'#009fe3'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Conta" id="NumConta" style={{color:'#009fe3'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row" >
                            <div class="col-md-6">                                                 
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Corrente} id="Corrente">Corrente</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-6">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Poupanca} id="Poupanca">Poupança</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                        </div>
                        </div>
                        <div class="row" id="DivCielo" style={{display:'none'}}>
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Codigo da Cielo" id="CodCielo" style={{color:'#009fe3'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="DivWibx" style={{display:'none'}}>
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Carteira Wibx" id="CodWibx" style={{color:'#009fe3'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row" style={{textAlign: '-webkit-center'}}>
                            <div class="col-md-12">
                                <div class="form-group">
                                <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="valida"></p>
                                <button type="submit" className=" btn btn-primary btnEditShop" onClick={Proximo}>Proximo</button>
                                </div>
                            </div>
                        </div>
                    </div>                                          

                    </div>
                </div>
            </div>
        </div>    
    </div>
    )
}