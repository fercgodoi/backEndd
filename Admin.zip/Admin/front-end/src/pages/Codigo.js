import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import rodape from  "../img/login.png";
import Blabala from "../img/cover.jpg";

export default function Codigo(){
    return(
        <div>
            
        <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" style={{marginBottom:'0px'}}>				
                     <div style={{
                        height: '100%',
                        width: '100%',
                        textAlign: 'center'
                        // paddingBottom: '25%'
                    }}>
                    <div>
                        <img src={rodape} style={{width: '40%', height: '20%'}}/>
                    </div>
                    <div style={{
                        width: '100%',
                        height: 'auto',
                        marginTop:'2%'
                    }}>
                        <div class="col-md-12">
                            <div class="form-group" style={{paddingLeft: '10%',paddingRight: '10%'}}>
                                <input type="text" class="form-control" placeholder="CPF"/>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group" style={{paddingLeft: '10%',paddingRight: '10%'}}>
                                <input type="text" class="form-control" placeholder="Código"/>
                            </div>
                        </div>
                     
                    </div>

                    
                    <div style={{
                        textAlign: '-webkit-center',
                        paddingTop: '5%'
                    }}>
                        <table>
                            <tr>
                                <td style={{width:'100%'}}>
                                    <button type="submit" class="btn btn-primary pull-right" style={{
                                        backgroundColor:' #009fe3',
                                        borderRadius: '32px',
                                        width:'100%'
                                    }}>Verificar</button>
                                    <div class="clearfix"></div>
                                </td>
                                
                                
                            </tr>
                        </table>
                        </div></div>
				</form>
				<div class="login100-more" >
                <img src={Blabala} style={{width: '100%',height: '50%',position: 'absolute',top:'50%'}}/>
                <img src={Blabala} style={{width: '100%',height: '50%',position: 'absolute'}}/>
				</div>
			</div>
		</div>
	</div>
    
    </div>
    )
}