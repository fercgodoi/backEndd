import React from 'react';
import InputMask from 'react-input-mask';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/Login/new.css";
import "../css/material-dashboard.css";
import Logo from  "../img/login.png";
import Imagem from "../img/cover.jpg";

export default function AlterarSenha(){

    async function Confirmar() {   
        var cpf = document.getElementById("cpf").value;
        var senha = document.getElementById("senha").value;
        var confSenha = document.getElementById("confSenha").value;
        var erro = document.getElementById("valida");
    
        if (cpf === "" || cpf === null || cpf === undefined) {
    
            erro.innerHTML = "Preencha os campos obrigatório";
        }
        else {
            if(validarCPF(cpf)){
                if (senha === "" || senha === null || senha === undefined) {
    
                    erro.innerHTML = "Preencha os campos obrigatório";
                    erro.style.color = "#FF0000";
                }
                else {
                    if(senha.length < 6  || senha.length > 15)
                    {
                        erro.innerHTML = "A senha deve conter de 6 a 15 caracteres";
                    }
                    else{
    
                        if (confSenha === "" || confSenha === null || confSenha === undefined) {
        
                            erro.innerHTML = "Preencha os campos obrigatório";
                        }
                        else{
            
                            if(confSenha !== senha){
                                erro.innerHTML = "As senhas não conhecidem ";
                            }
                            else{
                                erro.innerHTML = "";
    
                                // const response =  await api.get("/trocaSenha", {
                                //     headers:{
                                //         cpf:cpf,senha:senha
                                //     }
                                // });
                                // if(response.data.n === 0){
                                //     erro.innerHTML = "Seu CPF não é registrado no shopping.";
                                //     erro.style.color = "#FF0000";
                                // }
                                // else{
                                //     window.location.href="/Login";
                                // }
                            }    
                        }
                    }                
                }
            }
            else{
                erro.innerHTML = "Verifique o CPF";
            }
            
        }        
    }

    function validarCPF(cpf) {	
        var cpf1 = document.getElementById("cpf").value;
        cpf = cpf1;
        cpf = cpf.replace(/[^\d]+/g,'');	
        if(cpf === '') return false;	
        // Elimina CPFs invalidos conhecidos	
        if (cpf.length !== 11 || 
            cpf === "00000000000" || 
            cpf === "11111111111" || 
            cpf === "22222222222" || 
            cpf === "33333333333" || 
            cpf === "44444444444" || 
            cpf === "55555555555" || 
            cpf === "66666666666" || 
            cpf === "77777777777" || 
            cpf === "88888888888" || 
            cpf === "99999999999")
                return false;		
        // Valida 1o digito	
        var add = 0;	
        var i=0;
        var rev=0;
        for (i=0; i < 9; i ++)		
            add += parseInt(cpf.charAt(i)) * (10 - i);	
            rev = 11 - (add % 11);	
            if (rev === 10 || rev === 11)		
                rev = 0;	
            if (rev !== parseInt(cpf.charAt(9)))		
                return false;		
        // Valida 2o digito	
        var add2 = 0;	
        for (i = 0; i < 10; i ++)		
            add2 += parseInt(cpf.charAt(i)) * (11 - i);	
        rev = 11 - (add2 % 11);	
        if (rev === 10 || rev === 11)	
            rev = 0;	
        if (rev !== parseInt(cpf.charAt(10)))
            return false;		
        return true;   
    }

    return(
    <div>        
    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-form validate-form" style={{marginBottom:'0px'}}>				
                    <div style={{height: '100%',width: '100%',textAlign: 'center'}}>
                        <div>
                            <img src={Logo} alt="" style={{width: '40%', height: '20%'}}/>
                        </div>
                        <div style={{width: '100%',height: 'auto',marginTop:'2%'}}>
                            <div class="col-md-12">
                                <div class="form-group input" >
                                <InputMask type="text"  mask = "999.999.999-99" className="form-control" id="cpf" placeholder="CPF" maskChar=""/>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group input" >
                                    <input type="password" class="form-control" id="senha" placeholder="Nova Senha"/>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group input" >
                                    <input type="password" class="form-control" id="confSenha" placeholder="Confrimar Nova Senha"/>
                                    <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="valida"></p>
                                </div>
                            </div>
                        </div>
                        <div style={{textAlign: '-webkit-center',paddingTop: '5%'}}>
                            <table>
                                <tr>
                                    <td style={{width:'100%'}}>
                                        <button type="submit" class="btn btn-primary pull-right" style={{backgroundColor:' #009fe3',borderRadius: '32px',width:'100%'}} onClick={Confirmar}>Trocar Senha</button>
                                        <div class="clearfix"></div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
				</div>
				<div class="login100-more" >
                    <img src={Imagem}  alt="" className="ImagemTop"/>
                    <img src={Imagem} alt="" className="ImagemBottom"/>
				</div>
			</div>
		</div>
	</div>    
    </div>
    )
}