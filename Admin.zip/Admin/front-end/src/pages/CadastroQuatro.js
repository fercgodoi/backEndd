import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import rodape from  "../img/login.png";
import Blabala from "../img/cover.jpg";
import gatinho from "../img/Icon/gatinho.png";

export default function CdastroQuatro(){
    return(
    <div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style={{padding:'0px',margin:'0px'}}>

                    <div class="card-header card-header-blue" style={{background:'#009fe3'}}>
                        <h4 class="card-title" style={{fontWeight:'300',color:'#fff',textAlign: '-webkit-center'}}>Passo 4</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <img src={gatinho} style={{width:'30px'}}></img> 
                                <a style={{marginLeft:'5px',color:'#000000'}}>Perfeito! Qual é a sua área de atuação!</a>                                           
                                <br/>
                                <button type="submit" className="btnCadFunc">Acupuntura</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Adestramento</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Anestesia</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Banho</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Castração</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Cirurgias</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Clínica Veterinária</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Consultas Específicas</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Consultas Gerais </button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Corte de unha</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Creche</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Cremação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Dog Walker</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Escovação dos dentes</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Eutanásia</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Exames de imagens </button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Exames parasitológicos  </button>
                                <div class="clearfix"></div>                                                   
                            </div>

                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Exames sanguíneos</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Hemoterapia</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Hidratação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Hospedagem</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Hotel para Pet</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Ioga</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Natação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Pet Sitter</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Radiologia</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Remoção</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Sepultamento</button>
                                <div class="clearfix"></div>                                                   
                            </div>

                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Taxi Dog</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Tintura de pelagem</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Tosa</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Transfusão sanguínea</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Transporte</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Vacinação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/> 
                                <button type="submit" className="btnCadFunc">Venda de Animais</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc">Venda de Produtos</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                        </div>  
                        {/* <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Legal, agora precisamos saber qual é o seu cep do seu estabelecimento! </a>
                                        <input type="text" class="form-control" placeholder="CEP" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Seu estado é? </a>
                                        <input type="text" class="form-control" placeholder="Estado" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Sua cidade é? </a>
                                        <input type="text" class="form-control" placeholder="Cidade" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Sua rua é? </a>
                                        <input type="text" class="form-control" placeholder="Rua" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Show! Para poder atender melhor seus clientes, precisamos do número da Empresa!</a>
                                        <input type="text" class="form-control" placeholder="Número" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/> */}
                        <div class="row" style={{textAlign: '-webkit-center'}}>
                            <div class="col-md-12">
                                <div class="form-group" style={{paddingBottom:'0px'}}>
                                <button type="submit" className=" btn btn-primary btnEditShop" style={{border:'2px solid #009fe3'}} >Proximo</button>
                                </div>
                            </div>
                        </div>
                    </div>
                                            

                    </div>
                </div>
            </div>
        </div>    
    </div>
    )
}