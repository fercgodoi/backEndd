import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import gatinho from "../img/Icon/gatinho.png";

export default function CdastroQuatro(){

    var  ButtonAcupuntura = "Não";
    var  ButtonAdestramento = "Não";
    var  ButtonAnestesia = "Não";
    var  ButtonBanho = "Não";
    var  ButtonCastração  = "Não";
    var  ButtonCirurgias = "Não";
    var  ButtonClinicaVeterinaria = "Não";
    var  ButtonConsultasEspecificas = "Não";
    var  ButtonConsultasGerais = "Não";
    var  ButtonCorteUnha = "Não";
    var  ButtonCreche = "Não";
    var  ButtonCremacao = "Não";
    var  ButtonDogWalker = "Não";
    var  ButtonEscovacaoDentes = "Não";
    var  ButtonEutanasia = "Não";
    var  ButtonExamesImagens = "Não";
    var  ButtonExamesParasitologicos = "Não";
    var  ButtonExameSanguineos = "Não";
    var  ButtonHemoterapia = "Não";
    var  ButtonHidratacao = "Não";
    var  ButtonHospedagem = "Não";
    var  ButtonHotelPet = "Não";
    var  ButtonIoga = "Não";
    var  ButtonNatacao = "Não";
    var  ButtonPetSitter = "Não";
    var  ButtonRadiologia = "Não";
    var  ButtonRemocao = "Não";
    var  ButtonSepultamento = "Não";
    var  ButtonTaxiDog = "Não";
    var  ButtonTinturaPelagem = "Não";
    var  ButtonTosa = "Não";
    var  ButtonTransfusaoSanguinea = "Não";
    var  ButtonTransporte = "Não";
    var  ButtonVacinacao = "Não";
    var  ButtonVendaAnimais = "Não";
    var  ButtonVendaProdutos = "Não";

    function Proximo(){
        var erro = document.getElementById("valida");

        if (ButtonAcupuntura === "Não" && ButtonAdestramento === "Não" && ButtonAnestesia === "Não" && ButtonBanho === "Não" && ButtonCastração === "Não" && ButtonCirurgias === "Não" && ButtonClinicaVeterinaria === "Não" &&  ButtonConsultasEspecificas === "Não" && ButtonConsultasGerais === "Não" && ButtonCorteUnha === "Não" && ButtonCreche === "Não" && ButtonCremacao === "Não" && ButtonDogWalker === "Não" && ButtonEscovacaoDentes === "Não" && ButtonEutanasia === "Não" &&  ButtonExamesImagens === "Não" && ButtonExamesParasitologicos === "Não" && ButtonExameSanguineos === "Não" && ButtonHemoterapia === "Não" && ButtonHidratacao === "Não" && ButtonHospedagem === "Não" && ButtonHotelPet === "Não" && ButtonIoga === "Não" && ButtonNatacao === "Não" && ButtonPetSitter === "Não" && ButtonRadiologia === "Não" && ButtonRemocao === "Não" && ButtonSepultamento === "Não" && ButtonTaxiDog === "Não" && ButtonTinturaPelagem === "Não" && ButtonTosa === "Não" && ButtonTransfusaoSanguinea === "Não" && ButtonTransporte === "Não" && ButtonVacinacao === "Não" && ButtonVendaAnimais === "Não" && ButtonVendaProdutos === "Não"){
            erro.innerHTML = "Escolha pelo menos um serviço";
        }
        else{
            erro.innerHTML = "";
            alert("Ooi");
        }


    }

    function Acupuntura(){
        var button = document.getElementById("Acupuntura");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonAcupuntura="Sim";
    }
    function Adestramento(){
        var button = document.getElementById("Adestramento");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonAdestramento="Sim";
    }
    function Anestesia(){
        var button = document.getElementById("Anestesia");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonAnestesia="Sim";
    }
    function Banho(){
        var button = document.getElementById("Banho");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonBanho="Sim";
    }
    function Castração(){
        var button = document.getElementById("Castração");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCastração="Sim";
    }
    function ClinicaVeterinaria(){
        var button = document.getElementById("ClinicaVeterinaria");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonClinicaVeterinaria="Sim";
    }
    function Cirurgias(){
        var button = document.getElementById("Cirurgias");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCirurgias="Sim";
    }
    function ConsultasEspecificas(){
        var button = document.getElementById("ConsultasEspecificas");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonConsultasEspecificas="Sim";
    }
    function ConsultasGerais(){
        var button = document.getElementById("ConsultasGerais");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonConsultasGerais="Sim";
    }
    function CorteUnha(){
        var button = document.getElementById("CorteUnha");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCorteUnha="Sim";
    }
    function Creche(){
        var button = document.getElementById("Creche");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCreche="Sim";
    }
    function Cremacao(){
        var button = document.getElementById("Cremacao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonCremacao="Sim";
    }
    function DogWalker(){
        var button = document.getElementById("DogWalker");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonDogWalker="Sim";
    }
    function EscovacaoDentes(){
        var button = document.getElementById("EscovacaoDentes");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonEscovacaoDentes="Sim";
    }
    function Eutanasia(){
        var button = document.getElementById("Eutanasia");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonEutanasia="Sim";
    }
    function ExamesImagens(){
        var button = document.getElementById("ExamesImagens");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonExamesImagens="Sim";
    }
    function ExamesParasitologicos(){
        var button = document.getElementById("ExamesParasitologicos");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonExamesParasitologicos="Sim";
    }
    function ExameSanguineos(){
        var button = document.getElementById("ExameSanguineos");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonExameSanguineos="Sim";
    }
    function Hemoterapia(){
        var button = document.getElementById("Hemoterapia");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonHemoterapia="Sim";
    }
    function Hidratacao(){
        var button = document.getElementById("Hidratacao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonHidratacao="Sim";
    }
    function Hospedagem(){
        var button = document.getElementById("Hospedagem");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonHospedagem="Sim";
    }
    function HotelPet(){
        var button = document.getElementById("HotelPet");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonHotelPet="Sim";
    }
    function Ioga(){
        var button = document.getElementById("Ioga");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonIoga="Sim";
    }
    function Natacao(){
        var button = document.getElementById("Natacao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonNatacao="Sim";
    }
    function PetSitter(){
        var button = document.getElementById("PetSitter");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonPetSitter="Sim";
    }
    function Radiologia(){
        var button = document.getElementById("Radiologia");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonRadiologia="Sim";
    }
    function Remocao(){
        var button = document.getElementById("Remocao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonRemocao="Sim";
    }
    function Sepultamento(){
        var button = document.getElementById("Sepultamento");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonSepultamento="Sim";
    }
    function TaxiDog(){
        var button = document.getElementById("TaxiDog");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonTaxiDog="Sim";
    }
    function TinturaPelagem(){
        var button = document.getElementById("TinturaPelagem");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonTinturaPelagem="Sim";
    }
    function Tosa(){
        var button = document.getElementById("Tosa");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonTosa="Sim";
    }
    function TransfusaoSanguinea(){
        var button = document.getElementById("TransfusaoSanguinea");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonTransfusaoSanguinea="Sim";
    }
    function Transporte(){
        var button = document.getElementById("Transporte");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonTransporte="Sim";
    }
    function Vacinacao(){
        var button = document.getElementById("Vacinacao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonVacinacao="Sim";
    }
    function VendaAnimais(){
        var button = document.getElementById("VendaAnimais");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonVendaAnimais="Sim";
    }
    function VendaProdutos(){
        var button = document.getElementById("VendaProdutos");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ButtonVendaProdutos="Sim";
    }
    return(
    <div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style={{padding:'0px',margin:'0px'}}>

                    <div class="card-header card-header-blue" style={{background:'#009fe3'}}>
                        <h4 class="card-title" style={{fontWeight:'300',color:'#fff',textAlign: '-webkit-center'}}>Passo 4</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <img alt="" src={gatinho} style={{width:'30px'}}></img> 
                                <a style={{marginLeft:'5px',color:'#000000'}}>Legal! Quais são seus serviços?</a>                                           
                                <br/>
                                <button type="submit" className="btnCadFunc"  onClick={Acupuntura} id="Acupuntura">Acupuntura</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Adestramento} id="Adestramento">Adestramento</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Anestesia} id="Anestesia">Anestesia</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Banho} id="Banho">Banho</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Castração} id="Castração">Castração</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Cirurgias} id="Cirurgias">Cirurgias</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={ClinicaVeterinaria} id="ClinicaVeterinaria">Clínica Veterinária</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={ConsultasEspecificas} id="ConsultasEspecificas">Consultas Específicas</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={ConsultasGerais} id="ConsultasGerais">Consultas Gerais </button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={CorteUnha} id="CorteUnha">Corte de unha</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Creche} id="Creche">Creche</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Cremacao} id="Cremacao">Cremação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={DogWalker} id="DogWalker">Dog Walker</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={EscovacaoDentes} id="EscovacaoDentes">Escovação dos dentes</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Eutanasia} id="Eutanasia">Eutanásia</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={ExamesImagens} id="ExamesImagens">Exames de imagens</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={ExamesParasitologicos} id="ExamesParasitologicos">Exames parasitológicos</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={ExameSanguineos} id="ExameSanguineos">Exames sanguíneos</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Hemoterapia} id="Hemoterapia">Hemoterapia</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Hidratacao} id="Hidratacao">Hidratação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Hospedagem} id="Hospedagem">Hospedagem</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={HotelPet} id="HotelPet">Hotel para Pet</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Ioga} id="Ioga">Ioga</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Natacao} id="Natacao">Natação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={PetSitter} id="PetSitter">Pet Sitter</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Radiologia} id="Radiologia">Radiologia</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Remocao} id="Remocao">Remoção</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Sepultamento} id="Sepultamento">Sepultamento</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={TaxiDog} id="TaxiDog">Taxi Dog</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={TinturaPelagem} id="TinturaPelagem">Tintura de pelagem</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Tosa} id="Tosa">Tosa</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={TransfusaoSanguinea} id="TransfusaoSanguinea">Transfusão sanguínea</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Transporte} id="Transporte">Transporte</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={Vacinacao} id="Vacinacao">Vacinação</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/> 
                                <button type="submit" className="btnCadFunc" onClick={VendaAnimais} id="VendaAnimais">Venda de Animais</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <button type="submit" className="btnCadFunc" onClick={VendaProdutos} id="VendaProdutos">Venda de Produtos</button>
                                <div class="clearfix"></div>                                                   
                            </div>                            
                        </div>  
                       
                        <div class="row" style={{textAlign: '-webkit-center'}}>
                            <div class="col-md-12">
                                <div class="form-group" style={{paddingBottom:'0px'}}>
                                <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="valida"></p>
                                <button type="submit" className=" btn btn-primary btnEditShop" style={{border:'2px solid #009fe3'}} onClick={Proximo}>Proximo</button>
                                </div>
                            </div>
                        </div>
                    </div>
                                            

                    </div>
                </div>
            </div>
        </div>    
    </div>
    )
}