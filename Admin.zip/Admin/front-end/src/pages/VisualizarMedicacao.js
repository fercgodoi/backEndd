import React from 'react';


import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";

import Confrimar from  "../img/Icon/yes.png";
import Negar from  "../img/Icon/no.png";

export default function VisualizarMedicacao(){
    return(

         /* .btnCadFunc:active{
  background-color: #009fe3;
  border-radius: 32px;
  border: 2px solid #009FE3;
  color: #fff;
 } */
    <div>
        <div class="wrapper ">
            <div class="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                <div class="logo">
                    <a  class="simple-text logo-normal">
                        <img src={rodape} class="ImagemLogo" align="left" />            
                    </a>
                    <a  class="simple-text logo-normal">
                        <p class="NomePrest">Cantos dos Bichos</p>
                        <p class="TipoPrest">PetShop</p>
                    </a>
                </div>
                <div class="sidebar-wrapper">
                    <ul class="nav">
                        <li class="nav-item active  ">
                            <a class="nav-link" href="./dashboard.html">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./user.html">
                            <i class="material-icons">event</i>
                            <p>Calendário</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./tables.html">
                            <i class="material-icons">assignment_ind</i>
                            <p>Funcionários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./typography.html">
                            <i class="material-icons">shopping_cart</i>
                            <p>Shopping</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./icons.html">
                            <i class="material-icons">alarm</i>
                            <p>Horários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./map.html">
                            <i class="material-icons">account_circle</i>
                            <p>Editar Perfil</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./notifications.html">
                            <i class="material-icons">assignment</i>
                            <p>Prontuários</p>
                            </a>
                        </li>
                        <li class="nav-item active-pro ">
                            <a class="nav-link" style={{background:'none'}}>
                                <table>
                                    <tr>
                                        <td style={{width: '20%'}}>
                                            <img src={rodape2} class="material-icons"/>
                                        </td>
                                        <td style={{width: '80%'}}>
                                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                                        </td>
                                    </tr>
                                </table>            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>    
            <div class="main-panel">
                <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                    <div class="container-fluid">
                        <div class="navbar-wrapper">
                            <a class="navbar-brand" href="#pablo" style={{fontSize:'21px'}}>Visualizar Medicação</a>
                        </div>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-end">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">notifications</i>
                                        <span class="notification">5</span>
                                        <p class="d-lg-none d-md-block">
                                            Some Actions
                                        </p>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item" href="#">Mike John responded to your email</a>
                                        <a class="dropdown-item" href="#">You have 5 new tasks</a>
                                        <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                                        <a class="dropdown-item" href="#">Another Notification</a>
                                        <a class="dropdown-item" href="#">Another One</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#pablo">
                                        <i class="material-icons">help_outline</i>
                                        <p class="d-lg-none d-md-block">
                                            Stats
                                        </p>
                                    </a>
                                </li>                                
                                <li class="nav-item dropdown">
                                    <a >
                                        <img src={rodape} class="iconLogo" align="right" />      
                                    </a>                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header card-header-blue">
                                        <h4 class="card-title">Medicações</h4>
                                    </div>
                                    <div class="card-body">
                                        {/* <form> */}
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>Nome do Pet</label>
                                                            <input type="text" class="form-control" placeholder="Nome do Pet" disabled style={{borderBottom:    '1px solid #009fe3'}} />
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>RG Animal</label>
                                                        <input type="email" class="form-control" placeholder="RG Animal" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                            <label style={{color:'#009fe3'}}>Nome da Medicação</label>
                                                            <input type="text" class="form-control" placeholder="Nome" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>Dosagem</label>
                                                        <input type="email" class="form-control" placeholder="Dose" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                         <label style={{color:'#009fe3'}}>Lote</label>
                                                        <input type="text" class="form-control" placeholder="Lote" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>Observações</label>
                                                        <input type="text" class="form-control" placeholder="Observação" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/>   
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                         <label style={{color:'#009fe3'}}>Data Inicio</label>
                                                        <input type="text" class="form-control" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>Data Final</label>
                                                        <input type="text" class="form-control" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                            </div> 
                                            <br/>   
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>Nome do Aplicador</label>
                                                        <input type="text" class="form-control" placeholder="Nome do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label style={{color:'#009fe3'}}>Email do Aplicador</label>
                                                        <input type="text" class="form-control" placeholder="Email do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <div class="form-group">
                                                         <label style={{color:'#009fe3'}}>CRMV  do Aplicador</label>
                                                        <input type="text" class="form-control" placeholder="CRMV  do Aplicador" disabled style={{borderBottom:    '1px solid #009fe3'}}/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/> 
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div> 
            </div>
        </div>
    </div>
    )
}