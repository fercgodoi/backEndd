import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/Login/new.css";
import "../css/material-dashboard.css";
import Logo from  "../img/login.png";

import Imagem from "../img/cover.jpg";

export default function Login(){

   //verificar se a pessoa esta logado
  //  function Acesso(){
  //   var login= localStorage.getItem('Login');
  //   if(login === 'Sim'){
  //       window.location.href = "/Carrinho";
  //   }
  //   Acesso();

    //Efetuar o login
    async function Logar(e) {
        e.preventDefault();
        var email = document.getElementById("email").value;
        var senha = document.getElementById("senha").value;
        var erro = document.getElementById("valida");

        if (email === "" || email === null || email === undefined) {
            erro.innerText = "Preencha seu email";
        }
        else {
          if(email.indexOf("@") === -1 || email.indexOf(".") === -1  ){
            erro.innerText = "Email Inválido";
          }
          else{
            if (senha === "" || senha === null || senha === undefined) {
              erro.innerText = "Preencha sua senha";
            }
            else {
              erro.innerText="";
              // const response =  await api.get("/user", {
              //       headers:{
              //           email:email,senha:senha
              //       }
              //   });
                
              //   if(response.data[0])
              //   {
              //       var status = response.data[0].status;
              //       if(status === "Certo"){
              //           //Vai para o carrinho
              //           localStorage.removeItem('Login');
              //           localStorage.removeItem('Name');
              //           localStorage.removeItem('CPF');
              //           localStorage.setItem('Login','Sim');
              //           localStorage.setItem('Name',response.data[0].nome);
              //           localStorage.setItem('CPF',response.data[0].cpf);
              //           window.location.href = "/Carrinho";
              //       }
              //       else{
              //           //ele vai para trocar senha
              //           window.location.href = "/TrocaSenha";
              //       }
              //   }else{
              //       erroS.innerText = "Tente Novamente";
              //       erroS.style.color = "#FF0000";
              //   }

            }   
          }           
        }
    }

    return(
      <div>
      <div className="limiter">
		    <div className="container-login100">
		      <div className="wrap-login100">
            <form className="login100-form validate-form" style={{marginBottom:'0px'}}>
              <div style={{height: '100%',width: '100%',textAlign: 'center'}}>
                <div>
                    <img src={Logo} alt="" style={{width: '40%', height: '20%'}}/>
                </div>
                <div style={{width: '100%',height: 'auto',marginTop:'2%'}}>
                    <div className="col-md-12">
                        <div className="form-group input" >
                            <input type="text" className="form-control" id="email" placeholder="Email"/>
                        </div>
                    </div>
                    <div className="col-md-12 ">
                        <div className="form-group input">
                            <input type="password" className="form-control"  id="senha" placeholder="Senha"/>
                            <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="valida"></p>
                        </div>
                    </div>
                </div>
                <div className="DivEsqueceuSenha">
                  <a style={{color:'#009fe3',fontFamily:'Arial'}} href="/EsqueciSenha"> Esqueceu Senha?</a>
                </div>
                <div style={{textAlign: '-webkit-center',paddingTop: '5%'}}>
                  <table>
                      <tr>
                          <td style={{width:'50%'}}>
                              <button type="submit" className="btn btn-primary pull-right Login" onClick={Logar}>Login</button>
                              <div className="clearfix"></div>
                          </td>
                          <td style={{width:'50%', paddingLeft: '2%',}}>
                              <a type="submit" className="btn btn-primary pull-right Cadastro" href="/CadastroPrimeiro">Cadastro</a>
                              <div className="clearfix"></div>
                          </td>
                      </tr>
                  </table>
                </div>
              </div>
            </form>
            <div className="login100-more" >
              <img src={Imagem} alt="" className="ImagemTop"/>
              <img src={Imagem} alt="" className="ImagemBottom"/>
				    </div>
          </div>
        </div>
      </div>
      </div>        
    )
        
}