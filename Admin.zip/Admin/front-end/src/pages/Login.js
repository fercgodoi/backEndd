import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import rodape from  "../img/login.png";
import rodape2 from  "../img/Icon/versao.png";

import Confrimar from  "../img/Icon/yes.png";
import Negar from  "../img/Icon/no.png";
import Blabala from "../img/cover.jpg";

export default function Login(){
    return(
   
    // <div style={{height: '100%', maxHeight: '100%'}}>
    //     <div class="wrapper " style={{height:'100%'}}>       
    //         <div class="main-panel" style={{width:'100%',height:'100%'}}>    
    //             <div style={{height: '100%'}} >
    //                 <div class="container-fluid" style={{height: '100%', margin:'0 0 0 0', padding: '0 0 0 0'}} >
    //                     <div class="row" style={{height: '100%',width:'100%',margin:'0 0 0 0'}} >
    //                         <div class="row" style={{height: '100%',width: '100%',margin:'0 0 0 0'}} >
    //                             <div class="col-lg-7 col-md-12" style={{height: '100%', padding: '0 0 0 0'}} >
    //                                  <table style={{width: '100%',height: '100%'}}>
    //                                     <tr style={{width: '100%',height: '50%',margin:'0 0 0 0'}}>
    //                                         <td style={{width: '100%',height: '100%',display: 'table',margin:'0 0 0 0', padding: '0 0 0 0'}}>
    //                                             <img src={Blabala} style={{width: '100%',height: '360px'}}/>
    //                                         </td>                        
    //                                     </tr>
    //                                     <tr style={{width: '100%',height: '50%',margin:'0 0 0 0'}}>
    //                                         <td style={{width: '100%',height: '100%',display: 'table',margin:'0 0 0 0', padding: '0 0 0 0'}}>
    //                                                 <img src={Blabala} style={{width: '100%',height: '362.5px'}}/>
    //                                         </td>                        
    //                                     </tr>
    //                                 </table>
    //                             </div>
    //                             <div class="col-lg-5 col-md-12" style={{height: '100%'}} >
    //                                 <div style={{
    //                                         height: '100%',
    //                                         width: '100%',
    //                                         textAlign: 'center',
    //                                         paddingTop: '15%',
    //                                         // paddingBottom: '25%'
    //                                     }}>
    //                                     <div>
    //                                         <img src={rodape} style={{width: '40%', height: '20%'}}/>
    //                                     </div>
    //                                     <div style={{
    //                                         width: '100%',
    //                                         height: 'auto',
    //                                         marginTop:'2%'
    //                                     }}>
    //                                         <div class="col-md-12">
    //                                             <div class="form-group" style={{paddingLeft: '20%',paddingRight: '20%'}}>
    //                                                 <input type="text" class="form-control" placeholder="Email"/>
    //                                             </div>
    //                                         </div>
    //                                         <div class="col-md-12">
    //                                             <div class="form-group" style={{paddingLeft: '20%',paddingRight: '20%'}}>
    //                                                 <input type="text" class="form-control" placeholder="Senha"/>
    //                                             </div>
    //                                         </div>
    //                                     </div>

    //                                     <div style={{
    //                                         width: '100%',
    //                                         paddingTop: '5%',
    //                                         paddingLeft: '10%',
    //                                         paddingRight: '20%',
    //                                         textAlign: 'right',
    //                                         color: '#009fe3',
    //                                         fontWeight: '500'
    //                                     }}>
    //                                        <p> Esqueceu Senha?</p>
    //                                     </div>
    //                                     <div style={{
    //                                         textAlign: '-webkit-center',
    //                                         paddingTop: '5%'
    //                                     }}>
    //                                         <table>
    //                                             <tr>
    //                                                 <td>
    //                                                     <button type="submit" class="btn btn-primary pull-right" style={{
    //                                                         backgroundColor:' #009fe3',
    //                                                         borderRadius: '32px',
    //                                                         padding: '21px 75px',
    //                                                     }}>Login</button>
    //                                                     <div class="clearfix"></div>
    //                                                 </td>
    //                                                 <td >
    //                                                     <button type="submit" class="btn btn-primary pull-right" style={{
    //                                                         backgroundColor:' #fff',
    //                                                         borderRadius: '32px',
    //                                                         padding: '21px 65px',
    //                                                         border: '1px solid #009fe3',
    //                                                         color:'#009fe3'
    //                                                     }}>Cadastro</button>
    //                                                     <div class="clearfix"></div>
    //                                                 </td>
    //                                             </tr>
    //                                         </table>
    //                                     </div>                                     
                                     
    //                                 </div>
    //                             </div>
    //                         </div> 
    //                     </div>
    //                 </div>          
    //             </div>
    //         </div>
    //     </div>
    // </div>

    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" style={{marginBottom:'0px'}}>				
                     <div style={{
                                            height: '100%',
                                            width: '100%',
                                            textAlign: 'center'
                                            // paddingBottom: '25%'
                                        }}>
                                        <div>
                                            <img src={rodape} style={{width: '40%', height: '20%'}}/>
                                        </div>
                                        <div style={{
                                            width: '100%',
                                            height: 'auto',
                                            marginTop:'2%'
                                        }}>
                                            <div class="col-md-12">
                                                <div class="form-group" style={{paddingLeft: '10%',paddingRight: '10%'}}>
                                                    <input type="text" class="form-control" placeholder="Email"/>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group" style={{paddingLeft: '10%',paddingRight: '10%'}}>
                                                    <input type="text" class="form-control" placeholder="Senha"/>
                                                </div>
                                            </div>
                                        </div>

                                        <div style={{
                                            width: '100%',
                                            paddingTop: '5%',
                                            paddingLeft: '10%',
                                            paddingRight: '20%',
                                            textAlign: 'right',
                                            color: '#009fe3',
                                            fontWeight: '500'
                                        }}>
                                           <p style={{color:'#009fe3',fontFamily:'Arial'}}> Esqueceu Senha?</p>
                                        </div>
                                        <div style={{
                                            textAlign: '-webkit-center',
                                            paddingTop: '5%'
                                        }}>
                                            <table>
                                                <tr>
                                                    <td style={{width:'50%'}}>
                                                        <button type="submit" class="btn btn-primary pull-right" style={{
                                                            backgroundColor:' #009fe3',
                                                            borderRadius: '32px',
                                                            width:'100%'
                                                        }}>Login</button>
                                                        <div class="clearfix"></div>
                                                    </td>
                                                    <td style={{width:'50%', paddingLeft: '2%',}}>
                                                        <button type="submit" class="btn btn-primary pull-right" style={{
                                                            backgroundColor:' #fff',
                                                            borderRadius: '32px',
                                                            border: '1px solid #009fe3',
                                                            color:'#009fe3',
                                                            width:'100%'
                                                        }}>Cadastro</button>
                                                        <div class="clearfix"></div>
                                                    </td>
                                                </tr>
                                            </table>
                                            </div></div>
				</form>
                {/* style={{backgroundImage: 'url(src/img/cover.jpg)' }} */}
				<div class="login100-more" >
                <img src={Blabala} style={{width: '100%',height: '50%',position: 'absolute',top:'50%'}}/>
                <img src={Blabala} style={{width: '100%',height: '50%',position: 'absolute'}}/>
				</div>
			</div>
		</div>
	</div>
    )
        {/*  <!-- Navbar --> 
         *<nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
            <div class="container-fluid">
              <div class="navbar-wrapper">
                <a class="navbar-brand" href="#pablo">Inicio > Detalhes </a>
              </div>
              <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                <span class="sr-only">Toggle navigation</span>
                <span class="navbar-toggler-icon icon-bar"></span>
                <span class="navbar-toggler-icon icon-bar"></span>
                <span class="navbar-toggler-icon icon-bar"></span>
              </button>
              <div class="collapse navbar-collapse justify-content-end">
                <ul class="navbar-nav">
                   <li class="nav-item dropdown">
                    <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="material-icons">notifications</i>
                      <span class="notification">5</span>
                      <p class="d-lg-none d-md-block">
                        Some Actions
                      </p>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                      <a class="dropdown-item" href="#">Mike John responded to your email</a>
                      <a class="dropdown-item" href="#">You have 5 new tasks</a>
                      <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                      <a class="dropdown-item" href="#">Another Notification</a>
                      <a class="dropdown-item" href="#">Another One</a>
                    </div>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#pablo">
                      <i class="material-icons">help_outline</i>
                      <p class="d-lg-none d-md-block">
                        Stats
                      </p>
                    </a>
                  </li>
                 
                  <li class="nav-item dropdown">
                    <a >
                        <img src={rodape} class="iconLogo" align="right" />      
                    </a>
                  </li>
                </ul>
              </div>
          </div> 
          </nav>
           <div class="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
              <div class="logo">
            <a  class="simple-text logo-normal">
              <img src={rodape} class="ImagemLogo" align="left" />            
            </a>
            <a  class="simple-text logo-normal">
              <p class="NomePrest">Cantos dos Bichos</p>
              <p class="TipoPrest">PetShop</p>
            </a>
          </div>
          <div class="sidebar-wrapper">
            <ul class="nav">
              <li class="nav-item active  ">
                <a class="nav-link" href="./dashboard.html">
                  <i class="material-icons">dashboard</i>
                  <p>Inicio</p>
                </a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="./user.html">
                  <i class="material-icons">event</i>
                  <p>Calendário</p>
                </a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="./tables.html">
                  <i class="material-icons">assignment_ind</i>
                  <p>Funcionários</p>
                </a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="./typography.html">
                  <i class="material-icons">shopping_cart</i>
                  <p>Shopping</p>
                </a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="./icons.html">
                  <i class="material-icons">alarm</i>
                  <p>Horários</p>
                </a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="./map.html">
                  <i class="material-icons">account_circle</i>
                  <p>Editar Perfil</p>
                </a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="./notifications.html">
                  <i class="material-icons">assignment</i>
                  <p>Prontuários</p>
                </a>
              </li>
              <li class="nav-item active-pro ">
                <a class="nav-link" style={{background:'none'}}>
                    <table>
                        <tr>
                            <td style={{width: '20%'}}>
                                <img src={rodape2} class="material-icons"/>
                            </td>
                            <td style={{width: '80%'}}>
                                <p style={{color:'#009fe3'}}>Versão 1.0</p>
                            </td>
                        </tr>
                    </table>
                
                </a>
              </li>
            </ul>
          </div>
        </div> *
        <div class="card" style={{marginTop:'0px',marginBottom:'0px'}}>
                    <div class="card-body">
                      <div class="tab-content">
                        <div class="tab-pane active" id="profile">
                            <div style={{width:'100%', height:'400px'}}>
                                <img src={Blabala} style={{width: '100%',height: '100%'}}/>
                            </div>
                        </div>
                        <div class="tab-pane active" id="profile">
                            <div style={{width:'100%', height:'400px'}}>
                                <img src={Blabala} style={{width: '100%',height: '100%'}}/>
                            </div>
                        </div>
                        <div class="tab-pane" id="messages">
                          <table class="table">
                            <tbody>
                              <tr>
                                <td>
                                  <div class="form-check">
                                    <label class="form-check-label">
                                      <input class="form-check-input" type="checkbox" value="" checked/>
                                      <span class="form-check-sign">
                                        <span class="check"></span>
                                      </span>
                                    </label>
                                  </div>
                                </td>
                                <td>Flooded: One year later, assessing what was lost and what was found when a ravaging rain swept through metro Detroit
                                </td>
                                <td class="td-actions text-right">
                                  <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                    <i class="material-icons">edit</i>
                                  </button>
                                  <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                    <i class="material-icons">close</i>
                                  </button>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="form-check">
                                    <label class="form-check-label">
                                      <input class="form-check-input" type="checkbox" value=""/>
                                      <span class="form-check-sign">
                                        <span class="check"></span>
                                      </span>
                                    </label>
                                  </div>
                                </td>
                                <td>Sign contract for "What are conference organizers afraid of?"</td>
                                <td class="td-actions text-right">
                                  <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                    <i class="material-icons">edit</i>
                                  </button>
                                  <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                    <i class="material-icons">close</i>
                                  </button>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div> */}
                        {/* <div class="tab-pane" id="settings">
                          <table class="table">
                            <tbody>
                              <tr>
                                <td>
                                  <div class="form-check">
                                    <label class="form-check-label">
                                      <input class="form-check-input" type="checkbox" value=""/>
                                      <span class="form-check-sign">
                                        <span class="check"></span>
                                      </span>
                                    </label>
                                  </div>
                                </td>
                                <td>Lines From Great Russian Literature? Or E-mails From My Boss?</td>
                                <td class="td-actions text-right">
                                  <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                    <i class="material-icons">edit</i>
                                  </button>
                                  <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                    <i class="material-icons">close</i>
                                  </button>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="form-check">
                                    <label class="form-check-label">
                                      <input class="form-check-input" type="checkbox" value="" checked/>
                                      <span class="form-check-sign">
                                        <span class="check"></span>
                                      </span>
                                    </label>
                                  </div>
                                </td>
                                <td>Flooded: One year later, assessing what was lost and what was found when a ravaging rain swept through metro Detroit
                                </td>
                                <td class="td-actions text-right">
                                  <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                    <i class="material-icons">edit</i>
                                  </button>
                                  <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                    <i class="material-icons">close</i>
                                  </button>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <div class="form-check">
                                    <label class="form-check-label">
                                      <input class="form-check-input" type="checkbox" value="" checked/>
                                      <span class="form-check-sign">
                                        <span class="check"></span>
                                      </span>
                                    </label>
                                  </div>
                                </td>
                                <td>Sign contract for "What are conference organizers afraid of?"</td>
                                <td class="td-actions text-right">
                                  <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                    <i class="material-icons">edit</i>
                                  </button>
                                  <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                    <i class="material-icons">close</i>
                                  </button>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div> 
                      </div>
                    </div>
                  </div>*/}
               
                {/* <div class="col-lg-4 col-md-12">
                  <div class="card">
                    <div class="card-body table-responsive">
                      <table class="table table-hover " >
                        <tbody>
                            <tr style={{width: '100%',background:'none'}}>      
                                <td style={{paddingBottom:'03px'}}>   
                                    <p className="TituloDet" >   
                                    Sobre Bernado
                                    </p>                          
                                </td>                        
                            </tr>
                            <tr style={{width: '100%',background:'none'}}>      
                                <td style={{paddingBottom:'03px'}}>                                   
                                    <i class="material-icons" style={{position:'absolute',color:'#009fe3'}}>edit</i> <p className="InfoDet" > São bernado </p>                          
                                </td>                        
                            </tr>
                            <tr style={{width: '100%',background:'none'}}>      
                                <td style={{paddingBottom:'03px'}}>                                  
                                    <i class="material-icons" style={{position:'absolute',color:'#009fe3'}}>edit</i> <p className="InfoDet" > Macho </p>                          
                                </td>                        
                            </tr>
                            <tr style={{width: '100%',background:'none'}}>      
                                <td style={{paddingBottom:'03px'}}>                                  
                                    <i class="material-icons" style={{position:'absolute',color:'#009fe3'}}>edit</i> <p className="InfoDet" > 17/02/2017 </p>                          
                                </td>                        
                            </tr>
                            <tr style={{width: '100%',background:'none'}}>      
                                <td>                                  
                                    <i class="material-icons" style={{position:'absolute',color:'#009fe3'}}>edit</i> <p className="InfoDet" > Castrado </p>                          
                                </td>                        
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>*/}
             

   
}