import React from 'react';
import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";

export default function CadastroProntuario(){

    var clinica = "Agenda Animal";
    var veterinario ="Fernanda Coelho";

    var VacSim ="Não";
    var VacNao ="Não";

    var MedSim ="Não";
    var MedNao ="Não";

    var ExSim ="Não";
    var ExNao ="Não";

    var ButtonImagem= "Não";
    var ButtonHematologico = "Não";
    var ButtonBioquimico = "Não";
    var ButtonParasitologico = "Não";
    var ButtonOutros = "Não";

    async function Salvar(){
        var tutor = document.getElementById("tutor").value;
        var pet = document.getElementById("pet").value;
        var date = document.getElementById("date").value;
        var rg = document.getElementById("rg").value;
        var erro = document.getElementById("valida");

        //////////////////////////////////////////////////////////    EXAMES HEMO       ////////////////////////////////////////////////////////////////
        var HemogramaCompleto = document.getElementById("HemogramaCompleto");
        var Fribrinogenio = document.getElementById("Fribrinogenio");
        var PesquisaHemoparasitas = document.getElementById("PesquisaHemoparasitas");
        var FuncaoHepatica = document.getElementById("FuncaoHepatica");
        var SorologicoFIVFELV = document.getElementById("SorologicoFIVFELV");

        
        //////////////////////////////////////////////////////////    EXAMES IMAGEM       ////////////////////////////////////////////////////////////////
        var RadiologiaSimples = document.getElementById("RadiologiaSimples");
        var RadiologiaContrastada = document.getElementById("RadiologiaContrastada");
        var Eletrocardiograma = document.getElementById("Eletrocardiograma");
        var UltrassonografiAbdominal = document.getElementById("UltrassonografiAbdominal");

        //////////////////////////////////////////////////////////    EXAMES PARASITOLOGICO       ////////////////////////////////////////////////////////////
        var Fezes = document.getElementById("Fezes");

        //////////////////////////////////////////////////////////    EXAMES OUTROS       ////////////////////////////////////////////////////////////////
        var ExameTumoral = document.getElementById("ExameTumoral");
        var ExameGinecologico = document.getElementById("ExameGinecologico");
        var GlicemiaJejum = document.getElementById("GlicemiaJejum");
        var Biopsia = document.getElementById("Biopsia");
        var SexagemAves = document.getElementById("SexagemAves");

          //////////////////////////////////////////////////////////    EXAMES BIOQUIMICO       ////////////////////////////////////////////////////////////////
          var Urina = document.getElementById("Urina");
          var AcidoUrico = document.getElementById("AcidoUrico");
          var Albumina = document.getElementById("Albumina");
          var ALT = document.getElementById("ALT");
          var Amilase = document.getElementById("Amilase");
           var AST = document.getElementById("AST");
          var Bilirrubina = document.getElementById("Bilirrubina");
          var CalcioSerico = document.getElementById("CalcioSerico");
          var Colesterol = document.getElementById("Colesterol");
          var Colinesterase = document.getElementById("Colinesterase");
          var CreatinaQuinase = document.getElementById("CreatinaQuinase");
          var Creatinina = document.getElementById("Creatinina");
          var FerroSerico = document.getElementById("FerroSerico");
          var FosfataseAlcalina = document.getElementById("FosfataseAlcalina");
          var Fosforo = document.getElementById("Fosforo");
          var Gama = document.getElementById("Gama");
          var Glicose = document.getElementById("Glicose");
          var Magnesio = document.getElementById("Magnesio");
          var ProteinasTotais = document.getElementById("ProteinasTotais");
          var NAKCL = document.getElementById("NAKCL");
          var Triglicerideos = document.getElementById("Triglicerideos");
          var Ureia = document.getElementById("Ureia");

        
        if (tutor === "" || tutor === null || tutor === undefined) {
    
            erro.innerHTML = "Preencha o campo Nome Tutor";
        }
        else{
            if (pet === "" || pet === null || pet === undefined) {
    
                erro.innerHTML = "Preencha o campo Nome do Pet";
            }else{
                if (rg === "" || rg === null || rg === undefined) {
    
                    erro.innerHTML = "Preencha o campo Rg Animal";
                }
                else{
                    if (date === "" || date === null || date === undefined) {
        
                        erro.innerHTML = "Preencha o campo Data";
                    }
                    else{
                        erro.innerHTML ="";

                        var DataAtual = new Date()
                        var MesAtual = DataAtual.getMonth() + 1;                                        
                        var AnoAtual = DataAtual.getFullYear();
                        var DiaAtual= DataAtual.getDate();
                        if(MesAtual < 10){
                            MesAtual="0" + MesAtual;
                        }
                        var DataCorreta = AnoAtual + "-"+ MesAtual +"-"+ DiaAtual;

                        if(date > DataCorreta){
                            erro.innerHTML = "O data deve ser menor ou igual a de hoje";
                        }
                        else{
                            if(VacSim === "Sim" && VacNao === "Sim"){
                                erro.innerHTML = "Escolha apenas uma opção na vacina";
                                var buttonVacSim = document.getElementById("VacSim");
                                    buttonVacSim.style.backgroundColor="#fff";
                                    buttonVacSim.style.border="1px solid #009fe3"; 
                                    buttonVacSim.style.color="#009fe3";        
                                    VacSim="Não";
    
                                    var buttonVacNao = document.getElementById("VacNao");
                                    buttonVacNao.style.backgroundColor="#fff";
                                    buttonVacNao.style.border="1px solid #009fe3"; 
                                    buttonVacNao.style.color="#009fe3";  
                                    VacNao="Não";
                            }
                            else{
                                if(VacSim === "Não" && VacNao === "Não"){
                                    erro.innerHTML = "Escolha pelo menos uma opção na vacina";
                                    var buttonVacSimm = document.getElementById("VacSim");
                                    buttonVacSimm.style.backgroundColor="#fff";
                                    buttonVacSimm.style.border="1px solid #009fe3"; 
                                    buttonVacSimm.style.color="#009fe3";        
                                    VacSim="Não";
    
                                    var buttonVacNaoo = document.getElementById("VacNao");
                                    buttonVacNaoo.style.backgroundColor="#fff";
                                    buttonVacNaoo.style.border="1px solid #009fe3"; 
                                    buttonVacNaoo.style.color="#009fe3";  
                                    VacNao="Não";
                                }
                                else{
                                    if(MedSim === "Sim" && MedNao === "Sim"){
                                        erro.innerHTML = "Escolha apenas uma opção na medicação";
                                        var buttonMedSim = document.getElementById("MedSim");
                                        buttonMedSim.style.backgroundColor="#fff";
                                        buttonMedSim.style.border="1px solid #009fe3"; 
                                        buttonMedSim.style.color="#009fe3";        
                                        MedSim="Não";
        
                                        var buttonMedNao = document.getElementById("MedNao");
                                        buttonMedNao.style.backgroundColor="#fff";
                                        buttonMedNao.style.border="1px solid #009fe3"; 
                                        buttonMedNao.style.color="#009fe3";  
                                        MedNao="Não";
                                    }
                                    else{
                                        if(MedSim === "Não" && MedNao === "Não"){
                                            erro.innerHTML = "Escolha pelo menos uma opção de medicação";
                                            var buttonMedSimm = document.getElementById("MedSim");
                                            buttonMedSimm.style.backgroundColor="#fff";
                                            buttonMedSimm.style.border="1px solid #009fe3"; 
                                            buttonMedSimm.style.color="#009fe3";        
                                            MedSim="Não";
            
                                            var buttonMedNaoo = document.getElementById("MedNao");
                                            buttonMedNaoo.style.backgroundColor="#fff";
                                            buttonMedNaoo.style.border="1px solid #009fe3"; 
                                            buttonMedNaoo.style.color="#009fe3";  
                                            MedNao="Não";
                                        }
                                        else{
                                            if(ExSim === "Sim" && ExNao === "Sim"){
                                                erro.innerHTML = "Escolha apenas uma opção no exame";
                                                var buttonExeSim = document.getElementById("ExSim");
                                                buttonExeSim.style.backgroundColor="#fff";
                                                buttonExeSim.style.border="1px solid #009fe3"; 
                                                buttonExeSim.style.color="#009fe3";        
                                                ExSim="Não";
                
                                                var buttonExeNao = document.getElementById("ExNao");
                                                buttonExeNao.style.backgroundColor="#fff";
                                                buttonExeNao.style.border="1px solid #009fe3"; 
                                                buttonExeNao.style.color="#009fe3";  
                                                ExNao="Não";
                                            }
                                            else{
                                                if(ExSim === "Não" && ExNao === "Não"){
                                                    erro.innerHTML = "Escolha pelo menos uma opção de exame";
                                                    var buttonExeSimm = document.getElementById("ExSim");
                                                    buttonExeSimm.style.backgroundColor="#fff";
                                                    buttonExeSimm.style.border="1px solid #009fe3"; 
                                                    buttonExeSimm.style.color="#009fe3";        
                                                    ExSim="Não";
                    
                                                    var buttonExeNaoo = document.getElementById("ExNao");
                                                    buttonExeNaoo.style.backgroundColor="#fff";
                                                    buttonExeNaoo.style.border="1px solid #009fe3"; 
                                                    buttonExeNaoo.style.color="#009fe3";  
                                                    ExNao="Não";
                                                }
                                                else{
                                                    if(ExSim === "Sim"){
                                                        if(ButtonImagem === "Não" && ButtonHematologico === "Não" && ButtonBioquimico === "Não" && ButtonParasitologico === "Não" && ButtonOutros === "Não" ){
                                                            erro.innerHTML = "Escolha pelo menos uma opção de exame";
                                                            var buttonImagemm = document.getElementById("Imagem");
                                                            buttonImagemm.style.backgroundColor="#fff";
                                                            buttonImagemm.style.border="1px solid #009fe3"; 
                                                            buttonImagemm.style.color="#009fe3";  
                                                            ButtonImagem="Não";
                                                            var DivImagem = document.getElementById("DivImagem");
                                                            DivImagem.style.display="none";


                                                            var buttonHematologicoo = document.getElementById("Hematologico");
                                                            buttonHematologicoo.style.backgroundColor="#fff";
                                                            buttonHematologicoo.style.border="1px solid #009fe3"; 
                                                            buttonHematologicoo.style.color="#009fe3";  
                                                            ButtonHematologico="Não";
                                                            var DivHematologico = document.getElementById("DivHematologico");
                                                            DivHematologico.style.display="none";


                                                            var buttonBioquimicoo = document.getElementById("Bioquimico");
                                                            buttonBioquimicoo.style.backgroundColor="#fff";
                                                            buttonBioquimicoo.style.border="1px solid #009fe3"; 
                                                            buttonBioquimicoo.style.color="#009fe3";  
                                                            ButtonBioquimico="Não";
                                                            var DivBioquimico = document.getElementById("DivBioquimico");
                                                            DivBioquimico.style.display="none";


                                                            var buttonParasitologicoo = document.getElementById("Parasitologico");
                                                            buttonParasitologicoo.style.backgroundColor="#fff";
                                                            buttonParasitologicoo.style.border="1px solid #009fe3"; 
                                                            buttonParasitologicoo.style.color="#009fe3";  
                                                            ButtonParasitologico="Não";
                                                            var DivParasitologico = document.getElementById("DivParasitologico");
                                                            DivParasitologico.style.display="none";


                                                            var buttonOutross = document.getElementById("Outros");
                                                            buttonOutross.style.backgroundColor="#fff";
                                                            buttonOutross.style.border="1px solid #009fe3"; 
                                                            buttonOutross.style.color="#009fe3";  
                                                            ButtonOutros="Não";
                                                            var DivOutros = document.getElementById("DivOutros");
                                                            DivOutros.style.display="none";
                                                        }
                                                        else{
                                                            if(ButtonImagem === "Sim" || ButtonHematologico === "Sim" || ButtonBioquimico === "Sim" || ButtonParasitologico === "Sim" || ButtonOutros === "Sim" ) {

                                                                var OpcaoImagem= "Não";
                                                                var OpcaoHematologico = "Não";
                                                                var OpcaoBioquimico= "Não";
                                                                var OpcaoParasitologico = "Não";
                                                                var OpcaoOutros= "Não";

                                                                if(ButtonHematologico === "Sim"){
                                                                    if(HemogramaCompleto.checked === false && Fribrinogenio.checked === false &&PesquisaHemoparasitas.checked === false && FuncaoHepatica.checked === false &&  SorologicoFIVFELV.checked === false){
                                                                        erro.innerHTML = "Escolha pelo menos uma opção de exame Hematologico";
                                                                        OpcaoHematologico = "Pendente";
                                                                    }
                                                                    else{
                                                                        OpcaoHematologico = "Sim";
                                                                    }
                                                                }else{
                                                                    OpcaoHematologico = "Não";
                                                                }

                                                                if(ButtonImagem === "Sim") {
                                                                    if(RadiologiaSimples.checked === false && RadiologiaContrastada.checked === false && Eletrocardiograma.checked === false && UltrassonografiAbdominal.checked === false){
                                                                        erro.innerHTML = "Escolha pelo menos uma opção de exame Imagem";
                                                                        OpcaoImagem= "Pendente";
                                                                    }else{
                                                                        OpcaoImagem= "Sim";
                                                                    }
                                                                }
                                                                else{
                                                                    OpcaoImagem= "Não";
                                                                }

                                                                if(ButtonParasitologico === "Sim") {
                                                                    if(Fezes.checked === false){
                                                                        erro.innerHTML = "Escolha pelo menos uma opção de exame Parasitologico ";
                                                                        OpcaoParasitologico= "Pendente";
                                                                    }else{
                                                                        OpcaoParasitologico= "Sim";
                                                                    }
                                                                }
                                                                else{
                                                                    OpcaoParasitologico= "Não";
                                                                }

                                                                if(ButtonOutros === "Sim"){
                                                                    if(ExameTumoral.checked === false && ExameGinecologico.checked === false && GlicemiaJejum.checked === false && Biopsia.checked === false && SexagemAves.checked === false){
                                                                        erro.innerHTML = "Escolha pelo menos uma opção de exame Outros";
                                                                        OpcaoOutros= "Pendente";
                                                                    }else{
                                                                        OpcaoOutros= "Sim";
                                                                    }
                                                                }
                                                                else{
                                                                    OpcaoOutros= "Não";
                                                                }                                                               

                                                                if(ButtonBioquimico === "Sim"){
                                                                    if(Urina.checked === false && AcidoUrico.checked === false && Albumina.checked === false && ALT.checked === false && Amilase.checked === false && AST.checked === false && Bilirrubina.checked === false && CalcioSerico.checked === false && Colesterol.checked === false && Colinesterase.checked === false && CreatinaQuinase.checked === false && Creatinina.checked === false && FerroSerico.checked === false && FosfataseAlcalina.checked === false && Fosforo.checked === false && Gama.checked === false && Glicose.checked === false && Magnesio.checked === false && ProteinasTotais.checked === false && NAKCL.checked === false && Triglicerideos.checked === false && Ureia.checked === false){
                                                                        erro.innerHTML = "Escolha pelo menos uma opção de exame Bioquimico";
                                                                        OpcaoBioquimico= "Pendente";
                                                                    }else{
                                                                        OpcaoBioquimico= "Sim";
                                                                    }
                                                                }
                                                                else{
                                                                    OpcaoBioquimico= "Não";
                                                                }

                                                                if( OpcaoBioquimico === "Pendente" || OpcaoOutros === "Pendente" || OpcaoParasitologico === "Pendente" || OpcaoHematologico === "Pendente" || OpcaoImagem === "Pendente" ){
                                                                    erro.innerHTML = "Verifique se nenhum exame esta vazio";
                                                                }

                                                                else if( OpcaoBioquimico === "Sim" || OpcaoOutros === "Sim" || OpcaoParasitologico === "Sim" || OpcaoHematologico === "Sim" || OpcaoImagem === "Sim"){                                                                
                                                                    erro.innerHTML = "Fimmmmm";
                                                                    alert("ooi")
                                                                }
                                                            }
                                                            else{
                                                                erro.innerHTML = "Fimmmmm";
                                                                alert("ooi")
                                                            }
                                                        }                                                
                                                    }
                                                    else{
                                                        erro.innerHTML = "Fimmmmm";
                                                        alert("ooi")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }            
        }
    }


    function VacinaSim(){
        var button = document.getElementById("VacSim");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";        
        VacSim="Sim";

        let a= document.createElement('a');
        a.target= '_blank';
        a.href= '/CadastroVacina';
        a.click();        
    }

    function VacinaNao(){
        var button = document.getElementById("VacNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        VacNao="Sim";
    }

    function MedicaSim(){
        var button = document.getElementById("MedSim");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";        
        MedSim="Sim";

        let a= document.createElement('a');
        a.target= '_blank';
        a.href= '/CadastroMedicacao';
        a.click();        
    }

    function MedicaNao(){
        var button = document.getElementById("MedNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        MedNao="Sim";
    }

    function ExameSim(){
        var button = document.getElementById("ExSim");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";        
        ExSim="Sim";  
        
        var div = document.getElementById("Div");
        div.style.display="block";
    }

    function ExameNao(){
        var button = document.getElementById("ExNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ExNao="Sim";
    }

    function Hematologico(){
        var button = document.getElementById("DivHematologico");
        button.style.display="block";
        ButtonHematologico = "Sim";

        var button2 = document.getElementById("Hematologico");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Imagem(){
        var button = document.getElementById("DivImagem");
        button.style.display="block";
        ButtonImagem = "Sim";
        
        var button2 = document.getElementById("Imagem");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Bioquimico(){
        var button = document.getElementById("DivBioquimico");
        button.style.display="block";
        ButtonBioquimico = "Sim";

        var button2 = document.getElementById("Bioquimico");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Parasitologico(){
        var button = document.getElementById("DivParasitologico");
        button.style.display="block";
        ButtonParasitologico = "Sim";
        
        var button2 = document.getElementById("Parasitologico");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Outros(){
        var button = document.getElementById("DivOutros");
        button.style.display="block";
        ButtonOutros = "Sim";

        var button2 = document.getElementById("Outros");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    return(

    <div>
        <div className="wrapper ">
            <div className="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                <div className="logo">
                    <a  className="simple-text logo-normal">
                        <img alt="" src={rodape} className="ImagemLogo" align="left" />            
                    </a>
                    <a  className="simple-text logo-normal">
                        <p className="NomePrest">Cantos dos Bichos</p>
                        <p className="TipoPrest">PetShop</p>
                    </a>
                </div>
                <div className="sidebar-wrapper">
                    <ul className="nav">
                        <li className="nav-item active  ">
                            <a className="nav-link" href="./dashboard.html">
                            <i className="material-icons">dashboard</i>
                            <p>Inicio</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./user.html">
                            <i className="material-icons">event</i>
                            <p>Calendário</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./tables.html">
                            <i className="material-icons">assignment_ind</i>
                            <p>Funcionários</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./typography.html">
                            <i className="material-icons">shopping_cart</i>
                            <p>Shopping</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./icons.html">
                            <i className="material-icons">alarm</i>
                            <p>Horários</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./map.html">
                            <i className="material-icons">account_circle</i>
                            <p>Editar Perfil</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./notifications.html">
                            <i className="material-icons">assignment</i>
                            <p>Prontuários</p>
                            </a>
                        </li>
                        <li className="nav-item active-pro ">
                            <a className="nav-link" style={{background:'none'}}>
                                <table>
                                    <tr>
                                        <td style={{width: '20%'}}>
                                            <img  alt="" src={rodape2} className="material-icons"/>
                                        </td>
                                        <td style={{width: '80%'}}>
                                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                                        </td>
                                    </tr>
                                </table>            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>    
            <div className="main-panel">
                <nav className="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                    <div className="container-fluid">
                        <div className="navbar-wrapper">
                            <a className="navbar-brand" href="#pablo" style={{fontSize:'21px'}}>Cadastro Prontuários</a>
                        </div>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="sr-only">Toggle navigation</span>
                            <span className="navbar-toggler-icon icon-bar"></span>
                            <span className="navbar-toggler-icon icon-bar"></span>
                            <span className="navbar-toggler-icon icon-bar"></span>
                        </button>
                        <div className="collapse navbar-collapse justify-content-end">
                            <ul className="navbar-nav">
                                <li className="nav-item dropdown">
                                    <a className="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i className="material-icons">notifications</i>
                                        <span className="notification">5</span>
                                        <p className="d-lg-none d-md-block">
                                            Some Actions
                                        </p>
                                    </a>
                                    <div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <a className="dropdown-item" href="#">Mike John responded to your email</a>
                                        <a className="dropdown-item" href="#">You have 5 new tasks</a>
                                        <a className="dropdown-item" href="#">You're now friend with Andrew</a>
                                        <a className="dropdown-item" href="#">Another Notification</a>
                                        <a className="dropdown-item" href="#">Another One</a>
                                    </div>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#pablo">
                                        <i className="material-icons">help_outline</i>
                                        <p className="d-lg-none d-md-block">
                                            Stats
                                        </p>
                                    </a>
                                </li>                                
                                <li className="nav-item dropdown">
                                    <a >
                                        <img  alt="" src={rodape} className="iconLogo" align="right" />      
                                    </a>                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>

                
                <div className="content">
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card">
                                    <div className="card-header card-header-blue">
                                        <h4 className="card-title">Prontuários</h4>
                                        <p className="card-category">Complete os Dados!</p>
                                    </div>
                                    <div className="card-body">
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="tutor" placeholder="Nome do Tutor"  />
                                                    </div>
                                                </div>  
                                                <div className="col-md-3">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control"  placeholder="Data" disabled/>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form-group">
                                                        <input type="date" id="date" className="form-control" />
                                                    </div>
                                                </div>                                             
                                            </div>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="pet" placeholder="Nome do Pet"/>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="rg" placeholder="RG do Animal"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="Clinica" value={clinica} placeholder="Clinica Veterinaria" style={{color:'#009fe3',fontWeight:'500'}} disabled/>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="veterinario" value={veterinario} style={{color:'#009fe3',fontWeight:'500'}} placeholder="Veterinario Responsavel" disabled/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/>
                                            <div className="row">
                                                <div className="col-md-6"> 
                                                <label className="bmd-label-floating">Vacinas</label>          
                                                        <button type="submit" className="btnCadFunc"  id="VacSim" onClick={VacinaSim} style={{width:'50px',marginLeft:'5%'}}>Sim</button>
                                                        <button type="submit" className="btnCadFunc" id="VacNao" onClick={VacinaNao} style={{width:'70px',marginLeft:'2%'}}>Não</button>
                                                </div>
                                                <div className="col-md-6">
                                                    <label className="bmd-label-floating">Medicações</label>                                                
                                                        <button type="submit" className="btnCadFunc" id="MedSim" onClick={MedicaSim} style={{width:'50px',marginLeft:'5%'}}>Sim</button>
                                                        <button type="submit" className="btnCadFunc" id="MedNao" onClick={MedicaNao} style={{width:'70px',marginLeft:'2%'}}>Não</button>
                                                </div>
                                            </div>  
                                            <br/>   
                                            <div className="row">
                                                <div className="col-md-6">
                                                <label className="bmd-label-floating">Exame</label>  
                                                        <button type="submit" className="btnCadFunc" id="ExSim" onClick={ExameSim} style={{width:'50px',marginLeft:'5%'}}>Sim</button>
                                                        <button type="submit" className="btnCadFunc" id="ExNao" onClick={ExameNao} style={{width:'70px',marginLeft:'2%'}}>Não</button>
                                                </div>
                                                <div className="col-md-6" style={{display:"none"}} id="Div">
                                                <label className="bmd-label-floating">Selecione Tipo de Exame</label>
                                                    <div className="row">
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Imagem" onClick={Imagem} style={{marginLeft:'2%'}}>Imagem</button>
                                                        </div> 
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Hematologico" onClick={Hematologico} style={{marginLeft:'2%'}}>Hematologico</button>
                                                        </div> 
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Bioquimico" onClick={Bioquimico} style={{marginLeft:'2%'}}>Bioquimico</button>
                                                        </div>                                                         
                                                    </div>
                                                    <div className="row" style={{marginTop:'2%'}}>
                                                        <div className="col-md-5">
                                                            <button type="submit" className="btnCadFunc" id="Parasitologico" onClick={Parasitologico} style={{marginLeft:'2%'}}>Parasitologico</button> 
                                                        </div> 
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Outros" onClick={Outros} style={{marginLeft:'2%'}}>Outros</button> 
                                                        </div>
                                                    </div> 
                                                </div>
                                            </div> 
                                            <br/>

                                            <div className="row">    
                                                
                                                
                                               
                                               

                                                

                                                <div className="col-md-2">
                                                    <div id="DivParasitologico" style={{display:'none'}}>    
                                                        <br/>
                                                        <p  style={{color:'black',marginBottom:'0px'}}> Exames Parasitologico:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                            <p  style={{color:'black',visibility:'collapse',marginBottom:'0px'}}> Dias</p>

                                                            <label className="dias">Parasitologico de fezes
                                                                <input type="checkbox" id="Fezes" />
                                                                <span className="checkmark"></span>
                                                            </label>                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="col-md-2">
                                                    <div id="DivImagem" style={{display:'none'}}>    
                                                        <br/>
                                                        <p  style={{color:'black',marginBottom:'0px'}}> Exames Imagem:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                            <p  style={{color:'black',visibility:'collapse',marginBottom:'0px'}}> Dias</p>

                                                            <label className="dias">Radiologia simples
                                                                <input type="checkbox" id="RadiologiaSimples" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Radiologia contrastada
                                                                <input type="checkbox" id="RadiologiaContrastada" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Eletrocardiograma
                                                                <input type="checkbox" id="Eletrocardiograma" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Ultrassonografia Abdominal 
                                                                <input type="checkbox" id="UltrassonografiAbdominal" />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="col-md-2">
                                                    <div id="DivHematologico" style={{display:'none'}}>  
                                                        <br/>
                                                        <p  style={{color:'black',marginBottom:'0px'}}> Exames Hematologico:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                            <p  style={{color:'black',visibility:'collapse',marginBottom:'0px'}}> Dias</p>

                                                            <label className="dias">Hemograma Completo
                                                                <input type="checkbox" id="HemogramaCompleto" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Fribrinogenio
                                                                <input type="checkbox" id="Fribrinogenio" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Pesquisa de Hemoparasitas
                                                                <input type="checkbox" id="PesquisaHemoparasitas" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Função Hepatica
                                                                <input type="checkbox" id="FuncaoHepatica" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Sorologico para FIV e FELV
                                                                <input type="checkbox" id="SorologicoFIVFELV" />
                                                                <span className="checkmark"></span>
                                                            </label>                                                            
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* <div className="col-md-2">
                                                    <div id="DivOutros" style={{display:'none'}}>    
                                                        <br/>
                                                        <p  style={{color:'black',marginBottom:'0px'}}> Exames Outros:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                            <p  style={{color:'black',visibility:'collapse',marginBottom:'0px'}}> Dias</p>

                                                            <label className="dias">Exame tumoral 
                                                                <input type="checkbox" id="ExameTumoral" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Exame ginecologico 
                                                                <input type="checkbox" id="ExameGinecologico" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Glicemia de jejum
                                                                <input type="checkbox" id="GlicemiaJejum" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Biopsia
                                                                <input type="checkbox" id="Biopsia" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Sexagem de Aves
                                                                <input type="checkbox" id="SexagemAves" />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div> */}

                                                <div className="col-md-2">
                                                    <div id="DivBioquimico" style={{display:'none'}}>    
                                                        <br/>
                                                        <p  style={{color:'black',marginBottom:'0px'}}> Exames Bioquimico:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                            <p  style={{color:'black',visibility:'collapse',marginBottom:'0px'}}> Dias</p>
                                                            <label className="dias">Urina - Rotina
                                                                <input type="checkbox" id="Urina" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Acido Úrico 
                                                                <input type="checkbox" id="AcidoUrico" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Albumina 
                                                                <input type="checkbox" id="Albumina" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">ALT (TGP)
                                                                <input type="checkbox" id="ALT" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Amilase
                                                                <input type="checkbox" id="Amilase" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">AST (TGO)
                                                                <input type="checkbox" id="AST" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Bilirrubina
                                                                <input type="checkbox" id="Bilirrubina" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Calcio sérico
                                                                <input type="checkbox" id="CalcioSerico" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Colesterol
                                                                <input type="checkbox" id="Colesterol" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Colinesterase 
                                                                <input type="checkbox" id="Colinesterase" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Creatina quinase (CK)
                                                                <input type="checkbox" id="CreatinaQuinase" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                           

                                                          
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-2">
                                                <br/>
                                                        <p  style={{color:'black',marginBottom:'0px',visibility:'hidden'}}> Exames Bioquimico:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                <label className="dias">Creatinina
                                                                <input type="checkbox" id="Creatinina" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Ferro sérico
                                                                <input type="checkbox" id="FerroSerico" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Fosfatase alcalina
                                                                <input type="checkbox" id="FosfataseAlcalina" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Fósforo
                                                                <input type="checkbox" id="Fosforo" />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                <label className="dias">Gama GT
                                                                <input type="checkbox" id="Gama" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Glicose 
                                                                <input type="checkbox" id="Glicose" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Magnésio
                                                                <input type="checkbox" id="Magnesio" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Proteínas totais
                                                                <input type="checkbox" id="ProteinasTotais" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Sódio (Na+), Potássio (K+) e Cloro (Cl-)
                                                                <input type="checkbox" id="NAKCL" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Triglicerídeos
                                                                <input type="checkbox" id="Triglicerideos" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Uréia
                                                                <input type="checkbox" id="Ureia" />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                        </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                            <div className="col-md-12">
                                                    <div id="DivOutros" style={{display:'none'}}>    
                                                        <br/>
                                                        <p  style={{color:'black',marginBottom:'0px'}}> Exames Outros:</p>
                                                        <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>
                                                            <p  style={{color:'black',visibility:'collapse',marginBottom:'0px'}}> Dias</p>

<div>
                                                            <div style={{width:'50%'}}>
                                                                 <label className="dias">Exame tumoral 
                                                                <input type="checkbox" id="ExameTumoral" />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                            </div>
                                                            <div style={{width:'50%'}}>
                                                            <input type="text" className="form-control"  placeholder="Data" />
                                                            </div>
                                                            </div>
                                                           

                                                            <label className="dias">Exame ginecologico 
                                                                <input type="checkbox" id="ExameGinecologico" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Glicemia de jejum
                                                                <input type="checkbox" id="GlicemiaJejum" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Biopsia
                                                                <input type="checkbox" id="Biopsia" />
                                                                <span className="checkmark"></span>
                                                            </label>

                                                            <label className="dias">Sexagem de Aves
                                                                <input type="checkbox" id="SexagemAves" />
                                                                <span className="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        
                                            <div className="row" style={{textAlign: '-webkit-center'}}>
                                                <div className="col-md-12">
                                                    <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="valida"></p>
                                                    <button type="submit" className="btn btn-primary" onClick={Salvar} style={{borderRadius: '30px',padding: '1% 5%'}}>Salvar</button>
                                                    <div className="clearfix"></div>
                                                </div>                                              
                                            </div>   
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div> 
            </div>
        </div>
    </div>
    )

   
}