import React from 'react';
import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";

export default function CadastroProntuario(){

    var clinica = "Agenda Animal";
    var veterinario ="Fernanda Coelho";

    var VacSim ="Não";
    var VacNao = "Não";
    var VacInfo = "Não";

    var MedSim ="Não";
    var MedNao ="Não";

    var ExSim ="Não";
    var ExNao ="Não";
    var MedInfo="Não";

    var ButtonImagem= "Não";
    var ButtonHematologico = "Não";
    var ButtonBioquimico = "Não";
    var ButtonParasitologico = "Não";
    var ButtonOutros = "Não";

    async function Salvar(){
        var tutor = document.getElementById("tutor").value;
        var pet = document.getElementById("pet").value;
        var date = document.getElementById("date").value;
        var rg = document.getElementById("rg").value;
        var erro = document.getElementById("valida");

        //////////////////////////////////////////////////////////    EXAMES HEMO       ////////////////////////////////////////////////////////////////
        // var HemogramaCompleto = document.getElementById("HemogramaCompleto");
        // var Fribrinogenio = document.getElementById("Fribrinogenio");
        // var PesquisaHemoparasitas = document.getElementById("PesquisaHemoparasitas");
        // var FuncaoHepatica = document.getElementById("FuncaoHepatica");
        // var SorologicoFIVFELV = document.getElementById("SorologicoFIVFELV");

        
        //////////////////////////////////////////////////////////    EXAMES IMAGEM       ////////////////////////////////////////////////////////////////
        var RadiologiaSimples = document.getElementById("RadiologiaSimples");
        var RadiologiaContrastada = document.getElementById("RadiologiaContrastada");
        var Eletrocardiograma = document.getElementById("Eletrocardiograma");
        var UltrassonografiAbdominal = document.getElementById("UltrassonografiAbdominal");

        //////////////////////////////////////////////////////////    EXAMES PARASITOLOGICO       ////////////////////////////////////////////////////////////
        var Fezes = document.getElementById("Fezes");

        //////////////////////////////////////////////////////////    EXAMES OUTROS       ////////////////////////////////////////////////////////////////
        // var ExameTumoral = document.getElementById("ExameTumoral");
        // var ExameGinecologico = document.getElementById("ExameGinecologico");
        // var GlicemiaJejum = document.getElementById("GlicemiaJejum");
        // var Biopsia = document.getElementById("Biopsia");
        // var SexagemAves = document.getElementById("SexagemAves");

          //////////////////////////////////////////////////////////    EXAMES BIOQUIMICO       ////////////////////////////////////////////////////////////////
        //   var Urina = document.getElementById("Urina");
        //   var AcidoUrico = document.getElementById("AcidoUrico");
        //   var Albumina = document.getElementById("Albumina");
        //   var ALT = document.getElementById("ALT");
        //   var Amilase = document.getElementById("Amilase");
        //   var AST = document.getElementById("AST");
        //   var Bilirrubina = document.getElementById("Bilirrubina");
        //   var CalcioSerico = document.getElementById("CalcioSerico");
        //   var Colesterol = document.getElementById("Colesterol");
        //   var Colinesterase = document.getElementById("Colinesterase");
        //   var CreatinaQuinase = document.getElementById("CreatinaQuinase");
        //   var Creatinina = document.getElementById("Creatinina");
        //   var FerroSerico = document.getElementById("FerroSerico");
        //   var FosfataseAlcalina = document.getElementById("FosfataseAlcalina");
        //   var Fosforo = document.getElementById("Fosforo");
        //   var Gama = document.getElementById("Gama");
        //   var Glicose = document.getElementById("Glicose");
        //   var Magnesio = document.getElementById("Magnesio");
        //   var ProteinasTotais = document.getElementById("ProteinasTotais");
        //   var NAKCL = document.getElementById("NAKCL");
        //   var Triglicerideos = document.getElementById("Triglicerideos");
        //   var Ureia = document.getElementById("Ureia");

        
        if (tutor === "" || tutor === null || tutor === undefined) {
    
            erro.innerHTML = "Preencha o campo Nome Tutor";
        }
        else{
            if (pet === "" || pet === null || pet === undefined) {
    
                erro.innerHTML = "Preencha o campo Nome do Pet";
            }else{
                if (rg === "" || rg === null || rg === undefined) {
    
                    erro.innerHTML = "Preencha o campo Rg Animal";
                }
                else{
                    if (date === "" || date === null || date === undefined) {
        
                        erro.innerHTML = "Preencha o campo Data";
                    }
                    else{
                        erro.innerHTML ="";

                        var DataAtual = new Date()
                        var MesAtual = DataAtual.getMonth() + 1;                                        
                        var AnoAtual = DataAtual.getFullYear();
                        var DiaAtual= DataAtual.getDate();
                        if(MesAtual < 10){
                            MesAtual="0" + MesAtual;
                        }
                        var DataCorreta = AnoAtual + "-"+ MesAtual +"-"+ DiaAtual;

                        if(date > DataCorreta){
                            erro.innerHTML = "O data deve ser menor ou igual a de hoje";
                        }
                        else{
                            if(VacSim === "Não" && VacNao === "Não"){
                                erro.innerHTML = "Escolha pelo menos uma opção na vacina";
                                var buttonVacSimm = document.getElementById("VacSim");
                                buttonVacSimm.style.backgroundColor="#fff";
                                buttonVacSimm.style.border="1px solid #009fe3"; 
                                buttonVacSimm.style.color="#009fe3";        
                                VacSim="Não";
                        
                                var div = document.getElementById("DivVacinaSim");
                                div.style.display="none";  
                        
                                var buttonVacNaoo = document.getElementById("VacNao");
                                buttonVacNaoo.style.backgroundColor="#fff";
                                buttonVacNaoo.style.border="1px solid #009fe3"; 
                                buttonVacNaoo.style.color="#009fe3";  
                                VacNao="Não";
                            }else{
                                if(VacSim === "Sim"){
                                    if(VacInfo === "Pendente"){
                                        SalvarVacina();   
                                    }                               
                                }
                                if(MedSim === "Não" && MedNao === "Não"){
                                    erro.innerHTML = "Escolha pelo menos uma opção de medicação";
                                    var buttonMedSimm = document.getElementById("MedSim");
                                    buttonMedSimm.style.backgroundColor="#fff";
                                    buttonMedSimm.style.border="1px solid #009fe3"; 
                                    buttonMedSimm.style.color="#009fe3";        
                                    MedSim="Não";
                        
                                    var div = document.getElementById("DivMedicacaoSim");
                                    div.style.display="none";  
                        
                                    var buttonMedNaoo = document.getElementById("MedNao");
                                    buttonMedNaoo.style.backgroundColor="#fff";
                                    buttonMedNaoo.style.border="1px solid #009fe3"; 
                                    buttonMedNaoo.style.color="#009fe3";  
                                    MedNao="Não";
                                }else{
                                    if(MedSim === "Sim"){
                                        if(MedInfo === "Pendente"){
                                            SalvarMed();   
                                        }                                                                         
                                    }

                                    if(MedInfo === "Pendente" || VacInfo === "Pendente"){
                                        erro.innerHTML = "Verifique os dados da vacina ou da medicação";
                                    }
                                    else{
                                        if(ExSim === "Sim" && ExNao === "Sim"){
                                            erro.innerHTML = "Escolha apenas uma opção no exame";
                                            var buttonExeSim = document.getElementById("ExSim");
                                            buttonExeSim.style.backgroundColor="#fff";
                                            buttonExeSim.style.border="1px solid #009fe3"; 
                                            buttonExeSim.style.color="#009fe3";        
                                            ExSim="Não";
                            
                                            var buttonExeNao = document.getElementById("ExNao");
                                            buttonExeNao.style.backgroundColor="#fff";
                                            buttonExeNao.style.border="1px solid #009fe3"; 
                                            buttonExeNao.style.color="#009fe3";  
                                            ExNao="Não";
                                        }
                                        else{
                                            if(ExSim === "Não" && ExNao === "Não"){
                                                erro.innerHTML = "Escolha pelo menos uma opção de exame";
                                                var buttonExeSimm = document.getElementById("ExSim");
                                                buttonExeSimm.style.backgroundColor="#fff";
                                                buttonExeSimm.style.border="1px solid #009fe3"; 
                                                buttonExeSimm.style.color="#009fe3";        
                                                ExSim="Não";
                            
                                                var buttonExeNaoo = document.getElementById("ExNao");
                                                buttonExeNaoo.style.backgroundColor="#fff";
                                                buttonExeNaoo.style.border="1px solid #009fe3"; 
                                                buttonExeNaoo.style.color="#009fe3";  
                                                ExNao="Não";
                                            }
                                            else{
                                                if(ExSim === "Sim"){
                                                    if(ButtonImagem === "Não" && ButtonHematologico === "Não" && ButtonBioquimico === "Não" && ButtonParasitologico === "Não" && ButtonOutros === "Não" ){
                            
                                                        erro.innerHTML = "Escolha pelo menos uma opção de exame";
                                                        var buttonImagemm = document.getElementById("Imagem");
                                                        buttonImagemm.style.backgroundColor="#fff";
                                                        buttonImagemm.style.border="1px solid #009fe3"; 
                                                        buttonImagemm.style.color="#009fe3";  
                                                        ButtonImagem="Não";
                                                        var DivImagem = document.getElementById("DivImagem");
                                                        DivImagem.style.display="none";
                            
                            
                                                        // var buttonHematologicoo = document.getElementById("Hematologico");
                                                        // buttonHematologicoo.style.backgroundColor="#fff";
                                                        // buttonHematologicoo.style.border="1px solid #009fe3"; 
                                                        // buttonHematologicoo.style.color="#009fe3";  
                                                        // ButtonHematologico="Não";
                                                        // var DivHematologico = document.getElementById("DivHematologico");
                                                        // DivHematologico.style.display="none";
                            
                            
                                                        // var buttonBioquimicoo = document.getElementById("Bioquimico");
                                                        // buttonBioquimicoo.style.backgroundColor="#fff";
                                                        // buttonBioquimicoo.style.border="1px solid #009fe3"; 
                                                        // buttonBioquimicoo.style.color="#009fe3";  
                                                        // ButtonBioquimico="Não";
                                                        // var DivBioquimico = document.getElementById("DivBioquimico");
                                                        // DivBioquimico.style.display="none";
                                                        // var DivBioquimico2 = document.getElementById("DivBioquimico2");
                                                        // DivBioquimico2.style.display="none";
                            
                            
                                                        var buttonParasitologicoo = document.getElementById("Parasitologico");
                                                        buttonParasitologicoo.style.backgroundColor="#fff";
                                                        buttonParasitologicoo.style.border="1px solid #009fe3"; 
                                                        buttonParasitologicoo.style.color="#009fe3";  
                                                        ButtonParasitologico="Não";
                                                        var DivParasitologico = document.getElementById("DivParasitologico");
                                                        DivParasitologico.style.display="none";
                            
                            
                                                        // var buttonOutross = document.getElementById("Outros");
                                                        // buttonOutross.style.backgroundColor="#fff";
                                                        // buttonOutross.style.border="1px solid #009fe3"; 
                                                        // buttonOutross.style.color="#009fe3";  
                                                        // ButtonOutros="Não";
                                                        // var DivOutros = document.getElementById("DivOutros");
                                                        // DivOutros.style.display="none";
                                                    }
                                                    else{
                                                        if(ButtonImagem === "Sim" || ButtonHematologico === "Sim" || ButtonBioquimico === "Sim" || ButtonParasitologico === "Sim" || ButtonOutros === "Sim" ) {
                                                            var erro = document.getElementById("valida");
                            
                                                            var OpcaoParasitologico = "Não";
                                                            var OpcaoImagem= "Não";
                            
                                                            if(ButtonParasitologico === "Sim") {
                                                                if(Fezes.checked === false){
                                                                    erro.innerHTML = "Escolha pelo menos uma opção de exame Parasitologico ";
                                                                    OpcaoParasitologico= "Pendente";
                                                                }else{
                                                                    OpcaoParasitologico= "Pendente";
                                                                    var InputFezes = document.getElementById("InputFezes");
                                                                    if(InputFezes.value === "" || InputFezes.value === null || InputFezes.value === undefined){
                                                                        erro.innerHTML = "Preencha a observação do exame de fezes."
                                                                    }else{
                                                                        OpcaoParasitologico= "Sim";
                                                                    }
                                                                }
                                                            }
                                                            else{
                                                                OpcaoParasitologico= "Não";
                                                            }
                            
                                                            if(ButtonImagem === "Sim") {
                                                                if(RadiologiaSimples.checked === false && RadiologiaContrastada.checked === false && Eletrocardiograma.checked === false && UltrassonografiAbdominal.checked === false){
                                                                    erro.innerHTML = "Escolha pelo menos uma opção de exame Imagem";
                                                                    OpcaoImagem= "Pendente";
                                                                }else{
                                                                    if(RadiologiaSimples.checked === true){
                                                                        OpcaoImagem= "Pendente";
                                                                        var InputRadiologiaSimples = document.getElementById("InputRadiologiaSimples");
                                                                        if(InputRadiologiaSimples.value === "" || InputRadiologiaSimples.value === null || InputRadiologiaSimples.value === undefined){
                                                                        }else{
                                                                            OpcaoImagem= "Sim";
                                                                        }
                                                                    }
                            
                                                                    if(RadiologiaContrastada.checked === true){
                                                                        OpcaoImagem= "Pendente";
                                                                        var InputRadiologiaContrastada = document.getElementById("InputRadiologiaContrastada");
                                                                        if(InputRadiologiaContrastada.value === "" || InputRadiologiaContrastada.value === null || InputRadiologiaContrastada.value === undefined){
                                                                            erro.innerHTML = "Preencha a observação do exame de RadiologiaContrastada."
                                                                        }else{
                                                                            OpcaoImagem= "Sim";
                                                                        }
                                                                    }
                            
                                                                    if(Eletrocardiograma.checked === true){
                                                                        OpcaoImagem= "Pendente";
                                                                        var InputEletrocardiograma = document.getElementById("InputEletrocardiograma");
                                                                        if(InputEletrocardiograma.value === "" || InputEletrocardiograma.value === null || InputEletrocardiograma.value === undefined){
                                                                            erro.innerHTML = "Preencha a observação do exame de Eletrocardiograma."
                                                                        }else{
                                                                            OpcaoImagem= "Sim";
                                                                        }
                                                                    }
                            
                                                                    if(UltrassonografiAbdominal.checked === true){
                                                                        OpcaoImagem= "Pendente";
                                                                        var InputUltrassonografiAbdominal = document.getElementById("InputUltrassonografiAbdominal");
                                                                        if(InputUltrassonografiAbdominal.value === "" || InputUltrassonografiAbdominal.value === null || InputUltrassonografiAbdominal.value === undefined){
                                                                            erro.innerHTML = "Preencha a observação do exame de Ultrassonografia Abdominal."
                                                                        }else{
                                                                            OpcaoImagem= "Sim";
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            else{
                                                                OpcaoImagem= "Não";
                                                            }
                            
                                                            if(OpcaoParasitologico === "Pendente" ||  OpcaoImagem === "Pendente" ){
                                                                // OpcaoBioquimico === "Pendente" || OpcaoOutros === "Pendente" || OpcaoHematologico === "Pendente" ||
                                                                erro.innerHTML = "Verifique se nenhum exame esta vazio";
                                                            }
                                                            
                                                            else if( OpcaoParasitologico === "Sim" ||  OpcaoImagem === "Sim"){        
                                                                // OpcaoBioquimico === "Sim" || OpcaoOutros === "Sim" ||OpcaoHematologico === "Sim" ||                                                        
                                                                erro.innerHTML = "Fimmmmm";
                                                                alert("tchau")
                                                            }
                            
                                                        
                            
                                                        }
                            
                            
                                                    }                                         
                                                }
                                                else{
                                                    erro.innerHTML = "Fimmmmm";
                                                    alert("ooi")
                                                }
                                            }
                                        }
                                    }
                                }
                            }                     
                        }
                    }
                }
            }            
        }
    }

/////////////////////////////////////////////////////////////////////  VACINA /////////////////////////////////////////////////////////////////////
    function VacinaSim(){
        var button = document.getElementById("VacSim");
        button.style.display = "none";      
        VacSim="Sim";
        VacInfo = "Não";

        var div = document.getElementById("DivVacinaSim");
        div.style.display="block";  

        var buttonNao = document.getElementById("VacNao")
        buttonNao.style.display = "none";

        VacInfo = "Pendente";
    }

    function VacinaNao(){
        var button = document.getElementById("VacNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        VacNao="Sim";
        VacInfo = "Não";
    }

    async function SalvarVacina(){
        VacInfo = "Pendente";
        var nome = document.getElementById("nome");
        var valor = document.getElementById("valor");
        var lote = document.getElementById("lote");
        var dose = document.getElementById("dose");
        var rg = document.getElementById("rgVacina");
        var dataIni = document.getElementById("dataIni");
        var dataProx = document.getElementById("dataProx");
        var erro = document.getElementById("validaVacina");
        
        if (nome.value === "" || nome.value === null || nome.value === undefined) {
    
            erro.innerHTML = "Preencha o campo Nome";
            return false;   
        }
        else{
            if (valor.value === "" || valor.value === null || valor.value === undefined) {
    
                erro.innerHTML = "Preencha o campo de Valor";
                return false;   
            }
            else{
                if (lote.value === "" || lote.value === null || lote.value === undefined) {
    
                    erro.innerHTML = "Preencha o campo Lote";
                    return false;   
                }
                else{
                    if (dose.value === "" || dose.value === null || dose.value === undefined) {
        
                        erro.innerHTML = "Preencha o campo da Dose";
                        return false;   
                    }
                    else{
                        if (rg.value === "" || rg.value === null || rg.value === undefined) {
            
                            erro.innerHTML = "Preencha o campo do Rg Animal";
                            return false;   
                        }
                        else{
                            if (dataIni.value === "" || dataIni.value === null || dataIni.value === undefined) {
                
                                erro.innerHTML = "Preencha o campo Data Aplicada";
                                return false;   
                            }
                            else{
                                if (dataProx.value === "" || dataProx === null || dataProx.value === undefined) {
                    
                                    erro.innerHTML = "Preencha o campo Proxima data";
                                    return false;   
                                }
                                else{
                                    if (dataProx.value < dataIni.value)
                                    {
                                        erro.innerHTML = "A data de proxima dose deve ser mais do que a de inicio";
                                        return false;   
                                    }
                                    else{
                                        erro.innerHTML ="Vacina Cadastrada com Sucesso";
                                        nome.setAttribute("disabled", "disabled");
                                        valor.setAttribute("disabled", "disabled");
                                        lote.setAttribute("disabled", "disabled");
                                        dose.setAttribute("disabled", "disabled");
                                        rg.setAttribute("disabled", "disabled");
                                        dataIni.setAttribute("disabled", "disabled");
                                        dataProx.setAttribute("disabled", "disabled");
                                        VacInfo = "Sim";
                                        var ButtonVacina = document.getElementById("ButtonVacina");
                                        ButtonVacina.style.display="none";
                                        return true;   
                                        
                                    }
                                }
                            }
                        }
                    }
                }
                
            }
        }
        
    }

    /////////////////////////////////////////////////////////////////////  MEDICAÇÃO /////////////////////////////////////////////////////////////////////

    function MedicaSim(){
        var button = document.getElementById("MedSim");
        button.style.display = "none";        
        MedSim="Sim";       

        var div = document.getElementById("DivMedicacaoSim");
        div.style.display="block"; 

        var buttonNao = document.getElementById("MedNao");
        buttonNao.style.display = "none"; 
        MedInfo = "Pendente";   
 
    }

    function MedicaNao(){
        var button = document.getElementById("MedNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        MedNao="Sim";
    }

    async function SalvarMed(){
        MedInfo = "Pendente";
        var nome = document.getElementById("nomeMed");
        var observ = document.getElementById("observMed");
        var lote = document.getElementById("loteMed");
        var dose = document.getElementById("doseMed");
        var rg = document.getElementById("rgMed");
        var dataIni = document.getElementById("dataAtual");
        var dataProx = document.getElementById("dataDoseProx");
        var erro = document.getElementById("validaMed");
        
        if (nome.value === "" || nome.value === null || nome.value === undefined) {
    
            erro.innerHTML = "Preencha o campo Nome";
            return false;  
        }
        else{
            if (observ.value === "" || observ.value === null || observ.value === undefined) {
    
                erro.innerHTML = "Preencha o campo de Observação";
                return false;  
            }
            else{
                if (lote.value === "" || lote.value === null || lote.value === undefined) {
    
                    erro.innerHTML = "Preencha o campo Lote";
                    return false;  
                }
                else{
                    if (dose.value === "" || dose.value === null || dose.value === undefined) {
        
                        erro.innerHTML = "Preencha o campo da Dose";
                        return false;  
                    }
                    else{
                        if (rg.value === "" || rg.value === null || rg.value === undefined) {
            
                            erro.innerHTML = "Preencha o campo do Rg Animal";
                            return false;  
                        }
                        else{
                            if (dataIni.value === "" || dataIni.value === null || dataIni.value === undefined) {
                
                                erro.innerHTML = "Preencha o campo Data de Inicio";
                                return false;  
                            }
                            else{
                                if (dataProx.value === "" || dataProx.value === null || dataProx.value === undefined) {
                    
                                    erro.innerHTML = "Preencha o campo Proxima data";
                                    return false;  
                                }
                                else{
                                    if (dataProx.value < dataIni.value)
                                    {
                                        erro.innerHTML = "A data de proxima dose deve ser mais do que a de inicio";
                                        return false;  
                                    }
                                    else{
                                        erro.innerHTML ="Medicação cadastrada com sucesso";
                                        nome.setAttribute("disabled", "disabled");
                                        observ.setAttribute("disabled", "disabled");
                                        lote.setAttribute("disabled", "disabled");
                                        dose.setAttribute("disabled", "disabled");
                                        rg.setAttribute("disabled", "disabled");
                                        dataIni.setAttribute("disabled", "disabled");
                                        dataProx.setAttribute("disabled", "disabled");
                                        erro.setAttribute("disabled", "disabled");
                                        MedInfo="Sim";
                                        var ButtonMed = document.getElementById("ButtonMed");
                                        ButtonMed.style.display="none";
                                        return true;  

                                        

                                    }
                                }
                            }
                        }
                    }
                }
                
            }
        }
    }


    /////////////////////////////////////////////////////////////////////  EXAME  /////////////////////////////////////////////////////////////////////////////
    function ExameSim(){
        var button = document.getElementById("ExSim");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";        
        ExSim="Sim";  
        
        var div = document.getElementById("Div");
        div.style.display="block";
    }

    function ExameNao(){
        var button = document.getElementById("ExNao");
        button.style.backgroundColor="#009fe3";
        button.style.color="#fff";
        ExNao="Sim";
    }

    function Hematologico(){
        var button = document.getElementById("DivHematologico");
        button.style.display="block";
        ButtonHematologico = "Sim";

        var button2 = document.getElementById("Hematologico");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Imagem(){
        var button = document.getElementById("DivImagem");
        button.style.display="block";
        ButtonImagem = "Sim";
        
        var button2 = document.getElementById("Imagem");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Bioquimico(){
        var button = document.getElementById("DivBioquimico");
        button.style.display="block";
        ButtonBioquimico = "Sim";

        var button3 = document.getElementById("DivBioquimico2");
        button3.style.display="block";
        ButtonBioquimico = "Sim";

        var button2 = document.getElementById("Bioquimico");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Parasitologico(){
        var button = document.getElementById("DivParasitologico");
        button.style.display="block";
        ButtonParasitologico = "Sim";
        
        var button2 = document.getElementById("Parasitologico");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Outros(){
        var button = document.getElementById("DivOutros");
        button.style.display="block";
        ButtonOutros = "Sim";

        var button2 = document.getElementById("Outros");
        button2.style.backgroundColor="#009fe3";        
        button2.style.color="#fff";        
    }

    function Fezes(){
        var Fezes = document.getElementById("Fezes");
        var InputFezes = document.getElementById("InputFezes");

        if(Fezes.checked === true){
            InputFezes.style.display="block";
        }
        else{
            InputFezes.style.display="none";
        }
    }

    function RadiologiaSimples(){
        var RadiologiaSimples = document.getElementById("RadiologiaSimples");
        var InputRadiologiaSimples = document.getElementById("InputRadiologiaSimples");

        if(RadiologiaSimples.checked === true){
            InputRadiologiaSimples.style.display="block";
        }
        else{
            InputRadiologiaSimples.style.display="none";
        }
    }

    function RadiologiaContrastada(){
        var RadiologiaContrastada = document.getElementById("RadiologiaContrastada");
        var InputRadiologiaContrastada = document.getElementById("InputRadiologiaContrastada");

        if(RadiologiaContrastada.checked === true){
            InputRadiologiaContrastada.style.display="block";
        }
        else{
            InputRadiologiaContrastada.style.display="none";
        }
    }

    function Eletrocardiograma(){
        var Eletrocardiograma = document.getElementById("Eletrocardiograma");
        var InputEletrocardiograma = document.getElementById("InputEletrocardiograma");

        if(Eletrocardiograma.checked === true){
            InputEletrocardiograma.style.display="block";
        }
        else{
            InputEletrocardiograma.style.display="none";
        }
    }

    function UltrassonografiAbdominal(){
        var UltrassonografiAbdominal = document.getElementById("UltrassonografiAbdominal");
        var InputUltrassonografiAbdominal = document.getElementById("InputUltrassonografiAbdominal");

        if(UltrassonografiAbdominal.checked === true){
            InputUltrassonografiAbdominal.style.display="block";
        }
        else{
            InputUltrassonografiAbdominal.style.display="none";
        }
    }

    return(

    <div>
        <div className="wrapper ">
            <div className="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                <div className="logo">
                    <a  className="simple-text logo-normal">
                        <img alt="" src={rodape} className="ImagemLogo" align="left" />            
                    </a>
                    <a  className="simple-text logo-normal">
                        <p className="NomePrest">Cantos dos Bichos</p>
                        <p className="TipoPrest">PetShop</p>
                    </a>
                </div>
                <div className="sidebar-wrapper">
                    <ul className="nav">
                        <li className="nav-item active  ">
                            <a className="nav-link" href="./dashboard.html">
                            <i className="material-icons">dashboard</i>
                            <p>Inicio</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./user.html">
                            <i className="material-icons">event</i>
                            <p>Calendário</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./tables.html">
                            <i className="material-icons">assignment_ind</i>
                            <p>Funcionários</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./typography.html">
                            <i className="material-icons">shopping_cart</i>
                            <p>Shopping</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./icons.html">
                            <i className="material-icons">alarm</i>
                            <p>Horários</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./map.html">
                            <i className="material-icons">account_circle</i>
                            <p>Editar Perfil</p>
                            </a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link" href="./notifications.html">
                            <i className="material-icons">assignment</i>
                            <p>Prontuários</p>
                            </a>
                        </li>
                        <li className="nav-item active-pro ">
                            <a className="nav-link" style={{background:'none'}}>
                                <table>
                                    <tr>
                                        <td style={{width: '20%'}}>
                                            <img  alt="" src={rodape2} className="material-icons"/>
                                        </td>
                                        <td style={{width: '80%'}}>
                                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                                        </td>
                                    </tr>
                                </table>            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>    
            <div className="main-panel">
                <nav className="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                    <div className="container-fluid">
                        <div className="navbar-wrapper">
                            <a className="navbar-brand" href="#pablo" style={{fontSize:'21px'}}>Cadastro Prontuários</a>
                        </div>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="sr-only">Toggle navigation</span>
                            <span className="navbar-toggler-icon icon-bar"></span>
                            <span className="navbar-toggler-icon icon-bar"></span>
                            <span className="navbar-toggler-icon icon-bar"></span>
                        </button>
                        <div className="collapse navbar-collapse justify-content-end">
                            <ul className="navbar-nav">
                                <li className="nav-item dropdown">
                                    <a className="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i className="material-icons">notifications</i>
                                        <span className="notification">5</span>
                                        <p className="d-lg-none d-md-block">
                                            Some Actions
                                        </p>
                                    </a>
                                    <div className="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <a className="dropdown-item" href="#">Mike John responded to your email</a>
                                        <a className="dropdown-item" href="#">You have 5 new tasks</a>
                                        <a className="dropdown-item" href="#">You're now friend with Andrew</a>
                                        <a className="dropdown-item" href="#">Another Notification</a>
                                        <a className="dropdown-item" href="#">Another One</a>
                                    </div>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="#pablo">
                                        <i className="material-icons">help_outline</i>
                                        <p className="d-lg-none d-md-block">
                                            Stats
                                        </p>
                                    </a>
                                </li>                                
                                <li className="nav-item dropdown">
                                    <a >
                                        <img  alt="" src={rodape} className="iconLogo" align="right" />      
                                    </a>                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>

                
                <div className="content">
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="card">
                                    <div className="card-header card-header-blue">
                                        <h4 className="card-title">Prontuários</h4>
                                        <p className="card-category">Complete os Dados!</p>
                                    </div>
                                    <div className="card-body">
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="tutor" placeholder="Nome do Tutor"  />
                                                    </div>
                                                </div>  
                                                <div className="col-md-3">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control"  placeholder="Data" disabled/>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="form-group">
                                                        <input type="date" id="date" className="form-control" />
                                                    </div>
                                                </div>                                             
                                            </div>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="pet" placeholder="Nome do Pet"/>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="rg" placeholder="RG do Animal"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="Clinica" value={clinica} placeholder="Clinica Veterinaria" style={{color:'#009fe3',fontWeight:'500'}} disabled/>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" id="veterinario" value={veterinario} style={{color:'#009fe3',fontWeight:'500'}} placeholder="Veterinario Responsavel" disabled/>
                                                    </div>
                                                </div>
                                            </div>
                                            <br/>
                                            <div className="row">
                                                <div className="col-md-6"> 
                                                <label className="bmd-label-floating">Vacinas</label>  
                                                        {/* <div id="DivVacina" style={{display:'block'}}>        */}
                                                        <button type="submit" className="btnCadFunc"  id="VacSim" onClick={VacinaSim} style={{width:'100px',marginLeft:'5%'}}>Adicionar</button>
                                                        <button type="submit" className="btnCadFunc" id="VacNao" onClick={VacinaNao} style={{width:'100px',marginLeft:'2%'}}>Sem Vacina</button>
                                                        {/* </div>      */}
                                                        <div id="DivVacinaSim" style={{display:'none'}}>
                                                        <div className="card-body">
                                                            <div className="row">
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                            <input type="text" className="form-control" id="nome" placeholder="Nome"/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" id="dose" placeholder="Dose"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="row">
                                                                <div className="col-md-6">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" id="lote"placeholder="Lote"/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" id="valor" placeholder="Valor"/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" id="rgVacina" placeholder="RG Animal"/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br/>   
                                                            <div className="row">
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control" placeholder="Data Aplicada" disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="date" id="dataIni" className="form-control"/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="text" className="form-control"  placeholder="Proxima data" disabled/>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-3">
                                                                    <div className="form-group">
                                                                        <input type="date" id="dataProx" min="2020-01-01" className="form-control"/>
                                                                    </div>
                                                                </div>
                                                            </div> 
                                                            <br/>   
                                                            <div className="row" style={{textAlign: '-webkit-center'}}>
                                                                <div className="col-md-12">
                                                                    <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="validaVacina"></p>
                                                                    <button type="submit" className="btn btn-primary" style={{borderRadius: '30px',padding: '1% 5%',background:'#fff',border:'1px solid #009fe3',color:"#009fe3"}} onClick={SalvarVacina}id="ButtonVacina">Salvar</button>
                                                                    <div className="clearfix"></div>
                                                                </div>
                                                            
                                                            </div>   
                                                        {/* </form> */}
                                                    </div>
                                                    </div>
                                                </div>
                                                        <div className="col-md-6">
                                                            <label className="bmd-label-floating">Medicações</label>                                                
                                                                <button type="submit" className="btnCadFunc" id="MedSim" onClick={MedicaSim} style={{width:'100px',marginLeft:'5%'}}>Adicionar</button>
                                                                <button type="submit" className="btnCadFunc" id="MedNao" onClick={MedicaNao} style={{width:'150px',marginLeft:'2%'}}>Sem Medicação</button>

                                                                <div id="DivMedicacaoSim" style={{display:'none'}}>
                                                                    <div className="card-body">
                                                                        {/* <form> */}
                                                                            <div className="row">
                                                                                <div className="col-md-6">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control" id="nomeMed" placeholder="Nome"/>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-6">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control" id="observMed" placeholder="Observações"/>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div className="row">
                                                                                <div className="col-md-6">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control" id="loteMed" placeholder="Lote"/>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-3">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control" id="doseMed" placeholder="Dose"/>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-3">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control"  id="rgMed" placeholder="RG Animal"/>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <br/>   
                                                                            <div className="row">
                                                                                <div className="col-md-3">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control" placeholder="Data de Inicio" disabled/>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-3">
                                                                                    <div className="form-group">
                                                                                        <input type="date"  min="2020-04-01" id="dataAtual" className="form-control"/>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-3">
                                                                                    <div className="form-group">
                                                                                        <input type="text" className="form-control"  placeholder="Data Final" disabled/>
                                                                                    </div>
                                                                                </div>
                                                                                <div className="col-md-3">
                                                                                    <div className="form-group">
                                                                                        <input type="date" min="2020-04-01" id="dataDoseProx" className="form-control"/>
                                                                                    </div>
                                                                                </div>
                                                                            </div> 
                                                                            <br/>   
                                                                            <div className="row" style={{textAlign: '-webkit-center'}}>
                                                                                <div className="col-md-12">
                                                                                    <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="validaMed"></p>
                                                                                    <button type="submit" className="btn btn-primary" style={{borderRadius: '30px',padding: '1% 5%',background:'#fff',border:'1px solid #009fe3',color:"#009fe3"}}id="ButtonMed" onClick={SalvarMed}>Salvar</button>
                                                                                    <div className="clearfix"></div>
                                                                                </div>
                                                                            
                                                                            </div>   
                                                                        {/* </form> */}
                                                                    </div>
                                                                </div>
                                                        </div>
                                                    </div>  
                                            <br/>   
                                            <div className="row">
                                                <div className="col-md-6">
                                                <label className="bmd-label-floating">Exame</label>  
                                                        <button type="submit" className="btnCadFunc" id="ExSim" onClick={ExameSim} style={{width:'50px',marginLeft:'5%'}}>Sim</button>
                                                        <button type="submit" className="btnCadFunc" id="ExNao" onClick={ExameNao} style={{width:'70px',marginLeft:'2%'}}>Não</button>
                                                </div>
                                                <div className="col-md-6" style={{display:"none"}} id="Div">
                                                <label className="bmd-label-floating">Selecione Tipo de Exame</label>
                                                    <div className="row">
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Imagem" onClick={Imagem} style={{marginLeft:'2%'}}>Imagem</button>
                                                        </div> 
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Hematologico" onClick={Hematologico} style={{marginLeft:'2%'}}>Hematologico</button>
                                                        </div> 
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Bioquimico" onClick={Bioquimico} style={{marginLeft:'2%'}}>Bioquimico</button>
                                                        </div>                                                         
                                                    </div>
                                                    <div className="row" style={{marginTop:'2%'}}>
                                                        <div className="col-md-5">
                                                            <button type="submit" className="btnCadFunc" id="Parasitologico" onClick={Parasitologico} style={{marginLeft:'2%'}}>Parasitologico</button> 
                                                        </div> 
                                                        <div className="col-md-3">
                                                            <button type="submit" className="btnCadFunc" id="Outros" onClick={Outros} style={{marginLeft:'2%'}}>Outros</button> 
                                                        </div>
                                                    </div> 
                                                </div>
                                            </div> 
                                            <br/>

                                            <div id="DivParasitologico" style={{display:'none'}}>  
                                                <div className="col-md-12">
                                                    <p  style={{color:'black',marginBottom:'0px'}}> Exames Parasitologico:</p>
                                                   <div className="row">
                                                        <div className="col-md-4">                                                                
                                                            <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>

                                                                <label className="dias">Parasitologico de fezes
                                                                    <input type="checkbox" id="Fezes" onClick={Fezes} />
                                                                    <span className="checkmark"></span>
                                                                </label>                                                            
                                                            </div>
                                                        </div>
                                                        <div className="col-md-8">
                                                            <input type="text" className="form-control"  id="InputFezes" placeholder="Observação" style={{display:'none'}}/>
                                                        </div>
                                                    </div>
                                                </div>                                               
                                            </div>

                                            <div id="DivImagem" style={{display:'none'}}>    
                                                <div className="col-md-12"> 
                                                    <p  style={{color:'black',marginBottom:'0px'}}> Exames Imagem:</p>
                                                    <div className="row">
                                                        <div className="col-md-4">                                                            
                                                            <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>

                                                                <label className="dias">Radiologia simples
                                                                    <input type="checkbox" id="RadiologiaSimples" onClick={RadiologiaSimples} />
                                                                    <span className="checkmark"></span>
                                                                </label>                                                                
                                                            </div>
                                                        </div> 
                                                        <div className="col-md-8">
                                                            <input type="text" className="form-control"  id="InputRadiologiaSimples" placeholder="Observação" style={{display:'none'}}/>
                                                        </div>
                                                          {/*////////////////////////////////////////////////////// EXAME 2 /////////////////////////////*/}
                                                        <div className="col-md-4">                                                           
                                                            <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>

                                                                <label className="dias">Radiologia contrastada
                                                                    <input type="checkbox" id="RadiologiaContrastada" onClick={RadiologiaContrastada}/>
                                                                    <span className="checkmark"></span>
                                                                </label>                                                                
                                                            </div>
                                                        </div> 
                                                        <div className="col-md-8">
                                                            <input type="text" className="form-control"  id="InputRadiologiaContrastada" placeholder="Observação" style={{display:'none'}}/>
                                                        </div>

                                                         {/*////////////////////////////////////////////////////// EXAME 3 /////////////////////////////*/}
                                                         <div className="col-md-4">                                                           
                                                            <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>

                                                                <label className="dias">Eletrocardiograma
                                                                    <input type="checkbox" id="Eletrocardiograma" onClick={Eletrocardiograma}/>
                                                                    <span className="checkmark"></span>
                                                                </label>                                                                
                                                            </div>
                                                        </div> 
                                                        <div className="col-md-8">
                                                            <input type="text" className="form-control"  id="InputEletrocardiograma" placeholder="Observação" style={{display:'none'}}/>
                                                        </div>

                                                        {/*////////////////////////////////////////////////////// EXAME 4 /////////////////////////////*/}
                                                        <div className="col-md-4">                                                           
                                                            <div className="col-md-12" style={{verticalAlign: 'middle',display: 'inline-grid'}}>

                                                                <label className="dias">Ultrassonografia Abdominal 
                                                                    <input type="checkbox" id="UltrassonografiAbdominal" onClick={UltrassonografiAbdominal}/>
                                                                    <span className="checkmark"></span>
                                                                </label>                                                                
                                                            </div>
                                                        </div> 
                                                        <div className="col-md-8">
                                                            <input type="text" className="form-control"  id="InputUltrassonografiAbdominal" placeholder="Observação" style={{display:'none'}}/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        
                                        
                                            <br/>
                                            <div className="row" style={{textAlign: '-webkit-center'}}>
                                                <div className="col-md-12">
                                                    <p style={{color:'red',fontWeight:'200',marginBottom:'0px'}} id="valida"></p>
                                                    <button type="submit" className="btn btn-primary" onClick={Salvar} style={{borderRadius: '30px',padding: '1% 5%'}}>Salvar</button>
                                                    <div className="clearfix"></div>
                                                </div>                                              
                                            </div>   
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div> 
            </div>
        </div>
    </div>
    )

   
}