import React from 'react';

export default function EditarPerfil(){
    return(
    <div>
        


    </div>
    )
}