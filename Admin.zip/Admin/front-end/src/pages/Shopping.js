import React from 'react';
import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";

import api from '../services/api.js';

export default function Shopping(){

    async function Aparecer(){
        let response="";

        try {
            response = await api.post('/Produto/BuscarProd', {idPrest:2});
        } catch (error) {
            console.log(error);               
        } 

        var produto = response.data.response.Produto;

        for(let i=0; i< produto.length;i++){

            var tbody = document.getElementById("tbody");
            var tr = document.createElement("tr");
            var div = document.createElement("div");
            var div2 = document.createElement("div");
            var img = document.createElement("img");
            var div3 = document.createElement("div");
            var pNome = document.createElement("a");
            var pDesc = document.createElement("a");
            var br = document.createElement("BR");
            var div4 = document.createElement("div");
            var div5 = document.createElement("div");
            var buttonExluir = document.createElement("button");
            var buttonEditar = document.createElement("button");
            var buttonVisualizar = document.createElement("button");

            tr.style.width="100%";
            tr.style.borderBottom="1px solid #c1e0fc";
            div.className="row";
            div2.className="col-md-0.5";
            div2.style.paddingRight="0";
            div2.style.marginLeft="15px";
            img.setAttribute("src",{rodape});
            img.className="ImagemProd";
            img.setAttribute("align","right");
            div3.className="col-md-4";
            div3.style.paddingLeft="0";
            pNome.className="NomeFunc";
            pNome.innerHTML="Nome: "+ produto[i].NomeProd;
            pDesc.className="NomeFunc";
            pDesc.innerHTML="Descrição: "+produto[i].DescProd;
            div4.className="col-md-7";
            div5.style.width="100%";
            div5.style.textAlign="right";

            buttonExluir.setAttribute("id", i.toString() );
            buttonExluir.onclick = function() { Excluir(i) };
            buttonExluir.className="btn btn-primary btnExcShop";
            buttonExluir.innerHTML="Excluir";
            buttonExluir.setAttribute("type","submit");

            buttonEditar.setAttribute("id", i.toString() );
            buttonEditar.onclick = function() { Editar(i) };
            buttonEditar.className="btn btn-primary btnEditShop";
            buttonEditar.innerHTML="Editar";
            buttonEditar.setAttribute("type","submit");

            buttonVisualizar.setAttribute("id", i.toString() );
            buttonVisualizar.onclick = function() { Visualizar(i) };
            buttonVisualizar.className="btn btn-primary btnVisShop";
            buttonVisualizar.innerHTML="Visualizar";
            buttonVisualizar.setAttribute("type","submit");

            div2.appendChild(img);
            div3.appendChild(pNome);
            div3.appendChild(br);
            div3.appendChild(pDesc);
            div5.appendChild(buttonExluir);
            div5.appendChild(buttonEditar);
            div5.appendChild(buttonVisualizar);
            div4.appendChild(div5);
            div.appendChild(div2);
            div.appendChild(div3);
            div.appendChild(div4);
            tr.appendChild(div);
            tbody.appendChild(tr);
        }
    }

    Aparecer();

     //Ir para telas para de detalhes
     function Excluir(c){   
        localStorage.setItem('Codigo', c);
        // window.location.href = "/Detalhes";
        alert("excluir");
    }

     //Ir para telas para de detalhes
     function Editar(c){   
        localStorage.setItem('Codigo', c);
        window.location.href = "/EditarProduto";
    }

     //Ir para telas para de detalhes
     function Visualizar(c){   
        localStorage.setItem('Codigo', c);
        alert("Visualizar");
    }

    async function Filtro(){
        var Nome = document.getElementById("Nome");
        var ButtonFiltro = document.getElementById("ButtonFiltro");
        

        if (Nome.value === "" || Nome.value === null || Nome.value === undefined) {
    
            Nome.value = "Preencha o campo Nome";
            Nome.style.color="red";
        }
        else{
            Nome.style.color="#009fe3";
            let response="";

            var tbody = document.getElementById("tbody").remove();
            ButtonFiltro.setAttribute("disabled", "disabled");
            
            try {
                response = await api.post('/Produto/FiltroProd', {idPrest:2,NomeProd:Nome.value});
            } catch (error) {
                console.log(error);               
            } 
            console.log(response)

            var produto = response.data.response.Produto;

            for(let i=0; i< produto.length;i++){

                // var table= document.getElementById("table");
                // var tbody = document.createElement("tbody");
                var table= document.getElementById("table");
                var tbody = document.createElement("tbody");
                var tr = document.createElement("tr");
                var div = document.createElement("div");
                var div2 = document.createElement("div");
                var img = document.createElement("img");
                var div3 = document.createElement("div");
                var pNome = document.createElement("a");
                var pDesc = document.createElement("a");
                var br = document.createElement("BR");
                var div4 = document.createElement("div");
                var div5 = document.createElement("div");
                var buttonExluir = document.createElement("button");
                var buttonEditar = document.createElement("button");
                var buttonVisualizar = document.createElement("button");

                tbody.setAttribute("id", "tbody"+i.toString() );
                tr.style.width="100%";
                tr.style.borderBottom="1px solid #c1e0fc";
                div.className="row";
                div2.className="col-md-0.5";
                div2.style.paddingRight="0";
                div2.style.marginLeft="15px";
                img.setAttribute("src",{rodape});
                img.className="ImagemProd";
                img.setAttribute("align","right");
                div3.className="col-md-4";
                div3.style.paddingLeft="0";
                pNome.className="NomeFunc";
                pNome.innerHTML="Nome: "+ produto[i].NomeProd;
                pDesc.className="NomeFunc";
                pDesc.innerHTML="Descrição: "+produto[i].DescProd;
                div4.className="col-md-7";
                div5.style.width="100%";
                div5.style.textAlign="right";

                buttonExluir.setAttribute("id", i.toString() );
                buttonExluir.onclick = function() { Excluir(i) };
                buttonExluir.className="btn btn-primary btnExcShop";
                buttonExluir.innerHTML="Excluir";
                buttonExluir.setAttribute("type","submit");

                buttonEditar.setAttribute("id", i.toString() );
                buttonEditar.onclick = function() { Editar(i) };
                buttonEditar.className="btn btn-primary btnEditShop";
                buttonEditar.innerHTML="Editar";
                buttonEditar.setAttribute("type","submit");

                buttonVisualizar.setAttribute("id", i.toString() );
                buttonVisualizar.onclick = function() { Visualizar(i) };
                buttonVisualizar.className="btn btn-primary btnVisShop";
                buttonVisualizar.innerHTML="Visualizar";
                buttonVisualizar.setAttribute("type","submit");

                div2.appendChild(img);
                div3.appendChild(pNome);
                div3.appendChild(br);
                div3.appendChild(pDesc);
                div5.appendChild(buttonExluir);
                div5.appendChild(buttonEditar);
                div5.appendChild(buttonVisualizar);
                div4.appendChild(div5);
                div.appendChild(div2);
                div.appendChild(div3);
                div.appendChild(div4);
                tr.appendChild(div);
                tbody.appendChild(tr);
                table.appendChild(tbody);
                // table.appendChild(tbody);
            }
        }

        
    }
    

    return(
    <div>
        <div class="wrapper ">
            <div class="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                <div class="logo">
                    <a  class="simple-text logo-normal">
                        <img src={rodape} class="ImagemLogo" align="left" />            
                    </a>
                    <a  class="simple-text logo-normal">
                        <p class="NomePrest">Cantos dos Bichos</p>
                        <p class="TipoPrest">PetShop</p>
                    </a>
                </div>
                <div class="sidebar-wrapper">
                    <ul class="nav">
                        <li class="nav-item active  ">
                            <a class="nav-link" href="./dashboard.html">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./user.html">
                            <i class="material-icons">event</i>
                            <p>Calendário</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./tables.html">
                            <i class="material-icons">assignment_ind</i>
                            <p>Funcionários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./typography.html">
                            <i class="material-icons">shopping_cart</i>
                            <p>Shopping</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./icons.html">
                            <i class="material-icons">alarm</i>
                            <p>Horários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./map.html">
                            <i class="material-icons">account_circle</i>
                            <p>Editar Perfil</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./notifications.html">
                            <i class="material-icons">assignment</i>
                            <p>Prontuários</p>
                            </a>
                        </li>
                        <li class="nav-item active-pro ">
                            <a class="nav-link" style={{background:'none'}}>
                                <table>
                                    <tr>
                                        <td style={{width: '20%'}}>
                                            <img src={rodape2} class="material-icons"/>
                                        </td>
                                        <td style={{width: '80%'}}>
                                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                                        </td>
                                    </tr>
                                </table>            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>    
            <div class="main-panel">
                <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                    <div class="container-fluid">
                        <div class="navbar-wrapper">
                            <a class="navbar-brand" href="#" >Shopping</a>
                        </div>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-end">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">notifications</i>
                                        <span class="notification">5</span>
                                        <p class="d-lg-none d-md-block">
                                            Some Actions
                                        </p>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item" href="#">Mike John responded to your email</a>
                                        <a class="dropdown-item" href="#">You have 5 new tasks</a>
                                        <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                                        <a class="dropdown-item" href="#">Another Notification</a>
                                        <a class="dropdown-item" href="#">Another One</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#pablo">
                                        <i class="material-icons">help_outline</i>
                                        <p class="d-lg-none d-md-block">
                                            Stats
                                        </p>
                                    </a>
                                </li>                                
                                <li class="nav-item dropdown">
                                    <a >
                                        <img src={rodape} class="iconLogo" align="right" />      
                                    </a>                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card" style={{borderLeft:'4px solid #009fe3'}}>
                                    <div class="card-body" style={{padding:'0 0 0 0'}}>
                                        <div >
                                        <div class="row" >
                                            <div class="col-md-4">
                                                <div class="navbar-form" style={{textAlign: '-webkit-center'}}>
                                                    <div class="input-group no-border searchFunc" >
                                                            <span class="material-icons" style={{color:'#009fe3'}}>
                                                            search
                                                            </span>
                                                        <input type="text"  id="Nome" placeholder="Digite o Nome"/>
                                                    </div>
                                                </div>
                                            </div>  
                                            <div class="col-md-4" style={{paddingLeft: '0'}}>
                                                <div style={{width: '100%',textAlign: 'left',paddingRight:'5%'}}> 
                                                    <button type="submit" class="btn btn-primary btnPrimeiroShop" onClick={Filtro} id="ButtonFiltro">Filtrar</button>
                                                    <button type="submit" class="btn btn-primary btnSegundoShop">Novo Produto</button>
                                                </div> 
                                            </div>                                             
                                            <div class="col-md-4"></div>                                     
                                        </div> 
                                        <br/>
                                        </div>
                                        {/* style={{borderBottom:'1px solid #c1e0fc'}} */}
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="profile">
                                                <table class="table" style={{marginBottom:'0px'}} id="table">
                                                    <tbody id="tbody">  
                                                                                                            
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div> 
            </div>
        </div>
    </div>
    )
}