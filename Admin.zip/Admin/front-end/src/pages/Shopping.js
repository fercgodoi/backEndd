import React from 'react';
import "../css/material-dashboard.css";
import rodape from  "../img/Icon/versao.png";
import rodape2 from  "../img/Icon/versao.png";
import Confrimar from  "../img/Icon/yes.png";
import Negar from  "../img/Icon/no.png";

export default function Shopping(){
    return(
    <div>
        <div class="wrapper ">
            <div class="sidebar" data-color="blue" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
                <div class="logo">
                    <a  class="simple-text logo-normal">
                        <img src={rodape} class="ImagemLogo" align="left" />            
                    </a>
                    <a  class="simple-text logo-normal">
                        <p class="NomePrest">Cantos dos Bichos</p>
                        <p class="TipoPrest">PetShop</p>
                    </a>
                </div>
                <div class="sidebar-wrapper">
                    <ul class="nav">
                        <li class="nav-item active  ">
                            <a class="nav-link" href="./dashboard.html">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./user.html">
                            <i class="material-icons">event</i>
                            <p>Calendário</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./tables.html">
                            <i class="material-icons">assignment_ind</i>
                            <p>Funcionários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./typography.html">
                            <i class="material-icons">shopping_cart</i>
                            <p>Shopping</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./icons.html">
                            <i class="material-icons">alarm</i>
                            <p>Horários</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./map.html">
                            <i class="material-icons">account_circle</i>
                            <p>Editar Perfil</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link" href="./notifications.html">
                            <i class="material-icons">assignment</i>
                            <p>Prontuários</p>
                            </a>
                        </li>
                        <li class="nav-item active-pro ">
                            <a class="nav-link" style={{background:'none'}}>
                                <table>
                                    <tr>
                                        <td style={{width: '20%'}}>
                                            <img src={rodape2} class="material-icons"/>
                                        </td>
                                        <td style={{width: '80%'}}>
                                            <p style={{color:'#009fe3'}}>Versão 1.0</p>
                                        </td>
                                    </tr>
                                </table>            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>    
            <div class="main-panel">
                <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
                    <div class="container-fluid">
                        <div class="navbar-wrapper">
                            <a class="navbar-brand" href="#pablo" >Shopping</a>
                        </div>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                            <span class="navbar-toggler-icon icon-bar"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-end">
                            <ul class="navbar-nav">
                                <li class="nav-item dropdown">
                                    <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">notifications</i>
                                        <span class="notification">5</span>
                                        <p class="d-lg-none d-md-block">
                                            Some Actions
                                        </p>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item" href="#">Mike John responded to your email</a>
                                        <a class="dropdown-item" href="#">You have 5 new tasks</a>
                                        <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                                        <a class="dropdown-item" href="#">Another Notification</a>
                                        <a class="dropdown-item" href="#">Another One</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#pablo">
                                        <i class="material-icons">help_outline</i>
                                        <p class="d-lg-none d-md-block">
                                            Stats
                                        </p>
                                    </a>
                                </li>                                
                                <li class="nav-item dropdown">
                                    <a >
                                        <img src={rodape} class="iconLogo" align="right" />      
                                    </a>                                    
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card" style={{borderLeft:'4px solid #009fe3'}}>
                                    <div class="card-body" style={{padding:'0 0 0 0'}}>
                                        <div >
                                        <div class="row" >
                                            <div class="col-md-4">
                                                <div class="navbar-form" style={{textAlign: '-webkit-center'}}>
                                                    <div class="input-group no-border searchFunc" >
                                                            <span class="material-icons" style={{color:'#009fe3'}}>
                                                            search
                                                            </span>
                                                        <input type="text" value="" class="" placeholder="Digite o Nome"/>
                                                    </div>
                                                </div>
                                            </div>  
                                            <div class="col-md-4" style={{paddingLeft: '0'}}>
                                                <div style={{width: '100%',textAlign: 'left',paddingRight:'5%'}}> 
                                                 <button type="submit" class="btn btn-primary btnPrimeiroShop" >Filtrar</button>
                                                    <button type="submit" class="btn btn-primary btnSegundoShop">Novo Produto</button>
                                                </div> 
                                            </div>                                             
                                            <div class="col-md-4"></div>                                     
                                        </div> 
                                        <br/>
                                        </div>
                                        {/* style={{borderBottom:'1px solid #c1e0fc'}} */}
                                        <div class="tab-content">
                                            <div class="tab-pane active" id="profile">
                                                <table class="table" style={{marginBottom:'0px'}}>
                                                    <tbody>                                                    
                                                        <tr style={{width: '100%',borderBottom:'1px solid #c1e0fc'}}>
                                                            <div class="row">
                                                            <div class="col-md-0.5" style={{paddingRight: '0',marginLeft: '15px'}}>
                                                            <img src={rodape} class="ImagemProd" align="right" />            
                                                            </div>
                                                            <div class="col-md-4" style={{paddingLeft: '0'}}>
                                                                    <p className="NomeFunc">José da Silva <br/> nanda.cgodoi@gmail.com </p>
                                                            </div>
                                                            {/* <div class="col-md-4"> 
                                                            <p className="FuncaoFunc">Funcionário</p></div> */}
                                                            <div class="col-md-7">
                                                                <div style={{width: '100%',textAlign: 'right'}}>
                                                                <button type="submit" className=" btn btn-primary btnExcShop" >Excluir</button>
                                                                <button type="submit" className=" btn btn-primary btnEditShop" >Editar</button>
                                                                <button type="submit" className=" btn btn-primary btnVisShop" >Visualizar</button>
                                                                </div> 
                                                           </div>
                                                           </div>
                                                        </tr>   
                                                        <tr style={{width: '100%',borderBottom:'1px solid #c1e0fc'}}>
                                                            <div class="row">
                                                            <div class="col-md-0.5" style={{paddingRight: '0',marginLeft: '15px'}}>
                                                            <img src={rodape} class="ImagemProd" align="right" />            
                                                            </div>
                                                            <div class="col-md-4" style={{paddingLeft: '0'}}>
                                                                    <p className="NomeFunc">José da Silva <br/> nanda.cgodoi@gmail.com </p>
                                                            </div>
                                                            {/* <div class="col-md-4"> 
                                                            <p className="FuncaoFunc">Funcionário</p></div> */}
                                                            <div class="col-md-7">
                                                                <div style={{width: '100%',textAlign: 'right'}}>
                                                                <button type="submit" className=" btn btn-primary btnExcShop" >Excluir</button>
                                                                <button type="submit" className=" btn btn-primary btnEditShop" >Editar</button>
                                                                <button type="submit" className=" btn btn-primary btnVisShop" >Visualizar</button>
                                                                </div> 
                                                           </div>
                                                           </div>
                                                        </tr>   
                                                                                                            
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>
                 </div> 
            </div>
        </div>
    </div>
    )
}