import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import rodape from  "../img/login.png";
import Blabala from "../img/cover.jpg";
import gatinho from "../img/Icon/gatinho.png";

export default function CadastroTerceiro(){
    return(
    <div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style={{padding:'0px',margin:'0px'}}>

                    <div class="card-header card-header-blue" style={{background:'#009fe3'}}>
                        <h4 class="card-title" style={{fontWeight:'300',color:'#fff',textAlign: '-webkit-center'}}>Passo 3</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Miau! Qual é o seu nome fantasia?</a>
                                        <input type="text" class="form-control" placeholder="Nome Fantasia" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        {/* <div class="row">
                            <div class="col-md-3"> 
                                <img src={gatinho} style={{width:'30px'}}></img> 
                                <a style={{marginLeft:'5px',color:'#000000'}}>Perfeito! Qual é a sua área de atuação!</a>                                           
                                <br/>
                                <br/>
                                <button type="submit" className="btnCadFunc">Recepção</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <br/>
                                <button type="submit" className="btnCadFunc">Adiministração</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <br/>
                                <button type="submit" className="btnCadFunc">Veterinário</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                            <div class="col-md-3">
                                <br/>
                                <br/>
                                <button type="submit" className="btnCadFunc">Financeiro</button>
                                <div class="clearfix"></div>                                                   
                            </div>
                        </div>  
                        <br/>    */}
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Legal, agora precisamos saber qual é o seu cep do seu estabelecimento! </a>
                                        <input type="text" class="form-control" placeholder="CEP" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Seu estado é? </a>
                                        <input type="text" class="form-control" placeholder="Estado" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Sua cidade é? </a>
                                        <input type="text" class="form-control" placeholder="Cidade" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Sua rua é? </a>
                                        <input type="text" class="form-control" placeholder="Rua" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Show! Para poder atender melhor seus clientes, precisamos do número da Empresa!</a>
                                        <input type="text" class="form-control" placeholder="Número" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row" style={{textAlign: '-webkit-center'}}>
                            <div class="col-md-12">
                                <div class="form-group">
                                <button type="submit" className=" btn btn-primary btnEditShop" >Proximo</button>
                                </div>
                            </div>
                        </div>
                    </div>
                                            

                    </div>
                </div>
            </div>
        </div>    
    </div>
    )
}