import React from 'react';
import "../css/Login/main.css";
import "../css/Login/util.css";
import "../css/material-dashboard.css";
import rodape from  "../img/login.png";
import Blabala from "../img/cover.jpg";
import gatinho from "../img/Icon/gatinho.png";

export default function CadastroSeis(){
    return(
    <div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style={{padding:'0px',margin:'0px'}}>

                    <div class="card-header card-header-blue" style={{background:'#009fe3'}}>
                        <h4 class="card-title" style={{fontWeight:'300',color:'#fff',textAlign: '-webkit-center'}}>Passo 6</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Agora vamos cadastrar o responsável do estabelecimento!!</a>
                                        <input type="text" class="form-control" placeholder="Nome Fantasia" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Nome" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="CPF" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Celular" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Email" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <br/>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <img src={gatinho} style={{width:'30px'}}></img> 
                                    <a style={{marginLeft:'5px',color:'#000000'}}>Você é veterinario?</a>
                                </div>
                            </div>
                            <div class="col-md-3"> </div>
                            <div class="col-md-3"> 
                                <button type="submit" className="btnCadFunc">Sim</button>
                                <div class="clearfix"></div>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" className="btnCadFunc">Não</button>
                                <div class="clearfix"></div>                                                   
                            </div>   
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="CRMV" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Data de Emissão" style={{color:'#009fe3',marginTop:'1%'}}/>
                                </div>
                            </div>
                        </div>
                        
                        
                        <div class="row" style={{textAlign: '-webkit-center'}}>
                            <div class="col-md-12">
                                <div class="form-group">
                                <button type="submit" className=" btn btn-primary btnEditShop" >Proximo</button>
                                </div>
                            </div>
                        </div>
                    </div>
                                            

                    </div>
                </div>
            </div>
        </div>    
    </div>
    )
}