const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const ProdutoController = require('../../controllers/produto/produto-controller');

router.get('/BuscarProd',login.obrigatorio, ProdutoController.BuscarProdutos);
router.port('/CadastrarProd',login.obrigatorio, ProdutoController.CadastrarProdutos);

