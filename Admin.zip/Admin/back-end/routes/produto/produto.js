const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const ProdutoController = require('../../controllers/produto/produto-controller');

router.post('/BuscarProd',ProdutoController.BuscarProdutos);
router.post('/FiltroProd',ProdutoController.FiltrarProd);
router.post('/CadastrarProd',login.obrigatorio, ProdutoController.CadastrarProdutos);

// router.post('/BuscarProd', login.obrigatorio,ProdutoController.BuscarProdutos);
//router.post('/FiltroProd', login.obrigatorio,ProdutoController.FiltrarProd);

module.exports = router;