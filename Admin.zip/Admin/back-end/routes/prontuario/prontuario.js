const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const ProntuarioController = require('../../controllers/prontuario/prontuario-controller');

router.post('/CadProtuario',ProntuarioController.CadProntuario);
router.post('/BuscarPront',ProntuarioController.buscarPront);
router.post('/FiltroPront',ProntuarioController.FiltroPront);
router.post('/BuscarInfo',ProntuarioController.BuscarInfo);

//router.post('/EditarProd',login.obrigatorio, ProdutoController.EditarProd);
// router.post('/BuscarProd', login.obrigatorio,ProdutoController.BuscarProdutos);
//router.post('/FiltroProd', login.obrigatorio,ProdutoController.FiltrarProd);

module.exports = router;