const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const ProntuarioController = require('../../controllers/prontuario/prontuario-controller');

router.post('/CadProtuario',login.obrigatorio,ProntuarioController.CadProntuario);
router.post('/BuscarPront',login.obrigatorio,ProntuarioController.buscarPront);
router.post('/FiltroPront',login.obrigatorio,ProntuarioController.FiltroPront);
router.post('/BuscarInfo',login.obrigatorio,ProntuarioController.BuscarInfo);

// login.obrigatorio,

module.exports = router;