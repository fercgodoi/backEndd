const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const FuncionarioController = require('../../controllers/funcionario/funcionario-controller');

router.post('/AtualizarFunc', FuncionarioController.AtualizarFunc);
router.post('/BuscarFunc', FuncionarioController.BuscarFunc);
router.post('/Buscar', FuncionarioController.Buscar);
router.post('/BuscarFuncPrest', FuncionarioController.BuscarFuncPrest);
router.post('/CadastrarFunc', FuncionarioController.CadastroFuncionario);
router.post('/EsqueciSenhaFunc',FuncionarioController.EsqueciSenhaFunc);
router.post('/ExcluirFunc',FuncionarioController.ExcluirFunc);
router.post('/TrocarSenhaFunc',FuncionarioController.TrocarSenhaFunc);
router.post('/LoginFunc',FuncionarioController.LoginFunc);
router.post('/CodFunc',login.obrigatorio,FuncionarioController.CodFunc);

// router.post('/BuscarFuncPrest',login.obrigatorio, FuncionarioController.BuscarFuncPrest);
// router.post('/BuscarFunc',login.obrigatorio, FuncionarioController.BuscarFunc);
// router.post('/ExcluirFunc',login.obrigatorio, FuncionarioController.ExcluirFunc);
// router.post('/Buscar',login.obrigatorio, FuncionarioController.Buscar);
// router.post('/AtualizarFunc',login.obrigatorio, FuncionarioController.AtualizarFunc);
// router.post('/CadastrarFunc',login.obrigatorio, FuncionarioController.CadastroFuncionario);
module.exports = router;