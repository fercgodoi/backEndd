const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const AgendamentoController = require('../../controllers/agendamento/agendamento-controller');

router.post('/ConfAgendamento',login.obrigatorio, AgendamentoController.ConfirmarAgendamento);
router.get('/Contgendamento',login.obrigatorio, AgendamentoController.ContagemAgendamento);
router.post('/NegarAgendamento',login.obrigatorio, AgendamentoController.NegarAgendamento);
router.get('/BuscarAgendamento',login.obrigatorio, AgendamentoController.buscarAgendamento);
router.get('/BuscarConfAgendamento',login.obrigatorio, AgendamentoController.buscarAgendamentoConf);

module.exports = router;