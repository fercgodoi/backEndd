const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
//const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const ExameController = require('../../controllers/exame/exame-controller');

router.post('/CadExame',login.obrigatorio, ExameController.CadExames);
router.post('/BuscarInfo',login.obrigatorio, ExameController.BuscarInfo);


module.exports = router;
