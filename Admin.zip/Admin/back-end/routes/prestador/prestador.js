const express = require('express');
const router = express.Router();
//const mysql = require('mysql');
//const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
//const nodemailer = require("nodemailer");               //para enviar emails
//const bcrypt = require('bcrypt');                       //hash nas senhas
const login = require('../../middleware/login');

const PrestadorController = require('../../controllers/prestador/prestador-controller');

router.post('/AtualizarPrest',login.obrigatorio, PrestadorController.AtualizarPrest);
router.post('/CadastrarPrest', PrestadorController.CadastroPrestador);
// router.post('/CodPrest',login.obrigatorio, PrestadorController.codPrestador);
// router.post('/EsqueciSenhaPrest',PrestadorController.EsqueciSenhaPrest);
router.post('/HorarioPrest',login.obrigatorio, PrestadorController.HorarioPrest);
// router.post('/TrocarSenhaPrest',login.obrigatorio, PrestadorController.TrocarSenhaPrest);
router.post('/CodPrest',PrestadorController.CodPrest);

module.exports = router;