const mysql = require('../../mysql').pool;
const jwt = require('jsonwebtoken');
const nodemailer = require("nodemailer");               //para enviar emails


//---------------------------------BLOCO EMAIL------------------------------------------------------//

// let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
//     host:"imap.gmail.com",                                     
//     port: 465,
//     secure: true,
//     auth: {
//         user: "oneforasteiro@gmail.com",
//         pass: process.env.EMAIL_KEY                                         
//     }
// });


//---------------------------------------------------------------//

///////////////////////////////////////////////////////////////  CADASTRO MEDICAMENTOS /////////////////////////////////////////////////////////////////////////
exports.CadProntuario = (req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error:'error sql'})        
        }
        conn.query('select * from funcionario where idFunc= ?', [req.body.idFunc],
        (error, result, field)=> {
            if(error){return res.json({ error:'error sql'})}
            if(result.length == 0){
                return res.json({ message: "Vet nao encontrado"})
            }

            conn.query('select * from pet where rgPet = ?', [req.body.rgPet],
            (error, resultado, field)=> {
                if(error){return res.json({ error:'error sql'})}
                if(resultado.length == 0){
                    return res.json({ message: "Pet nao encontrado"})
                }

                conn.query('insert into consulta(idPrest,idFunc,idPet,idVacina,idMed,dataConst) values (?,?,?,?,?,?)',
                [result[0].idPrest,req.body.idFunc,resultado[0].idPet,req.body.idVacina,req.body.idMed,req.body.dataConst],
                        (error, resultados, field)=> {      //tratando o retorno
                        // conn.release();                //IMPORTANTE release: Feacha conexao com o banco
                        if(error){                                  //tratamento de erro da query
                            return res.json({ error:'error'})        
                        }
                        conn.release();
                        return res.json({message : "Cadastrado"});
                    })

            })   
        }) 
    })
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////  BUSCAR MEDICAMENTO  //////////////////////////////////////////////////////////////////////////
exports.buscarPront = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                             //tratamento de erro da conexao
            return res.json({ error: "error"})        
        }
        conn.query('select cliente.nomeCli as nomeCli, pet.nomePet as nomePet, pet.rgPet as rgPet, consulta.idConst as idConst from consulta inner join pet on consulta.idPet =pet.idPet inner join cliente on pet.idCli  = cliente.idCli where consulta.idPrest= ?',[req.body.idPrest],
        (error, resultado, fields) => {
            if(error){                                  //tratamento de erro da query
                return res.json({ error: "error"})        
            }
            if(resultado.length == 0){
                return res.json({ message: "Prontuario nao encontrado"})
            }
            const response = {
                Prontuario: resultado.map(prod => {
                    return  {
                        nomeCli: prod.nomeCli ,
                        nomePet: prod.nomePet ,
                        rgPet: prod.rgPet ,
                        idConst: prod.idConst 
                        // NomeMed: prod.NomeMed ,
                        // idPet: prod.idPet
                    };
                })
            };
             conn.release();  
            return res.json({ response });              
        })
    })
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////  FILTRO PRONTUARIO  //////////////////////////////////////////////////////////////////////////
exports.FiltroPront = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "Falhou"})        
        }
        conn.query('select cliente.nomeCli as nomeCli, pet.nomePet as nomePet, pet.rgPet as rgPet, consulta.idConst as idConst from consulta inner join pet on consulta.idPet =pet.idPet inner join cliente on pet.idCli  = cliente.idCli where pet.rgPet = ?',[req.body.rgPet],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "Falhou"})        
                }
                if(resultado.length == 0){
                    return res.json({ message: "Prontuario nao encontrado"})
                }

                const response = {
                    Prontuario: resultado.map(prod => {
                        return  {
                            nomeCli: prod.nomeCli ,
                            nomePet: prod.nomePet ,
                            rgPet: prod.rgPet ,
                            idConst: prod.idConst 
                            // NomeMed: prod.NomeMed ,
                            // idPet: prod.idPet
                        };
                    })
                };
                conn.release();  
                return res.json({ response });              
            }
        )
    })
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////  VISUALIZAR PRONTUARIO  /////////////////////////////////////////////////////////////////////
exports.BuscarInfo = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "error"})        
        }
        conn.query('select prestadores.nomePrest as nomePrest, funcionario.nomeFunc as nomeFunc, consulta.dataConst as dataConst,pet.rgPet as rgPet, pet.nomePet as nomePet,consulta.idVacina as idVacina,consulta.idMed as idMed from consulta inner join pet on consulta.idPet = pet.idPet inner join prestadores on prestadores.idPrest = consulta.idPrest inner join funcionario on funcionario.idFunc = consulta.idFunc where consulta.idConst=?',[req.body.idConst],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "error"})        
                }
                if(resultado.length == 0){
                    return res.json({ message: "Prontuario nao encontrado"})
                }

                if(resultado[0].idVacina != "Não" && resultado[0].idMed == "Não"){
                    conn.query('select prestadores.nomePrest as nomePrest, consulta.idVacina as idVacina,consulta.idMed as idMed, funcionario.nomeFunc as nomeFunc, consulta.dataConst as dataConst,pet.rgPet as rgPet, pet.nomePet as nomePet,vacina.nomeVacina as nomeVacina, vacina.qntDoseVacina as qntDoseVacina,vacina.loteVacina as loteVacina, vacina.dataApliVacina as dataApliVacina, vacina.dataProxVacina as dataProxVacina,vacina.observacaoVacina as observacaoVacina ,vacina.nomeVetVacina as nomeVetVacina, vacina.emailVetVacina as emailVetVacina,  vacina.crmvVetVacina as crmvVetVacina from consulta inner join pet on consulta.idPet = pet.idPet inner join prestadores on prestadores.idPrest = consulta.idPrest inner join funcionario on funcionario.idFunc = consulta.idFunc inner join vacina on vacina.idVacina = consulta.idVacina where consulta.idVacina = ?',[resultado[0].idVacina],
                        (error, resultado, fields) => {
                            if(error){                                  //tratamento de erro da query
                                return res.json({ error: "error"})        
                            }
                            if(resultado.length == 0){
                                return res.json({ message: "Prontuario com vacina nao encontrado"})
                            }

                            const response = {
                                Prontuario: resultado.map(Pront => {
                                    return  {
                                        nomePrest : Pront.nomePrest,
                                        nomeFunc :Pront.nomeFunc,
                                        dataConst :Pront.dataConst,
                                        rgPet : Pront.rgPet,
                                        nomePet : Pront.nomePet,
                                        idVacina: Pront.idVacina,
                                        idMed: Pront.idMed,
                                        nomeMed :"",
                                        doseMed :"",
                                        loteMed :"",
                                        observacaoMed :"",
                                        dataIniMed :"",
                                        dataFinMed :"",
                                        rotinaMed :"",
                                        nomeEstbMed :"",
                                        emailEstbMed :"",
                                        nomeVacina :Pront.nomeVacina,
                                        qntDoseVacina :Pront.qntDoseVacina,
                                        loteVacina :Pront.loteVacina,
                                        dataApliVacina :Pront.dataApliVacina,
                                        dataProxVacina :Pront.dataProxVacina,
                                        observacaoVacina :Pront.observacaoVacina,
                                        nomeVetVacina :Pront.nomeVetVacina,
                                        emailVetVacina:Pront.emailVetVacina,
                                        crmvVetVacina :Pront.crmvVetVacina
                                    };
                                })
                            };
        
                            conn.release();  
                            return res.json({ response });        
                        }
                    )
                }
                else if(resultado[0].idVacina == "Não" && resultado[0].idMed != "Não"){
                    conn.query('select prestadores.nomePrest as nomePrest,consulta.idVacina as idVacina,consulta.idMed as idMed,  funcionario.nomeFunc as nomeFunc, consulta.dataConst as dataConst,pet.rgPet as rgPet, pet.nomePet as nomePet,medicamento.nomeMed as nomeMed, medicamento.doseMed as doseMed,medicamento.loteMed as loteMed, medicamento.observacaoMed as observacaoMed, medicamento.dataIniMed as dataIniMed,medicamento.dataFinMed as dataFinMed ,medicamento.rotinaMed as rotinaMed, medicamento.nomeEstbMed as nomeEstbMed, medicamento.emailEstbMed as emailEstbMed from consulta inner join pet on consulta.idPet = pet.idPet inner join prestadores on prestadores.idPrest = consulta.idPrest inner join funcionario on funcionario.idFunc = consulta.idFunc inner join medicamento on medicamento.idMed = consulta.idMed where consulta.idMed = 1',[resultado[0].idMed],
                        (error, resultado, fields) => {
                            if(error){                                  //tratamento de erro da query
                                return res.json({ error: "error"})        
                            }
                            if(resultado.length == 0){ 
                                return res.json({ message: "Prontuario com medicacao nao encontrado"})
                            }

                            const response = {
                                Prontuario: resultado.map(Pront => {
                                    return  {
                                        nomePrest : Pront.nomePrest,
                                        nomeFunc :Pront.nomeFunc,
                                        dataConst :Pront.dataConst,
                                        rgPet : Pront.rgPet,
                                        nomePet : Pront.nomePet,
                                        idVacina: Pront.idVacina,
                                        idMed: Pront.idMed,
                                        nomeMed :Pront.nomeMed,
                                        doseMed :Pront.doseMed,
                                        loteMed :Pront.loteMed,
                                        observacaoMed :Pront.observacaoMed,
                                        dataIniMed :Pront.dataIniMed,
                                        dataFinMed :Pront.dataFinMed,
                                        rotinaMed :Pront.rotinaMed,
                                        nomeEstbMed :Pront.nomeEstbMed,
                                        emailEstbMed :Pront.emailEstbMed,
                                        nomeVacina :"",
                                        qntDoseVacina :"",
                                        loteVacina :"",
                                        dataApliVacina :"",
                                        dataProxVacina :"",
                                        observacaoVacina :"",
                                        nomeVetVacina :"",
                                        emailVetVacina:"",
                                        crmvVetVacina :"",
                                        
                                    };
                                })
                            };
        
                            conn.release();  
                            return res.json({ response });     
                        }
                    )
                }
                else if(resultado[0].idVacina != "Não" && resultado[0].idMed != "Não"){
                    conn.query('select prestadores.nomePrest as nomePrest, consulta.idVacina as idVacina,consulta.idMed as idMed,  funcionario.nomeFunc as nomeFunc, consulta.dataConst as dataConst,pet.rgPet as rgPet, pet.nomePet as nomePet,medicamento.nomeMed as nomeMed, medicamento.doseMed as doseMed,medicamento.loteMed as loteMed, medicamento.observacaoMed as observacaoMed, medicamento.dataIniMed as dataIniMed,medicamento.dataFinMed as dataFinMed ,medicamento.rotinaMed as rotinaMed, medicamento.nomeEstbMed as nomeEstbMed, medicamento.emailEstbMed as emailEstbMed,vacina.nomeVacina as nomeVacina, vacina.qntDoseVacina as qntDoseVacina,vacina.loteVacina as loteVacina, vacina.dataApliVacina as dataApliVacina,  vacina.dataProxVacina as dataProxVacina,vacina.observacaoVacina as observacaoVacina ,vacina.nomeVetVacina as nomeVetVacina, vacina.emailVetVacina as emailVetVacina, vacina.crmvVetVacina from consulta inner join pet on consulta.idPet = pet.idPet inner join prestadores on prestadores.idPrest = consulta.idPrest inner join funcionario on funcionario.idFunc = consulta.idFunc inner join medicamento on medicamento.idMed = consulta.idMed inner join vacina on vacina.idVacina = consulta.idVacina where consulta.idVacina = ? and consulta.idMed = ?',[resultado[0].idVacina,resultado[0].idMed ],
                        (error, resultado, fields) => {
                            if(error){                                  //tratamento de erro da query
                                return res.json({ error: "error"})        
                            }
                            if(resultado.length == 0){
                                return res.json({ message: "Prontuario ambos nao encontrado"})
                                
                            }
                            const response = {
                                Prontuario: resultado.map(Pront => {
                                    return  {
                                        nomePrest : Pront.nomePrest,
                                        nomeFunc :Pront.nomeFunc,
                                        dataConst :Pront.dataConst,
                                        rgPet : Pront.rgPet,
                                        nomePet : Pront.nomePet,
                                        idVacina: Pront.idVacina,
                                        idMed: Pront.idMed,
                                        nomeMed :Pront.nomeMed,
                                        doseMed :Pront.doseMed,
                                        loteMed :Pront.loteMed,
                                        observacaoMed :Pront.observacaoMed,
                                        dataIniMed :Pront.dataIniMed,
                                        dataFinMed :Pront.dataFinMed,
                                        rotinaMed :Pront.rotinaMed,
                                        nomeEstbMed :Pront.nomeEstbMed,
                                        emailEstbMed :Pront.emailEstbMed,
                                        nomeVacina :Pront.nomeVacina,
                                        qntDoseVacina :Pront.qntDoseVacina,
                                        loteVacina :Pront.loteVacina,
                                        dataApliVacina :Pront.dataApliVacina,
                                        dataProxVacina :Pront.dataProxVacina,
                                        observacaoVacina :Pront.observacaoVacina,
                                        nomeVetVacina :Pront.nomeVetVacina,
                                        emailVetVacina:Pront.emailVetVacina,
                                        crmvVetVacina :Pront.crmvVetVacina
                                    };
                                })
                            };
        
                            conn.release();  
                            return res.json({ response });     
                        }
                    )
                }
                else{
                    const response = {
                        Prontuario: resultado.map(Pront => {
                            return  {
                                nomePrest : Pront.nomePrest,
                                nomeFunc :Pront.nomeFunc,
                                dataConst :Pront.dataConst,
                                rgPet : Pront.rgPet,
                                nomePet : Pront.nomePet,
                                idVacina: Pront.idVacina,
                                idMed: Pront.idMed,
                                nomeMed :"",
                                doseMed :"",
                                loteMed :"",
                                observacaoMed :"",
                                dataIniMed :"",
                                dataFinMed :"",
                                rotinaMed :"",
                                nomeEstbMed :"",
                                emailEstbMed :"",
                                nomeVacina :"",
                                qntDoseVacina :"",
                                loteVacina :"",
                                dataApliVacina :"",
                                dataProxVacina :"",
                                observacaoVacina :"",
                                nomeVetVacina :"",
                                emailVetVacina:"",
                                crmvVetVacina :"",
                            };
                        })
                    };

                    conn.release();  
                    return res.json({ response });     
                }          
            }
        )
    })
}