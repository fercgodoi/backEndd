const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
const nodemailer = require("nodemailer");               //para enviar emails
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

/*                                                    ENVIAR EMAIL                                                               */
let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa"                                       
    }
});
/*                                                    ---------------                                                              */


/*                                                       GERAR SENHA                                                                  */
function getRandomInt() { return Math.floor(Math.random() * (999999 - 100000)) + 100000; }
/*                                                    ---------------                                                              */





/*                                                    BUSCAR AGENDAMENTO                                                                  */
exports.buscarAgendamento = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select cliente.nomeCli, pet.racaPet,agendamento.tipoServicoAgend,agendamento.formaPagtAgend,agendamento.DataAgend,agendamento.HoraAgend from agendamento inner join pet on pet.idPet = agendamento.idPet inner join cliente on pet.idCliente = cliente.idCliente where agendamento.idPrest = ?', [req.prestador.idPrest],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Agendamento: resultado.map(agend => {
                        return  {
                            nomeCli: agend.nomeCli,
                            racaPet: agend.racaPet,
                            tipoServicoAgend: agend.tipoServicoAgend,
                            formaPagtAgend: agend.formaPagtAgend,
                            DataAgend: agend.DataAgend,
                            HoraAgend: agend.HoraAgend,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */


/*                                                    BUSCAR AGENDAMENTO  CONFIRMADOS                                                             */
exports.buscarAgendamentoConf = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select cliente.nomeCli, pet.racaPet,agendamento.tipoServicoAgend,agendamento.formaPagtAgend,agendamento.DataAgend,agendamento.HoraAgend from agendamento inner join pet on pet.idPet = agendamento.idPet inner join cliente on pet.idCliente = cliente.idCliente where agendamento.idPrest = ? and agendamento.StatusAgend= ?', [req.prestador.idPrest,'Confirmado'],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Agendamento: resultado.map(agend => {
                        return  {
                            nomeCli: agend.nomeCli,
                            nomePet: agend.nomePet,
                            racaPet: agend.racaPet,
                            tipoServicoAgend: agend.tipoServicoAgend,
                            formaPagtAgend: agend.formaPagtAgend,
                            DataAgend: agend.DataAgend,
                            HoraAgend: agend.HoraAgend,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */


/*                                                    CONTAGEM DE AGENDAMENTO                                                                 */
exports.ContagemAgendamento = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query(' SELECT COUNT(idAgend) AS contador from agendamento where idPrest= ?', [req.prestador.idPrest],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Agendamento: resultado.map(agend => {
                        return  {
                            contador: agend.contador,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */



/*                                                    CONFIRMARÇÃO DE AGENDAMENTO                                                                 */

exports.ConfirmarAgendamento = (req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        bcrypt.hash(req.body.senhaCli, 10, (errBcrypt, hash) =>{
            if(errBcrypt){ return res.status(500).send({ error: errBcrypt }) }
            conn.query('update agendamento set StatusAgend="Confirmado" where idPrest=?',[req.prestador.idPrest],
                (error, resultado, field)=> {                  
                    conn.release();                           
                    if(error){                                  
                        return res.status(500).send({ message:"Error server", error: error})        
                    }

                    return res.status(200).send({message:'Senha alterada com sucesso' ,response: resultado})

                }
            )
        })
    }) 
}
/*                                                             ---------------                                                              */



/*                                                    NEGAÇÃO DE AGENDAMENTO                                                                 */

exports.NegarAgendamento = (req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        bcrypt.hash(req.body.senhaCli, 10, (errBcrypt, hash) =>{
            if(errBcrypt){ return res.status(500).send({ error: errBcrypt }) }
            conn.query('update agendamento set StatusAgend="Negado" where idPrest=?',[req.prestador.idPrest],
                (error, resultado, field)=> {                  
                    conn.release();                           
                    if(error){                                  
                        return res.status(500).send({ message:"Error server", error: error})        
                    }

                    return res.status(200).send({message:'Senha alterada com sucesso' ,response: resultado})

                }
            )
        })
    }) 
}
/*                                                             ---------------                                                              */

