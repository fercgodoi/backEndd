const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
const nodemailer = require("nodemailer");               //para enviar emails
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

/*                                                    ENVIAR EMAIL                                                               */
let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa1"                                       
    }
});
/*                                                    ---------------                                                              */


/*                                                       GERAR CODIGO                                                                  */
function getRandomInt() { return Math.floor(Math.random() * (999999 - 100000)) + 100000; }
/*                                                    ---------------                                                              */



/*                                                    LOGIN                                                                */
exports.LoginFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){ return res.json({ error: error}) }      //tratamento de erro da conexao
        conn.query('select * from funcionario where EmailFunc= ?',[req.body.EmailFunc],
            (error, result, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "Error de requisição"})        
                }

                if(result.length < 1){                 //tratamento de erro de autenticação
                    return res.json({message: "Usuario inexistente"})      //trocar retorno para falha de autenticação//
                }

                bcrypt.compare(req.body.senha, result[0].SenhaFunc, (err, resultCript)=> {           //comparando a senha hash com a senha enviada
                    if(err){ return res.json( "falha na autenticação") }
                    
                    if(resultCript){
                        
                    const token = jwt.sign({
                        idPrest: result[0].idPrest
                    }, process.env.JWT_KEY, {
                        expiresIn:"24H"
                    });
                        
                    const response = {                          //tratando o retorno
                        Funcionarios: result.map(func => {
                            return{
                                idFunc: func.idFunc,
                                StatusFunc: func.StatusFunc,
                                TimeFunc: func.TimeFunc,
                                CodFunc: func.CodFunc,
                                AcessoFunc:func.AcessoFunc,
                            }
                        })
                    }

                  

                    let timeSist = Date.now();
                    let timeFuncTot = response.Funcionarios[0].TimeFunc + 86400000;

                    if(response.Funcionarios[0].StatusFunc === 'Confirmado'){          
                        if(timeSist > timeFuncTot){     
                            let passRandom = getRandomInt();

                            conn.query('update funcionario set CodFunc= ?, TimeFunc = ? where idFunc = ? ',[passRandom, timeSist, response.Funcionarios[0].idFunc],
                                (error, result, fields) => {
                                    conn.release();
                                    if(error){                                  //tratamento de erro da query
                                        return res.json({ error: error})        
                                    }
                                    return res.json({ message: 'Seu codigo expirou, enviamos um novo codigo para seu email'})
                                    //enviar o codigo pelo email//
                                    /* transporter.sendMail({
                                        from: "  One <oneforasteiro@gmail.com>",
                                        to: response.Clientes[0].emailCli,               
                                        subject: "Codigo de verificação",
                                        text: `Faça login novamente no app com esta senha: ${passRandom}`
                                        //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
                                    }).then(message => {
                                        res.status(202).send({ mensagem: message})
                                    }).catch(err =>{
                                        res.status(404).send({ mensagem: "nao deu"})
                                    }) */

                                }
                            ) 
                        }else{                        
                                return res.json({
                                    response: response.Funcionarios[0].idFunc,
                                    message: "Confirmar Codigo",
                                    token: token
                                })
                            } 
                    }else if(response.Funcionarios[0].StatusFunc === 'Pendente'){
                        return res.json({
                            response: response.Funcionarios[0].idFunc,
                            message: "Trocar Senha",
                            token: token
                        })
                    }
                    else if(response.Funcionarios[0].StatusFunc === 'Excluido'){
                        return res.json({
                            response: response.Funcionarios[0].idFunc,
                            message: "Não Pode logar",
                            token: token
                        })
                    }
                    else{
                          return res.json({
                            response: response.Funcionarios[0].idFunc,
                            message: "Logar",
                            token: token,
                            acesso:response.Funcionarios[0].AcessoFunc
                        })
                    }
                } 
                return res.json({ error: 'falha na autenticação'})
            })   

            conn.release();
            } //termina aquii
        )     
    })
}
/*                                                    ---------------                                                              */





/*                                                    CADASTRAR FUNCIONARIO                                                               */
exports.CadastroFuncionario = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: error})        
        } 
        conn.query('select * from funcionario where EmailFunc = ? or CpfFunc = ?', [req.body.EmailFunc,req.body.CpfFunc],
        (error, result, field)=> {
            if(error){return res.json({ error:'error '})}
            if(result.length >= 1){
                if(result[0].EmailFunc == req.body.EmailFunc){
                    return res.json({ message: "Ja existe Email"})
                }
                if(result[0].CpfFunc == req.body.CpfFunc){
                    return res.json({ message: "Ja existe CPF"})
                }           
            }

                let passRandom = getRandomInt();
                let timeCodFunc = Date.now();
                let senha = "123456";
                    //return res.status(200).send("1")    //aceito
                bcrypt.hash(senha, 10, (errBcrypt, hash) =>{
                    if(errBcrypt){ return res.json({ error: errBcrypt }) }
                    conn.query('insert into funcionario(idPrest,CelFunc, NomeFunc,EmailFunc,CpfFunc,RecepFunc ,VetFunc,AdminFunc ,FinanFunc ,AcessoFunc ,StatusFunc,HorarioFunc , SenhaFunc,TimeFunc,CodFunc) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        [req.body.idPrest,req.body.NomeFunc,req.body.CelFunc,req.body.EmailFunc,req.body.CpfFunc,req.body.RecepFunc,req.body.VetFunc,req.body.AdminFunc,req.body.FinanFunc,req.body.AcessoFunc,"Confirmado",req.body.HorarioFunc,hash,timeCodFunc,passRandom],
                        (error, resultado, field)=> {                  //tratando o retorno
                                                       //IMPORTANTE release: fechar a conexao com a nossa query 
                            if(error){                                  //tratamento de erro da query
                                return res.json({ error: error})        
                            }
                            return res.json({message: "Cadastrado"})

                            // transporter.sendMail({
                            //     from: "  One <oneforasteiro@gmail.com>",
                            //     to: req.body.email,               
                            //     subject: "Recuperar senha",
                            //     text: `Faça login novamente no app com esta senha: ${passRandom}`
                            //     //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
                            // }).then(message => {
                            //    res.json({ 
                            //         mensagem: message, 
                            //         message:'Bem vindo ao app, enviamos um codigo ao seu email',
                            //         resultado: resultado
                            //     })
                            // }).catch(err =>{
                            //     res.json({ mensagem: "nao deu", error: err, email: req.body.email})
                            // }) 
                            //COLOCAR CODIGO P ENVIAR EMAIL                 <========================FEITOOOOOOOO
                            
                        }
                    )
                }) 

                conn.release();
            }
        )
    })
}

/*                                                    ---------------                                                              */



/*                                                    CODIGO FUNCIONARIO                                                               */
exports.CodFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return  res.json({ error: "falha na autenticação"})        
        }
        conn.query('select * from funcionario where CpfFunc = ? and CodFunc = ?',[ req.body.CpfFunc , req.body.CodFunc],
            (error, result, fields) => {
                if(error){                                  //tratamento de erro da query
                    return  res.json({ error:  "falha na autenticação"})        
                }

                if(result.length < 1){
                    return  res.json({ message: 'Codigo incorreto' })
                } else{
                    conn.query('update funcionario set StatusFunc = ? where CpfFunc = ? ',['Confirmado', req.body.CpfFunc],
                        (error, resultado, fields) => {
                            if(error){                                  //tratamento de erro da query
                                return  res.json({ error:  "falha na autenticação"})        
                            }
                            return  res.json({message: "ok"}) 
                        }
                    )
                }
                conn.release();
            }
        )     
    })
}
/*                                                    ---------------                                                              */



/*                                                    ESQUECI SENHA FUNCIONARIO                                                               */
exports.EsqueciSenhaFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.json({ message:'error sql', error: error})        
        }
        conn.query('select * from funcionario where EmailFunc = ?', [req.body.EmailFunc],
            (error, result, field)=> {
                if(error){return res.json({ message:'error sql', error: error})}
                if(result.length == 0){
                    return res.json({ message: "Usuario nao encontrado"})
                }

                let passRandom = String(getRandomInt()) ;
                console.log(passRandom)

                bcrypt.hash(passRandom, 10, (err, hash) =>{
                    if(err){ return res.json({ message: "erro no bcript", errou: err }) } 
                
                        conn.query(`update funcionario set SenhaFunc = ?, StatusFunc = ? where EmailFunc = ? `, [hash, 'Pendente', req.body.EmailFunc],
                            (error, resultado, field)=> {              
                                if(error){                
                                    return res.json({ error: error})         
                                }

                                // return res.status(202).send({ mensagem: resultado})
                                    // colocar aquii
                                transporter.sendMail({
                                    from: "  One <oneforasteiro@gmail.com>",
                                    to: req.body.EmailFunc,               
                                    subject: "Recuperar senha",
                                    text: `Faça login novamente no app com esta senha: ${passRandom}`
                                    //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
                                }).then(message => {
                                    res.json({message:'Enviamos uma nova senha, verifique seu email' , mensagem: message})
                                }).catch(err =>{
                                    res.json({ message: "nao deu", error: err})
                                }) 
                                
                        })
                })
                conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */


/*                                                    TROCA SENHA FUNCIONARIO                                                               */
exports.TrocarSenhaFunc = (req, res, next) => {       
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.json({  message: "error sql",error: error})        
        }
        conn.query('select * from funcionario where EmailFunc = ?', [req.body.EmailFunc],
            (error, result, field)=> {
                if(error){return res.json({ message:'error sql', error: error})}
                if(result.length == 0){
                    return res.json({ message: "Usuario nao encontrado"})
                }


                bcrypt.hash(req.body.SenhaFunc, 10, (err, hash) =>{
                    if(err){ return res.json({ error: "erro no bcript", errou: err }) }     

                        conn.query(`update funcionario set SenhaFunc = ?, StatusFunc = ? where EmailFunc = ? `, [hash, 'Confirmado', req.body.EmailFunc],
                            (error, resultado, field)=> {                 
                                if(error){                
                                    return res.json({  message: "nao deu",error: error})         
                                }
                                return res.json({  message: "deu certo", mensagem: resultado}) //colocar aquii       
                        })
                })
                conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */



/*                                                    BUSCAR FUNCIONARIOS                                                                 */
exports.BuscarFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "Falhou"})        
        } 
        conn.query('select * from funcionario where idPrest = ?', [req.body.idPrest],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "Falhou"})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Funcionario: resultado.map(func => {
                        return  {
                            idFunc:func.idFunc,
                            NomeFunc:func.NomeFunc,
                            EmailFunc:func.EmailFunc,
                            CpfFunc:func.CpfFunc,
                            RecepFunc:func.RecepFunc,
                            VetFunc:func.VetFunc,
                            AdminFunc:func.AdminFunc,
                            FinanFunc:func.FinanFunc,
                            AcessoFunc:func.AcessoFunc,
                            StatusFunc:func.StatusFunc,
                            HorarioFunc:func.HorarioFunc,
                            CelFunc:func.CelFunc
                        };
                    })
                };
                return res.json({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */


/*                                                    EXCLUIR FUNCIONARIO                                                               */
exports.ExcluirFunc = (req, res, next) => {       
    // mysql.getConnection((error, conn) =>{
    //     if(error){                                  //tratamento de erro da conexao
    //         return res.status(500).send({ error: error})        
    //     }       
    //     conn.query(`update funcionario set StatusFunc = ? where idFunc = ?`, ["Excluido", req.body.idFunc],
    //         (error, resultado, field)=> {                  
    //             if(error){                
    //                 return res.status(500).send({ error: error})         
    //             }
    //             return res.status(202).send({ mensagem: resultado}) //colocar aquii       
    //     })
    //     conn.release();
            
    // }) 
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "Falhou"})        
        } 
        conn.query('delete from funcionario where idFunc=?', [req.body.idFunc],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "Falhou"})        
                }
                //return res.status(200).send({response: resultado})                
                               
                return res.json({ message : "deletou" });
            })                     
    })
}
/*                                                    ---------------                                                              */

/*                                                    TROCA SENHA FUNCIONARIO                                                               */
exports.AtualizarFunc = (req, res, next) => {       
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error:'error sql'})        
        }
        conn.query('select * from funcionario where EmailFunc = ? or CpfFunc = ?', [req.body.EmailFunc,req.body.CpfFunc],
            (error, result, field)=> {
                if(error){return res.json({ error:'error sql'})}
                if(result.length >= 1){
                    if(result[0].EmailFunc != req.body.EmailFunc){
                        return res.json({ message: "Ja existe Email"})
                    }
                    if(result[0].CpfFunc != req.body.CpfFunc){
                        return res.json({ message: "Ja existe CPF"})
                    }                   
                }
                conn.query(`update funcionario set NomeFunc = ?,EmailFunc=?,CpfFunc= ?,RecepFunc=?,VetFunc= ?,AdminFunc= ?,FinanFunc= ?,AcessoFunc= ?, CelFunc= ?, HorarioFunc= ? where idFunc = ? `, [req.body.NomeFunc,req.body.EmailFunc,req.body.CpfFunc,req.body.RecepFunc,req.body.VetFunc,req.body.AdminFunc,req.body.FinanFunc,req.body.AcessoFunc, req.body.CelFunc,req.body.HorarioFunc,req.body.idFunc],
                    (error, resultado, field)=> {                 
                    if(error){                
                        return res.json({ error:error})         
                    }
                    return res.json({ message: "Atualizado"}) //colocar aquii       
                })               
                 conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */

/*                                                    BUSCAR FUNCIONARIO                                                                 */
exports.Buscar = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "Falhou"})        
        } 
        conn.query('select * from funcionario where idFunc = ?', [req.body.idFunc],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "Falhou"})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Funcionario: resultado.map(func => {
                        return  {
                            idFunc:func.idFunc,
                            NomeFunc:func.NomeFunc,
                            EmailFunc:func.EmailFunc,
                            CpfFunc:func.CpfFunc,
                            RecepFunc:func.RecepFunc,
                            VetFunc:func.VetFunc,
                            AdminFunc:func.AdminFunc,
                            FinanFunc:func.FinanFunc,
                            AcessoFunc:func.AcessoFunc,
                            StatusFunc:func.StatusFunc,
                            HorarioFunc:func.HorarioFunc,
                            CRMVFunc:func.CRMVFunc,
                            DateEmiFunc:func.DateEmiFunc,
                            CelFunc: func.CelFunc
                        };
                    })
                };
                return res.json({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */
