const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
const nodemailer = require("nodemailer");               //para enviar emails
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

/*                                                    ENVIAR EMAIL                                                               */
let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa"                                       
    }
});
/*                                                    ---------------                                                              */


/*                                                       GERAR CODIGO                                                                  */
function getRandomInt() { return Math.floor(Math.random() * (999999 - 100000)) + 100000; }
/*                                                    ---------------                                                              */



/*                                                    LOGIN                                                                */
exports.LoginFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){ return res.status(500).send({ error: error}) }      //tratamento de erro da conexao
        conn.query('select * from funcionario where EmailFunc= ?',[req.body.EmailFunc],
            (error, result, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: 'Error de requisição'})        
                }

                if(result.length < 1){                 //tratamento de erro de autenticação
                    return res.status(401).send({response: "Usuario inexistente"})      //trocar retorno para falha de autenticação//
                }

                bcrypt.compare(req.body.senha, result[0].SenhaFunc, (err, resultCript)=> {           //comparando a senha hash com a senha enviada
                    if(err){ return res.status(500).send( 'error: falha na autenticação') }
                    
                    if(resultCript){
                        
                    const token = jwt.sign({
                        idPrest: result[0].idPrest
                    }, process.env.JWT_KEY, {
                        expiresIn:"24H"
                    });
                        
                    const response = {                          //tratando o retorno
                        Funcionarios: result.map(func => {
                            return{
                                idFunc: func.idFunc,
                                StatusFunc: func.StatusFunc,
                                TimeFunc: func.TimeFunc,
                                CodFunc: func.CodFunc
                            }
                        })
                    }

                    let timeSist = Date.now();
                    let timeFuncTot = response.Funcionarios[0].TimeFunc + 86400000;

                    if(response.Funcionarios[0].StatusFunc === 'Confirmado'){                      
                    // }else 
                        if(timeSist > timeFuncTot){     
                            let passRandom = getRandomInt();

                            conn.query('update funcionario set CodFunc= ?, TimeFunc = ? where idFunc = ? ',[passRandom, timeSist, response.Funcionarios[0].idFunc],
                                (error, result, fields) => {
                                    conn.release();
                                    if(error){                                  //tratamento de erro da query
                                        return res.status(500).send({ error: error})        
                                    }
                                    return res.status(200).send({ message: 'Seu codigo expirou, enviamos um novo codigo para seu email'})
                                    //enviar o codigo pelo email//
                                    /* transporter.sendMail({
                                        from: "  One <oneforasteiro@gmail.com>",
                                        to: response.Clientes[0].emailCli,               
                                        subject: "Codigo de verificação",
                                        text: `Faça login novamente no app com esta senha: ${passRandom}`
                                        //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
                                    }).then(message => {
                                        res.status(202).send({ mensagem: message})
                                    }).catch(err =>{
                                        res.status(404).send({ mensagem: "nao deu"})
                                    }) */

                                }
                            ) 
                        }else{                        
                                return res.status(200).send({
                                    response: response.Funcionarios[0].idFunc,
                                    message: "Confirmar Codigo",
                                    token: token
                                })
                            } 
                    }else if(response.Funcionarios[0].StatusFunc === 'Pendente'){
                        return res.status(200).send({
                            response: response.Funcionarios[0].idFunc,
                            message: "Trocar Senha",
                            token: token
                        })
                    }
                    else if(response.Funcionarios[0].StatusFunc === 'Excluido'){
                        return res.status(200).send({
                            response: response.Funcionarios[0].idFunc,
                            message: "Não Pode logar",
                            token: token
                        })
                    }
                    else{
                          return res.status(200).send({
                            response: response.Funcionarios[0].idFunc,
                            message: "Logar",
                            token: token
                        })
                    }
                } 
                return res.status(500).send({ error: 'falha na autenticação'})
            })   

            conn.release();
            } //termina aquii
        )     
    })
}
/*                                                    ---------------                                                              */





/*                                                    CADASTRAR FUNCIONARIO                                                               */
exports.CadastroFuncionario = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select * from funcionario where EmailFunc = ? and CpfFunc=?',[req.body.EmailFunc,req.body.CpfFunc],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                if(resultado.length > 0 ){
                    return res.status(409).send("Usuario ja existente")    //nao aceita, usuario ja existente
                }

                let passRandom = getRandomInt();
                let timeCodFunc = Date.now();
                    //return res.status(200).send("1")    //aceito
                bcrypt.hash(req.body.senha, 10, (errBcrypt, hash) =>{
                    if(errBcrypt){ return res.status(500).send({ error: errBcrypt }) }
                    conn.query('insert into funcionario(idPrest,NomeFunc,EmailFunc,CpfFunc,RecepFunc ,VetFunc,AdminFunc ,FinanFunc ,AcessoFunc ,StatusFunc,HorarioFunc , SenhaFunc,TimeFunc,CodFunc) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        [req.prestador.idPrest,req.body.NomeFunc,req.body.EmailFunc,req.body.CpfFunc,req.body.RecepFunc,req.body.VetFunc,req.body.AdminFunc,req.body.FinanFunc,req.body.AcessoFunc,"Confirmado",req.body.HorarioFunc,hash,timeCodFunc,passRandom],
                        (error, resultado, field)=> {                  //tratando o retorno
                            conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                            if(error){                                  //tratamento de erro da query
                                return res.status(500).send({ error: error})        
                            }

                            //return res.status(200).send({response: resultado})

                            transporter.sendMail({
                                from: "  One <oneforasteiro@gmail.com>",
                                to: req.body.email,               
                                subject: "Recuperar senha",
                                text: `Faça login novamente no app com esta senha: ${passRandom}`
                                //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
                            }).then(message => {
                                res.status(202).send({ 
                                    mensagem: message, 
                                    message:'Bem vindo ao app, enviamos um codigo ao seu email',
                                    resultado: resultado
                                })
                            }).catch(err =>{
                                res.status(404).send({ mensagem: "nao deu", error: err, email: req.body.email})
                            }) 
                            //COLOCAR CODIGO P ENVIAR EMAIL                 <========================FEITOOOOOOOO

                        }
                    )
                })     
            }
        )
    })
}

/*                                                    ---------------                                                              */



/*                                                    CODIGO FUNCIONARIO                                                               */
exports.CodFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query('select * from funcionario where idFunc = ? && CodFunc = ?;',[ req.body.idFunc , req.body.codigo],
            (error, result, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }

                if(result.length < 1){
                    return res.status(500).send({ message: 'Codigo incorreto' })
                } else{
                    conn.query('update funcionario set StatusFunc = ? where idFunc = ? ;',['Confirmado', req.body.idFunc],
                        (error, resultado, fields) => {
                            conn.release();
                            if(error){                                  //tratamento de erro da query
                                return res.status(500).send({ error: error})        
                            }
                            return res.status(200).send({response: "Seu perfil esta verificado, aproveite o app"}) 
                        }
                    )
                }
                conn.release();
            }
        )     
    })
}
/*                                                    ---------------                                                              */



/*                                                    ESQUECI SENHA FUNCIONARIO                                                               */
exports.EsqueciSenhaFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query('select * from funcionario where EmailFunc = ?', [req.body.EmailFunc],
            (error, result, field)=> {
                if(error){return res.status(500).send({ msg:'error sql', error: error})}
                if(result.length == 0){
                    return res.status(404).send({ msg: "Usuario nao encontrado"})
                }

                let passRandom = String(getRandomInt()) ;
                console.log(passRandom)

                bcrypt.hash(passRandom, 10, (err, hash) =>{
                    if(err){ return res.status(500).send({ error: "erro no bcript", errou: err }) } 
                
                        conn.query(`update funcionario set SenhaFunc = ?, StatusFunc = ? where EmailFunc = ? `, [hash, 'Pendente', req.body.EmailFunc],
                            (error, resultado, field)=> {     
                                conn.release();                
                                if(error){                
                                    return res.status(500).send({ error: error})         
                                }
                                //return res.status(202).send({ mensagem: resultado})
                                    //colocar aquii
                                transporter.sendMail({
                                    from: "  One <oneforasteiro@gmail.com>",
                                    to: req.body.email,               
                                    subject: "Recuperar senha",
                                    text: `Faça login novamente no app com esta senha: ${passRandom}`
                                    //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
                                }).then(message => {
                                    res.status(202).send({msg:'Enviamos uma nova senha, verifique seu email' , mensagem: message})
                                }).catch(err =>{
                                    res.status(404).send({ msg: "nao deu", error: err})
                                }) 
                                
                        })
                })
                conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */


/*                                                    TROCA SENHA FUNCIONARIO                                                               */
exports.TrocarSenhaFunc = (req, res, next) => {       
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query('select * from funcionario where EmailFunc = ?', [req.body.EmailFunc],
            (error, result, field)=> {
                if(error){return res.status(500).send({ msg:'error sql', error: error})}
                if(result.length == 0){
                    return res.status(404).send({ msg: "Usuario nao encontrado"})
                }


                bcrypt.hash(req.body.SenhaFunc, 10, (err, hash) =>{
                    if(err){ return res.status(500).send({ error: "erro no bcript", errou: err }) }     

                        conn.query(`update funcionario set SenhaFunc = ?, StatusFunc = ? where EmailFunc = ? `, [hash, 'Confirmado', req.body.EmailFunc],
                            (error, resultado, field)=> {     
                                conn.release();                
                                if(error){                
                                    return res.status(500).send({ error: error})         
                                }
                                return res.status(202).send({ mensagem: resultado}) //colocar aquii       
                        })
                })
                conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */



/*                                                    BUSCAR FUNCIONARIOS                                                                 */
exports.BuscarFunc = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select * from funcionario where idPrest = ?', [req.prestador.idPrest],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Funcionario: resultado.map(func => {
                        return  {
                            idFunc:func.idFunc,
                            NomeFunc:func.NomeFunc,
                            EmailFunc:func.EmailFunc,
                            CpfFunc:func.CpfFunc,
                            RecepFunc:func.RecepFunc,
                            VetFunc:func.VetFunc,
                            AdminFunc:func.AdminFunc,
                            FinanFunc:func.FinanFunc,
                            AcessoFunc:func.AcessoFunc,
                            StatusFunc:func.StatusFunc,
                            HorarioFunc:func.HorarioFunc
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */


/*                                                    EXCLUIR FUNCIONARIO                                                               */
exports.ExcluirFunc = (req, res, next) => {       
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
       
        conn.query(`update funcionario set StatusFunc = ? where idFunc = ?`, ['Excluido', req.body.idFunc],
            (error, resultado, field)=> {     
                conn.release();                
                if(error){                
                    return res.status(500).send({ error: error})         
                }
                return res.status(202).send({ mensagem: resultado}) //colocar aquii       
        })
        conn.release();
            
    }) 
}
/*                                                    ---------------                                                              */

/*                                                    TROCA SENHA FUNCIONARIO                                                               */
exports.AtualizarFunc = (req, res, next) => {       
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query('select * from funcionario where EmailFunc = ? and CpfFunc=?', [req.body.EmailFunc,req.body.CpfFunc],
            (error, result, field)=> {
                if(error){return res.status(500).send({ msg:'error sql', error: error})}
                if(result.length < 1){
                    return res.status(401).send({ msg: "Usuario ja cadastrado"})
                }
                bcrypt.hash(req.body.SenhaFunc, 10, (err, hash) =>{
                    if(err){ return res.status(500).send({ error: "erro no bcript", errou: err }) }     

                        conn.query(`update funcionario set NomeFunc = ?,EmailFunc=?,CpfFunc= ?,RecepFunc=?,VetFunc= ?,AdminFunc= ?,FinanFunc= ?,AcessoFunc= ?,HorarioFunc= ? where idFunc = ? `, [req.body.NomeFunc,req.body.EmailFunc,req.body.CpfFunc,req.body.RecepFunc,req.body.VetFunc,req.body.AdminFunc,req.body.FinanFunc,req.body.AcessoFunc,req.body.HorarioFunc,req.body.idFunc],
                            (error, resultado, field)=> {     
                                conn.release();                
                                if(error){                
                                    return res.status(500).send({ error: error})         
                                }
                                return res.status(202).send({ mensagem: resultado}) //colocar aquii       
                        })
                })
                conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */


