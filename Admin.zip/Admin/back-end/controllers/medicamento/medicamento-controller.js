const mysql = require('../../mysql').pool;
const jwt = require('jsonwebtoken');
const nodemailer = require("nodemailer");               //para enviar emails


//---------------------------------BLOCO EMAIL------------------------------------------------------//

// let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
//     host:"imap.gmail.com",                                     
//     port: 465,
//     secure: true,
//     auth: {
//         user: "oneforasteiro@gmail.com",
//         pass: process.env.EMAIL_KEY                                         
//     }
// });


//---------------------------------------------------------------//

///////////////////////////////////////////////////////////////  CADASTRO MEDICAMENTOS /////////////////////////////////////////////////////////////////////////
exports.CadastroMed = (req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error:'error sql'})        
        }
        conn.query('select prestadores.EmailPrest as EmailPrest, prestadores.NomePrest as NomePrest, prestadores.idPrest as idPrest from funcionario inner join prestadores on Prestadores.idPrest = funcionario.idPrest where funcionario.idFunc= ?', [req.body.idFunc],
        (error, result, field)=> {
            if(error){return res.json({ error:'error sql'})}
            if(result.length == 0){
                return res.json({ message: "Vet nao encontrado"})
            }

            conn.query('select * from pet where rgPet = ?', [req.body.rgPet],
            (error, resultado, field)=> {
                if(error){return res.json({ error:'error sql'})}
                if(resultado.length == 0){
                    return res.json({ message: "Pet nao encontrado"})
                }

                conn.query('insert into medicamento(idPet,idPrest,statusMed,doseMed,rotinaMed,dataIniMed,dataFinMed,nomeMed,nomeEstbMed,emailEstbMed,loteMed,observacaoMed,confirmMed) values (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [resultado[0].idPet,result[0].idPrest, req.body.statusMed, req.body.doseMed, req.body.rotinaMed, req.body.dataIniMed,req.body.dataFinMed, req.body.nomeMed,result[0].NomePrest, result[0].EmailPrest,  req.body.loteMed, req.body.observacaoMed,"Confirmado"],
                        (error, resultados, field)=> {      //tratando o retorno
                        // conn.release();                //IMPORTANTE release: Feacha conexao com o banco
                        if(error){                                  //tratamento de erro da query
                            return res.json({ error:'error c'})        
                        }
                        conn.release();
                        return res.json({message : "Cadastrado", id :resultados.insertId});
                    })

            })   
        }) 
    })
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////  BUSCAR MEDICAMENTO  //////////////////////////////////////////////////////////////////////////
exports.buscarMed = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                             //tratamento de erro da conexao
            return res.json({ error: "error"})        
        }
        conn.query('select cliente.nomeCli as nomeCli, pet.nomePet as nomePet, pet.rgPet as rgPet, medicamento.idMed as idMed, medicamento.NomeMed as NomeMed, medicamento.idPet as idPet from medicamento inner join pet on medicamento.idPet =pet.idPet  inner join cliente on pet.idCli  = cliente.idCli where medicamento.idPrest = ? and medicamento.statusMed = "Vigente"',[req.body.idPrest],
        (error, resultado, fields) => {
            if(error){                                  //tratamento de erro da query
                return res.json({ error: "error"})        
            }
            if(resultado.length == 0){
                return res.json({ message: "Medicamento nao encontrado"})
            }

            const response = {
                Medicamento: resultado.map(med => {
                    return  {
                        nomeCli: med.nomeCli ,
                        nomePet: med.nomePet ,
                        rgPet: med.rgPet ,
                        idMed: med.idMed ,
                        NomeMed: med.NomeMed ,
                        idPet: med.idPet
                    };
                })
            };
            // conn.release();  
            return res.json({ response });              
        })
    })
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////  FILTRO MEDICAMENTO  //////////////////////////////////////////////////////////////////////////
exports.FiltroMed = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "error"})        
        }
        conn.query('select cliente.nomeCli as nomeCli, pet.nomePet as nomePet, pet.rgPet as rgPet, medicamento.idMed as idMed, medicamento.NomeMed as NomeMed, medicamento.idPet as idPet from medicamento inner join pet on medicamento.idPet =pet.idPet  inner join cliente on pet.idCli  = cliente.idCli where pet.rgPet = ? and medicamento.statusMed = "Vigente"',[req.body.rgPet],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "error"})        
                }
                if(resultado.length == 0){
                    return res.json({ message: "Medicamento nao encontrado"})
                }

                const response = {
                    Medicamento: resultado.map(med => {
                        return  {
                            nomeCli: med.nomeCli ,
                            nomePet: med.nomePet ,
                            rgPet: med.rgPet ,
                            idMed: med.idMed ,
                            NomeMed: med.NomeMed ,
                            idPet: med.idPet
                        };
                    })
                };
                conn.release();  
                return res.json({ response });              
            }
        )
    })
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////  VISUALIZAR MEDICAMENTO  /////////////////////////////////////////////////////////////////////
exports.BuscarInfo = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "error"})        
        }
        conn.query('select pet.nomePet as nomePet, pet.rgPet as rgPet, medicamento.nomeMed as nomeMed, medicamento.doseMed as doseMed, medicamento.loteMed as loteMed, medicamento.rotinaMed as rotinaMed, medicamento.observacaoMed as observacaoMed, medicamento.dataIniMed as dataIniMed, medicamento.dataFinMed as dataFinMed, medicamento.nomeEstbMed as nomeEstbMed, medicamento.emailEstbMed as emailEstbMed from medicamento inner join pet on medicamento.idPet = pet.idPet where  medicamento.idMed = ?',[req.body.idMed],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "error"})        
                }
                if(resultado.length == 0){
                    return res.json({ message: "Vacina nao encontrado"})
                }

                const response = {
                    Medicamento: resultado.map(med => {
                        return  {
                            nomePet: med.nomePet ,
                            rgPet: med.rgPet ,
                            nomeMed: med.nomeMed ,
                            doseMed: med.doseMed ,
                            loteMed: med.loteMed ,
                            rotinaMed: med.rotinaMed ,
                            observacaoMed: med.observacaoMed,
                            dataIniMed: med.dataIniMed ,
                            dataFinMed: med.dataFinMed,
                            nomeEstbMed: med.nomeEstbMed,
                            emailEstbMed: med.emailEstbMed
                        };
                    })
                };
                conn.release();  
                return res.json({ response });              
            }
        )
    })
}