const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
const nodemailer = require("nodemailer");               //para enviar emails
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

/*                                                    ENVIAR EMAIL                                                               */
let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa"                                       
    }
});
/*                                                    ---------------                                                              */



/*                                                    BUSCAR PETS                                                                 */
exports.BuscarPets = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select pet.nomePet,pet.racaPet,pet.dataPet,pet.castPet,pet.sexoPet,pet.fotoPet from agendamento inner join pet on agendamento.idPet = pet.idPet where idAgend = ?', [req.body.idAgend],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Pet: resultado.map(pet => {
                        return  {
                            nomePet: pet.nomePet,
                            racaPet: pet.racaPet,
                            dataPet: pet.dataPet,
                            castPet: pet.castPet,
                            fotoPet: pet.fotoPet,
                            sexoPet: pet.sexoPet,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */

