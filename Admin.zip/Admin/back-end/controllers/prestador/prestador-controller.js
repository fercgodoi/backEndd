const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
const nodemailer = require("nodemailer");               //para enviar emails
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

/*                                                    ENVIAR EMAIL                                                               */
let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa"                                       
    }
});
/*                                                    ---------------                                                              */


/*                                                       GERAR CODIGO                                                                  */
function getRandomInt() { return Math.floor(Math.random() * (999999 - 100000)) + 100000; }
/*                                                    ---------------                                                              */



// /*                                                    LOGIN                                                                */
// exports.LoginPrest = (req, res, next) => {       //rota passando parametro
//     mysql.getConnection((error, conn) => {
//         if(error){ return res.status(500).send({ error: error}) }      //tratamento de erro da conexao
//         conn.query('select * from prestadores where EmailPrest= ?',[req.body.EmailPrest],
//             (error, result, fields) => {
//                 if(error){                                  //tratamento de erro da query
//                     return res.status(500).send({ error: 'Error de requisição'})        
//                 }

//                 if(result.length < 1){                 //tratamento de erro de autenticação
//                     return res.status(401).send({response: "Usuario inexistente"})      //trocar retorno para falha de autenticação//
//                 }

//                 bcrypt.compare(req.body.senha, result[0].SenhaFunc, (err, resultCript)=> {           //comparando a senha hash com a senha enviada
//                     if(err){ return res.status(500).send( 'error: falha na autenticação') }
                    
//                     if(resultCript){
                        
//                     const token = jwt.sign({
//                         idPrest: result[0].idPrest
//                     }, process.env.JWT_KEY, {
//                         expiresIn:"24H"
//                     });
                        
//                     const response = {                          //tratando o retorno
//                         Prestadores: result.map(prest => {
//                             return{
//                                 idPrest: prest.isPrest,
//                                 StatusPrest: prest.StatusFunc,
//                                 TimePrest: prest.TimeFunc,
//                                 CodPrest: prest.CodFunc
//                             }
//                         })
//                     }

//                     let timeSist = Date.now();
//                     let timeFuncTot = response.Prestadores[0].TimePrest + 86400000;

//                     if(response.Prestadores[0].StatusFunc === 'Confirmado'){                      
//                     // }else 
//                         if(timeSist > timeFuncTot){     
//                             let passRandom = getRandomInt();

//                             conn.query('update prestadores set CodPrest= ?, TimePrest = ? where idPrest = ? ',[passRandom, timeSist, response.Prestadores[0].idPrest],
//                                 (error, result, fields) => {
//                                     conn.release();
//                                     if(error){                                  //tratamento de erro da query
//                                         return res.status(500).send({ error: error})        
//                                     }
//                                     return res.status(200).send({ message: 'Seu codigo expirou, enviamos um novo codigo para seu email'})
//                                     //enviar o codigo pelo email//
//                                     /* transporter.sendMail({
//                                         from: "  One <oneforasteiro@gmail.com>",
//                                         to: response.Clientes[0].emailCli,               
//                                         subject: "Codigo de verificação",
//                                         text: `Faça login novamente no app com esta senha: ${passRandom}`
//                                         //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
//                                     }).then(message => {
//                                         res.status(202).send({ mensagem: message})
//                                     }).catch(err =>{
//                                         res.status(404).send({ mensagem: "nao deu"})
//                                     }) */

//                                 }
//                             ) 
//                         }else{                        
//                                 return res.status(200).send({
//                                     response: response.Funcionarios[0].idPrest,
//                                     message: "Confirmar Codigo",
//                                     token: token
//                                 })
//                             } 
//                     }else if(response.Prestadores[0].StatusFunc === 'Pendente'){
//                         return res.status(200).send({
//                             response: response.Funcionarios[0].idPrest,
//                             message: "Trocar Senha",
//                             token: token
//                         })
//                     }
//                     else if(response.Prestadores[0].StatusFunc === 'Excluido'){
//                         return res.status(200).send({
//                             response: response.Funcionarios[0].idPrest,
//                             message: "Não Pode logar",
//                             token: token
//                         })
//                     }
//                     else{
//                           return res.status(200).send({
//                             response: response.Prestadores[0].idPrest,
//                             message: "Logar",
//                             token: token
//                         })
//                     }
//                 } 
//                 return res.status(500).send({ error: 'falha na autenticação'})
//             })   

//             conn.release();
//             } //termina aquii
//         )     
//     })
// }
// /*                                                    ---------------                                                              */




/*                                                    CADASTRO PRESTADOR                                                            */
exports.CadastroPrestador = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select * from responsavel where EmailResp = ? and CpfResp=?',[req.body.EmailResp,req.body.CpfResp],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                if(resultado.length > 0 ){
                    return res.status(409).send("Responsavel ja existente")    //nao aceita, usuario ja existente
                    }
            conn.query('insert into responsavel(NomeResp,CpfResp,CelResp,EmailResp,VetResp,CRMVResp,DataEmiResp)values(?,?,?,?,?,?,?)',
            [req.body.NomeResp,req.body.CpfResp,req.body.CelResp,req.body.EmailResp,req.body.VetResp,req.body.CRMVResp,req.body.DataEmiResp],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
            //return res.status(200).send({response: resultado})
                const response = {                          //tratando o retorno
                    Responsavel: result.map(resp => {
                        return{
                        idResp:resp.idResp
                        }
                    })
                }

                // return res.status(200).send({
                //     response: response.Responsavel[0].idResp,
                //     message: "Cadastro Reponsave com sucesso",
                //     token: token
                // })

                    let passRandom = getRandomInt();
                    let timCodPrest = Date.now();
                    bcrypt.hash(req.body.SenhaPrest, 10, (errBcrypt, hash) =>{
                        conn.query('insert into prestadores (idResp,NomePrest,CelularPrest,CnpjPrest,NomeFantsPrest,PetShopPrest,ClinicaPrest,OngPrest,PasseadorPrest,HotelPrest,PetSiterPrest,CepPrestNumPrest,EmergenciaPrest,LogoPrest,HorarioPrest ,SenhaPrest ,EmailPrest ,StatusPrest,CodPrest,TimePrest) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        [response.Responsavel[0].idResp,req.body.NomePrest,req.body.CelularPrest,req.body.CnpjPrest,req.body.NomeFantsPrest,req.body.PetShopPrest,req.body.ClinicaPrest,req.body.OngPrest,req.body.PasseadorPrest,req.body.HotelPrest,req.body.PetSiterPrest,req.body.CepPrestNumPrest,req.body.EmergenciaPrest,req.body.LogoPrest,req.body.HorarioPrest,hash,req.body.EmailPrest,'Confirmado',timCodPrest,passRandom],
                        (error, resultado, field)=> {                  //tratando o retorno
                            conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                            if(error){                                  //tratamento de erro da query
                                return res.status(500).send({ error: error})        
                            }
                            const response = {                          //tratando o retorno
                                Prestadores: result.map(prest => {
                                    return{
                                    idPrest:prest.idPrest
                                    }
                                })
                            }
        
                            // return res.status(200).send({
                            //     response: response.Prestadores[0].idPrest,
                            //     message: "Cadastro prestador com sucesso",
                            //     token: token
                            // })
                        
                            conn.query('insert into conta(idPrest,ContaCont,BancoCont,AgenciaCont,TipoCont,CartCont,CieloCont) values (?,?,?,?,?,?,?)',
                            [response.Prestadores[0].idPrest,req.body.ContaCont,req.body.BancoCont,req.body.AgenciaCont,req.body.TipoCont,req.body.CartCont,req.body.CieloCont],
                            (error, resultado, field)=> {                  //tratando o retorno
                                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                                if(error){                                  //tratamento de erro da query
                                    return res.status(500).send({ error: error})        
                                }
                                const response = {                          //tratando o retorno
                                    Conta: result.map(Conta => {
                                        return{
                                        idCont:Conta.idCont
                                        }
                                    })
                                }

                                return res.status(200).send({
                                    response: response.Conta[0].idCont,
                                    message: "Cadastro prestador com sucesso",
                                    token: token
                                })
                
                            })
                        })
                    })
            })
        })
        conn.release();
    })
}

/*                                                    ---------------                                                              */



/*                                                    HORARIO PRESTADOR                                                               */
exports.HorarioPrest = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        
        conn.query('update prestadores set HoraPrest=? where idPrest=?',[req.body.HorarioPrest, req.prestadores.idPrest],
            (error, resultado, fields) => {
                conn.release();
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                return res.status(200).send({response: "Horario Alterado"}) 
            }
        )    
     conn.release();
        
    })
}
/*                                                    ---------------                                                              */




// /*                                                    CODIGO PRESTADOR                                                               */
// exports.codPrestador = (req, res, next) => {       //rota passando parametro
//     mysql.getConnection((error, conn) => {
//         if(error){                                  //tratamento de erro da conexao
//             return res.status(500).send({ error: error})        
//         }
//         conn.query('select * from prestadores where CodPrest = ?;',[req.body.CodPrest],
//             (error, result, fields) => {
//                 if(error){                                  //tratamento de erro da query
//                     return res.status(500).send({ error: error})        
//                 }

//                 if(result.length < 1){
//                     return res.status(500).send({ message: 'Codigo incorreto' })
//                 } else{
//                     conn.query('update prestadores set StatusPrest = ? where CodPrest = ? ;',['Confirmado', req.body.CodPrest],
//                         (error, resultado, fields) => {
//                             conn.release();
//                             if(error){                                  //tratamento de erro da query
//                                 return res.status(500).send({ error: error})        
//                             }
//                             return res.status(200).send({response: "Seu perfil esta verificado, aproveite o app"}) 
//                         }
//                     )
//                 }
//                 conn.release();
//             }
//         )     
//     })
// }
// /*                                                    ---------------                                                              */





// /*                                                    ESQUECI SENHA PRESTADOR                                                               */
// exports.EsqueciSenhaPrest = (req, res, next) => {       //rota passando parametro
//     mysql.getConnection((error, conn) =>{
//         if(error){                                  //tratamento de erro da conexao
//             return res.status(500).send({ error: error})        
//         }
//         conn.query('select * from prestadores where EmailPrest = ?', [req.body.EmailPrest],
//             (error, result, field)=> {
//                 if(error){return res.status(500).send({ msg:'error sql', error: error})}
//                 if(result.length == 0){
//                     return res.status(404).send({ msg: "Usuario nao encontrado"})
//                 }

//                 let passRandom = String(getRandomInt()) ;
//                 console.log(passRandom)

//                 bcrypt.hash(passRandom, 10, (err, hash) =>{
//                     if(err){ return res.status(500).send({ error: "erro no bcript", errou: err }) } 
                
//                         conn.query(`update prestadores set SenhaPrest = ?, StatusPrest = ? where EmailPrest = ? `, [hash, 'Pendente', req.body.EmailPrest],
//                             (error, resultado, field)=> {     
//                                 conn.release();                
//                                 if(error){                
//                                     return res.status(500).send({ error: error})         
//                                 }
//                                 //return res.status(202).send({ mensagem: resultado})
//                                     //colocar aquii
//                                 transporter.sendMail({
//                                     from: "  One <oneforasteiro@gmail.com>",
//                                     to: req.body.email,               
//                                     subject: "Recuperar senha",
//                                     text: `Faça login novamente no app com esta senha: ${passRandom}`
//                                     //html: "caso precise vc pode passar um html, fica mais bonito e creio que podemos passar informaçoes nesse html sobre redirecionar p outra api"
//                                 }).then(message => {
//                                     res.status(202).send({msg:'Enviamos uma nova senha, verifique seu email' , mensagem: message})
//                                 }).catch(err =>{
//                                     res.status(404).send({ msg: "nao deu", error: err})
//                                 }) 
                                
//                         })
//                 })
//                 conn.release();
//             })
//     }) 
// }
// /*                                                    ---------------                                                              */


// /*                                                    TROCA SENHA PRESTADOR                                                               */
// exports.TrocarSenhaPrest = (req, res, next) => {       
//     mysql.getConnection((error, conn) =>{
//         if(error){                                  //tratamento de erro da conexao
//             return res.status(500).send({ error: error})        
//         }
//         conn.query('select * from prestadores where EmailPrest = ?', [req.body.EmailPrest],
//             (error, result, field)=> {
//                 if(error){return res.status(500).send({ msg:'error sql', error: error})}
//                 if(result.length == 0){
//                     return res.status(404).send({ msg: "Usuario nao encontrado"})
//                 }


//                 bcrypt.hash(req.body.SenhaFunc, 10, (err, hash) =>{
//                     if(err){ return res.status(500).send({ error: "erro no bcript", errou: err }) }     

//                         conn.query(`update prestadores set SenhaPrest = ?, StatusPrest = ? where EmailPrest = ? `, [hash, 'Confirmado', req.body.EmailPrest],
//                             (error, resultado, field)=> {     
//                                 conn.release();                
//                                 if(error){                
//                                     return res.status(500).send({ error: error})         
//                                 }
//                                 return res.status(202).send({ mensagem: resultado}) //colocar aquii       
//                         })
//                 })
//                 conn.release();
//             })
//     }) 
// }
/*                                                    ---------------                                                              */



/*                                                    Atualizar prestador                                                               */

exports.AtualizarPrest = (req, res, next) => {       
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query('select * from prestadores where EmailPrest = ? and CnpjPrest=?', [req.body.EmailPrest,req.body.CnpjPrest],
            (error, result, field)=> {
                if(error){return res.status(500).send({ msg:'error sql', error: error})}
                if(result.length < 1){
                    return res.status(401).send({ msg: "Usuario ja cadastrado"})
                }
                bcrypt.hash(req.body.SenhaFunc, 10, (err, hash) =>{
                    if(err){ return res.status(500).send({ error: "erro no bcript", errou: err }) }     

                        conn.query(` update prestadores set NomePrest =?,CelularPrest=?,CnpjPrest =?,NomeFantsPrest =?,PetShopPrest =?,ClinicaPrest =?,OngPrest =?,PasseadorPrest =?,HotelPrest =?,PetSiterPrest =?,CepPrest =?,NumPrest =?,EmergenciaPrest =?,LogoPrest =?,SenhaPrest =?,EmailPrest =? where idPrest=? `, [req.body.NomePrest,req.body.CelularPrest,req.body.CnpjPrest,req.body.NomeFantsPrest,req.body.PetShopPrest,req.body.ClinicaPrest,req.body.OngPrest,req.body.PasseadorPrest,req.body.HotelPrest,req.body.PetSiterPrest,req.body.NumPrest,req.body.EmergenciaPrest,req.body.LogoPrest,req.body.SenhaPrest,req.body.EmailPrest,req.prestadores.idPrest],
                            (error, resultado, field)=> {     
                                conn.release();                
                                if(error){                
                                    return res.status(500).send({ error: error})         
                                }
                                return res.status(202).send({ mensagem: resultado}) //colocar aquii       
                        })
                })
                conn.release();
            })
    }) 
}
/*                                                    ---------------                                                              */


