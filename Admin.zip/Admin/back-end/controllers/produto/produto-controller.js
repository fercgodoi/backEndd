const mysql = require('../../mysql').pool;              //para conectar ao banco
const multer = require('multer');                       //para salvar imagens
const nodemailer = require("nodemailer");               //para enviar emails
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

/*                                                    ENVIAR EMAIL                                                               */
let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa"                                       
    }
});
/*                                                    ---------------                                                              */



/*                                                    BUSCAR PRODUTOS                                                                */
exports.BuscarProdutos = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select * from produto where idPrest=?', [req.body.idPrest],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Produto: resultado.map(prod => {
                        return  {
                            idProd:prod.idProd,
                            NomeProd:prod.NomeProd,
                            DescProd:prod.DescProd,
                            PrecoProd:prod.PrecoProd,
                            QuantProd:prod.QuantProd,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */





/*                                                    BUSCAR PRODUTO                                                                */
exports.Buscar = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: "Falhou"})        
        } 
        conn.query('select * from produto where idProd=?', [req.body.idProd],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: "Falhou"})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Produto: resultado.map(prod => {
                        return  {
                            NomeProd:prod.NomeProd,
                            DescProd:prod.DescProd,
                            PrecoProd:prod.PrecoProd,
                            QuantProd:prod.QuantProd,
                            ImgProd:prod.ImgProd,
                            ImgsProd:prod.ImgsProd,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/*                                                    ---------------                                                              */




/*                                                    DELETAR PRODUTO                                                                */
exports.DeletarProd = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "Falhou"})        
        } 
        conn.query('delete from produto where idProd=?', [req.body.idProd],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "Falhou"})        
                }
                //return res.status(200).send({response: resultado})                
                               
                return res.json({ message : "deletou" });
            })                     
    })
}
/*                                                    ---------------                                                              */


/*                                                    FILTRAR PRODUTOS                                                                */
exports.FiltrarProd = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        } 
        conn.query('select * from produto where NomeProd=? and idPrest=?', [req.body.NomeProd,req.body.idPrest],
            (error, resultado, field)=> {                  //tratando o retorno
                conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                if(error){                                  //tratamento de erro da query
                    return res.status(500).send({ error: error})        
                }
                //return res.status(200).send({response: resultado})                

                const response = {
                    Produto: resultado.map(prod => {
                        return  {
                            NomeProd:prod.NomeProd,
                            DescProd:prod.DescProd,
                            PrecoProd:prod.PrecoProd,
                            QuantProd:prod.QuantProd,
                        };
                    })
                };
                return res.status(200).send({ response });
            })                     
    })
}
/* 



/*                                                    CADASTRAR PRODUTOS                                                               */
exports.CadastrarProdutos = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: 'Falhou'})        
        } 
        conn.query('select * from produto where NomeProd = ?', [req.body.NomeProd],
            (error, result, field)=> {
                if(error){return res.json({ message:'error sql', error: error})}
                // return res.json(result);
                if(result.length >= 1) {
                    return res.json({ message :'Já existe'})
                }
               
            conn.query('insert into produto(idPrest,NomeProd,DescProd,PrecoProd,QuantProd,ImgProd,ImgsProd) values(?,?,?,?,?,?,?)',
                [req.body.idPrest, req.body.NomeProd, req.body.DescProd, req.body.PrecoProd, req.body.QuantProd,req.body.ImgProd,req.body.ImgsProd],
                (error, resultado, field)=> {                  //tratando o retorno
                    conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                    if(error){                                  //tratamento de erro da query
                        return res.status(500).send({ error: 'Falhou'})        
                    }
                    return res.status(200).send({message: 'Cadastrado'})
                }            
            )
        }
        )
    })  
}
/*                                                    ---------------                                                              */



/*                                                    EDITAR PRODUTOS                                                               */
exports.EditarProd = (req, res, next) => {       //rota passando parametro
    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: 'Falhou'})        
        } 
        conn.query('select * from produto where NomeProd = ?', [req.body.NomeProd],
            (error, result, field)=> {
                if(error){return res.json({ message:'error sql', error: error})}
                // return res.json(result);
                if(result.length >= 1) {
                    return res.json({ message :'Já existe'})
                }
                conn.query('update produto set NomeProd=?, DescProd= ?,PrecoProd= ?, QuantProd= ?, ImgProd=?, ImgsProd=? where idProd=?',
                [req.body.NomeProd, req.body.DescProd, req.body.PrecoProd, req.body.QuantProd,req.body.ImgProd,req.body.ImgsProd,req.body.idProd],
                (error, resultado, field)=> {                  //tratando o retorno
                    conn.release();                            //IMPORTANTE release: fechar a conexao com a nossa query 
                    if(error){                                  //tratamento de erro da query
                        return res.status(500).send({ error: 'Falhou'})        
                    }
                    return res.status(200).send({message: 'Alterado'})
                }            
            )
        }
        )
    })  
}
/*                                                    ---------------                                                              */