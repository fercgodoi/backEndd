const mysql = require('../../mysql').pool;
const jwt = require('jsonwebtoken');
const nodemailer = require("nodemailer");               //para enviar emails

//---------------------------------BLOCO EMAIL------------------------------------------------------//

let transporter = nodemailer.createTransport({                  //configurando a minha conta, dados da conta q vai enviar//
    host:"imap.gmail.com",                                     
    port: 465,
    secure: true,
    auth: {
        user: "oneforasteiro@gmail.com",
        pass: "largatixa1"                                       
    }
});

///////////////////////////////////////////////////////////////  INSERIR VACINA  //////////////////////////////////////////////////////////////////////////

exports.inserirVacina = (req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }

        conn.query('select * from funcionario where idFunc = ?', [req.body.idFunc],
            (error, result, field)=> {
                if(error){return res.json({ error:'error sql'})}
                if(result.length == 0){
                    return res.json({ message: "Vet nao encontrado"})
                }

                conn.query('select * from pet where rgPet = ?', [req.body.rgPet],
                    (error, resultado, field)=> {
                        if(error){return res.json({ error:'error sql'})}
                        if(resultado.length == 0){
                            return res.json({ message: "Pet nao encontrado"})
                        }

                        conn.query('insert into vacina(dataApliVacina, dataProxVacina, nomeVacina, qntDoseVacina, loteVacina, valorVacina, nomeVetVacina, emailVetVacina, crmvVetVacina, idPet,idPrest,idFunc,observacaoVacina,statusVacina)  values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)',
                            [req.body.dataApliVacina, req.body.dataProxVacina, req.body.nomeVacina, req.body.qntDoseVacina, req.body.loteVacina, req.body.valorVacina, result[0].NomeFunc, result[0].EmailFunc, result[0].CRMVFunc, resultado[0].idPet,result[0].idPrest,result[0].idFunc,req.body.observacaoVacina,"Vigente"],
                            (error, resultados, field)=> {      //tratando o retorno
                                                //IMPORTANTE release: Feacha conexao com o banco
                                if(error){                                  //tratamento de erro da query
                                    return res.status(500).send({ error: "error sql"})        
                                }
                                conn.release();
                                return res.json({message : "Cadastrado"});
                                
                            }
                        )
                    }
                )
            }
        )
 
    }) 
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//----------TESTEEEE---------------------------//
exports.teste = (req, res, next) => {
    var idVac = req.body.idVac;
    var resp = req.body.resp;
    //res.send({ idVac: idVac ,resultado: resp})
    res.send(EnviarVacVet(idVac, resp));
}; 

//-------------------------------------------//


exports.atualizarVacina = (req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query('update vacina set dataApliVacina = ?, dataProxVacina = ?, nomeVacina = ?, qntDoseVacina = ?, loteVacina = ?, valorVacina = ?,  nomeVetVacina = ?, emailVetVacina = ?, crmvVetVacina = ?, statusVacina = ?,  confirmaVacina = ? where idVacina = ?',
                 [req.body.dataApliVacina, req.body.dataProxVacina, req.body.nomeVacina, req.body.qntDoseVacina, req.body.loteVacina, req.body.valorVacina, req.body.nomeVetVacina, req.body.emailVetVacina, req.body.crmvVetVacina, 'Pendente', 0 , req.body.idVacina],
                 (error, resultado, field)=> {      //tratando o retorno
                     conn.release();                //IMPORTANTE release: liberar a conexao com a nossa query 
                     if(error){                                  //tratamento de erro da query
                        return res.status(500).send({ error: error})        
                    }

                    var dataApliVacina = req.body.dataApliVacina.split('-').reverse().join('-'); //colocando a data para o formato dd/mm/yyyy
                    var dataProxVacina = req.body.dataProxVacina.split('-').reverse().join('-');

                    const token = jwt.sign({
                        idVacina: req.body.idVacina,
                        dataApliVacina: dataApliVacina,
                        dataProxVacina: dataProxVacina,
                        nomeVacina: req.body.nomeVacina,
                        qntDoseVacina: req.body.qntDoseVacina,
                        nomePet: req.body.nomePet,                      // <==================
                        nomeVetVacina: req.body.nomeVetVacina,
                        emailVetVacina: req.body.emailVetVacina,
                        crmvVetVacina: req.body.crmvVetVacina
                    }, process.env.JWT_KEY, {
                        expiresIn:"48H"
                    });

                    // //enviar o codigo pelo email//
                    // transporter.sendMail({
                    // from: "  One <oneforasteiro@gmail.com>",
                    // to: req.body.emailVetVacina,               
                    // subject: "O Agenda animal tem uma notificação para você",
                    // text: ``,
                    // html: `<!DOCTYPE HTML>
                    // <html lang=”pt-br”>
                    // <head>
                    // <meta charset=”UTF-8”>
                    // <link rel=”stylesheet” type=”text/css” href=”estilo.css”>
                    // <title></title>
                    // </head>
                    // <body>
                    //     <h1>Ola Somos o Agenda animal!!</h1>
                    //     <h3>Um tutor informa q vc vacinou um de seus animaizinhos, acesse o link a abaixo e confira</h3>
                        
                    //     <a href="http://localhost:3000/vacina/respostaVacina/${token}" target="_blank" >link</a>
                    // </body>
                    // </html>`

                    //     }).then(message => {
                    //         res.status(202).send({ mensagem: message, resposta:'Vacina atualizada com sucesso, aguardando confirmação do Profissional' })
                    //     }).catch(err =>{
                    //         res.status(404).send({ mensagem: "Falha", error: err})
                    //     }) 

                    //     //res.status(202).send({ resposta:'Vacina atualizada com sucesso, aguardando confirmação do Profissional' })
                }
        )
    }) 
};

exports.deletarVacina =(req, res, next) => {
    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query(`delete from vacina where idVacina = ? `,[req.body.idVacina],
                 (error, resultado, field)=> {      //tratando o retorno
                     conn.release();                //IMPORTANTE release: liberar a conexao com a nossa query 
                     if(error){                                  //tratamento de erro da query
                        return res.status(500).send({ error: error })        
                    }
                     res.status(202).send({                          
                        mensagem: 'Vacina deletada com sucesso',
                        resp: "ok"                       //retorno do id de insert, proprio sql nos retorna
                    })
                }
        )
    }) 
};

///////////////////////////////////////////////////////////////  BUSCAR VACINA  //////////////////////////////////////////////////////////////////////////
exports.buscarVacinas = (req, res, next) => {       //rota passando parametro

    mysql.getConnection((error, conn) => {
        if(error){                                  //tratamento de erro da conexao
            return res.json({ error: "error"})        
        }
        conn.query('select * from vacina where idPrest = ? and statusVacina = "Vigente"',[req.body.idPrest],
            (error, resultado, fields) => {
                if(error){                                  //tratamento de erro da query
                    return res.json({ error: "error"})        
                }
                const response = {
                    Vacina: resultado.map(vac => {
                        return  {
                            idVacina: vac.idVacina ,
                            idFunc: vac.idFunc ,
                            dataApliVacina: vac.dataApliVacina ,
                            dataProxVacina: vac.dataProxVacina ,
                            nomeVacina: vac.nomeVacina ,
                            qntDoseVacina: vac.qntDoseVacina ,
                            loteVacina: vac.loteVacina ,
                            valorVacina: vac.valorVacina ,
                            statusVacina: vac.statusVacina ,
                            confirmaVacina:vac.confirmaVacina ,
                            nomeVetVacina: vac.nomeVetVacina ,
                            emailVetVacina: vac.emailVetVacina ,
                            crmvVetVacina: vac.crmvVetVacina ,
                            observacaoVacina: vac.observacaoVacina ,
                        };
                    })
                };
                conn.release();  
                return res.json({ response });              
            }
        )
    })
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


exports.confirmaVacina = (req, res, next) => {

    let status ;

    if(req.body.confirmaVacina == 1){ status = "Vigente" }
    if(req.body.confirmaVacina == -1 ){ status = "Recusada" }
    if(req.body.dataProxVacina == '' || req.body.dataProxVacina == null || req.body.dataProxVacina == undefined){ req.body.dataProxVacina = null}

    mysql.getConnection((error, conn) =>{
        if(error){                                  //tratamento de erro da conexao
            return res.status(500).send({ error: error})        
        }
        conn.query(`update vacina set dataApliVacina = ?, dataProxVacina = ?, nomeVacina = ?, qntDoseVacina = ?, loteVacina = ?, nomeVetVacina = ?, emailVetVacina = ?, crmvVetVacina = ?, confirmaVacina = ?, statusVacina = ?, observacaoVacina = ?  where idVacina = ?`,
                 [req.body.dataApliVacina,
                 req.body.dataProxVacina, 
                 req.body.nomeVacina, 
                 req.body.qntDoseVacina, 
                 req.body.loteVacina, 
                 req.body.nomeVetVacina, 
                 req.body.emailVetVacina, 
                 req.body.crmvVetVacina, 
                 req.body.confirmaVacina,
                 status,
                 req.body.observacaoVacina, 
                 req.body.idVacina],
                 (error, resultado, field)=> {      //tratando o retorno
                     conn.release();                //IMPORTANTE release: liberar a conexao com a nossa query 
                     if(error){                                  //tratamento de erro da query
                        return res.status(500).send({ resposta:'falhou', error: error})        
                    }
                     res.status(201).send( 'Vacina atualizada com sucesso' )
                }
        )
    }) 
}