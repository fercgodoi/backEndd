drop database agendaanimal;
create database agendaanimal;
use agendaanimal;


SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;



create table recibo(
idRec int not null auto_increment,

Primary Key(idRec)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES recibo WRITE;
UNLOCK TABLES;


create table cliente(
idCli int not null auto_increment,
nomeCli text not null,
cpfCli varchar(15) UNIQUE,
emailCli varchar(225) not null UNIQUE,
telefoneCli text,
cepCli text,
estadoCli text,
cidadeCli text,
ruaCli text,
numeroCli text,
complementoCli text,
fotoCli longblob,
senhaCli text not null,
status_cli varchar(8) DEFAULT 'Pentende',
codigoCli int not null,
timeCodCli bigint not null,

Primary Key(idCli)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES cliente WRITE;
UNLOCK TABLES;



create table pagamento(
idPag int not null auto_increment,
idCli int not null,
numPag text not null,
dataPag text not null,
nomePag text not null,
cpfPag text not null,
ccvPag text not null,
bandeiraPag text not null,
enderecoPag text not null,

Primary Key(idPag),
KEY idCli (idCli),
CONSTRAINT PagamentoCli FOREIGN KEY (idCli) REFERENCES cliente (idCli)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES pagamento WRITE;
UNLOCK TABLES;


create table pet(
idPet int not null auto_increment,
idCli int not null,
nomePet text not null,
dataPet date not null,
fotoPet longblob not null,
pesoPet text not null,
pelagemPet text not null,
especiePet text not null,
racaPet text not null,
sexoPet text not null,
corPet text not null,
castPet text not null,
dataCastPet date,
microshipPet text,
pedigreePet text ,
statusPet text ,
rgPet text,

Primary Key(idPet),
KEY idCli (idCli),
CONSTRAINT petCli FOREIGN KEY (idCli) REFERENCES cliente (idCli)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES pet WRITE;
UNLOCK TABLES;




create table responsavel(
IdResp int not null auto_increment,
NomeResp text not null,
CpfResp varchar(15) not null UNIQUE,
CelResp text not null,
EmailResp varchar(255) not null UNIQUE,
VetResp text not null,
CRMVResp text,
DataEmiResp text,

Primary Key(IdResp)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES responsavel WRITE;
UNLOCK TABLES;



create table prestadores(
IdPrest int not null auto_increment,
IdResp int not null,
EmailPrest text not null,
NomePrest text not null,
CelularPrest text not null,
CnpjPrest varchar(50) not null UNIQUE,
NomeFantsPrest text not null,
PetShopPrest text not null,
ClinicaPrest text not null,
OngPrest text not null,
PasseadorPrest text not null,
HotelPrest text not null,
PetSiterPrest text not null,
CepPrest text not null,
NumPrest text not null,
EmergenciaPrest text not null,
LogoPrest longblob not null,
HorarioPrest text,

Primary Key(idPrest),
KEY IdResp (IdResp),
CONSTRAINT PrestResponsavel FOREIGN KEY (idResp) REFERENCES Responsavel (idResp)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES prestadores WRITE;
UNLOCK TABLES;


create table medicamento(
idMed int not null auto_increment,
idPet int(11) not NULL,
idPrest int(11) ,
statusMed varchar(12) DEFAULT 'Em andamento',
doseMed text NOT NULL,
rotinaMed text,
dataIniMed date NOT NULL,
dataFinMed date DEFAULT NULL,
nomeMed text NOT NULL,
nomeEstbMed text,
emailEstbMed text NOT NULL,
loteMed text NOT NULL,
confirmMed varchar(12) DEFAULT 'Pendente',
observacaoMed text,

Primary Key(idMed),
KEY idPet (idPet),
CONSTRAINT MedicamentoPet FOREIGN KEY (idPet) REFERENCES pet (idPet),
CONSTRAINT MedicamentoPrest FOREIGN KEY (idPrest) REFERENCES Prestadores (idPrest)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES medicamento WRITE;
UNLOCK TABLES;



create table servico(
idServ int not null auto_increment,
idPrest int not null,
BanhoServ text not null,
TosaServ text not null,
VendaServ text not null,
VacinaServ text not null,
HidracaoServ text not null,
EscaDentServ text not null,
CorteUnhaServ text not null,
TinturaPelaServ text not null,
ConsultaServ text not null,
IogaServ text not null,
AcumpunturaServ text not null,
VendaAnimalServ text not null,
TransporteServ text not null,
AdestramentoServ text not null,
SepultamentoServ text not null,
ConsultasGeraisoServ text not null,
ConsultasEspecificasoServ text not null,
RadiologiaoServ text not null,
HemoterapiaoServ text not null,
ExamesoServ text not null,
CirurgiaoServ  text not null,
CastracaooServ text not null,
ExamesSangueoServ text not null,
EutanasiaServ text not null,
RemocaoServ text not null,
ExamesParasitologicoServ text not null,
AnestesiaoServ text not null,
CremacaoServ text not null,
SepultamentooServ text not null,
TransfusaoSangueoServ text not null,
HospedagemServ text not null,
DogWalkerServ text not null,
NatacaoServ text not null,
CrecheServ text not null,

Primary Key(idServ),
KEY idPrest (idPrest),
CONSTRAINT ServicoPrest FOREIGN KEY (idPrest) REFERENCES prestadores (idPrest)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES servico WRITE;
UNLOCK TABLES;


create table produto(
idProd int not null auto_increment,
idPrest int not null,
NomeProd text not null,
DescProd text not null,
PrecoProd text not null,
QuantProd text not null,
ImgProd longblob not null,
ImgsProd longblob,


Primary Key(idProd),
Key idPrest (idPrest),
CONSTRAINT ProdutoPrest FOREIGN KEY (idPrest) REFERENCES Prestadores (idPrest)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES produto WRITE;
UNLOCK TABLES;


create table horarioFunc(
idHorarioFunc int not null auto_increment,
SegundInicio time not null, 
SegundFinal time not null,  
TercaInicio time not null, 
TercaFinal time not null, 
QuartInicio time not null, 
QuartFinal time not null, 
QuintInicio time not null,  
QuintFinal time not null,  
SextInicio time not null, 
SextFinal time not null,  
SabInicio time not null,  
SabFinal time not null, 
DomingInicio time not null,  
DomingFinal time not null,

primary Key(IdHorarioFunc)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES horarioFunc WRITE;
UNLOCK TABLES;

create table funcionario(
idFunc int not null auto_increment,
idHorarioFunc int not null,
idPrest int not null,
NomeFunc text not null,
CelFunc text not null,
EmailFunc varchar(225) not null UNIQUE,
CpfFunc varchar(15) not null UNIQUE,
RecepFunc text not null,
VetFunc text not null,
AdminFunc text not null,
FinanFunc text not null,
AcessoFunc text not null,
StatusFunc varchar(11) not null DEFAULT 'Pendente',
SenhaFunc text not null,
CodFunc int not null,
TimeFunc bigint not null,
CRMVFunc text,
DateEmiFunc date,


Primary Key(idFunc),
KEY idPrest (idPrest),
CONSTRAINT funcionarioPrest FOREIGN KEY (idPrest) REFERENCES Prestadores (idPrest),
CONSTRAINT funcionarioHorario FOREIGN KEY (idHorarioFunc) REFERENCES horarioFunc (idHorarioFunc)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES funcionario WRITE;
UNLOCK TABLES;




create table conta(
idCont int not null auto_increment,
idPrest int not null,
ContaCont text not null,
BancoCont text not null,
AgenciaCont text not null,
TipoCont text not null,
CartCont text not null,
CieloCont text not null,

Primary Key(idCont),
KEY idPrest(IdPrest),
CONSTRAINT contaPrest FOREIGN KEY (idPrest) REFERENCES Prestadores (idPrest)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES conta WRITE;
UNLOCK TABLES;




create table agendamento(
idAgend int not null auto_increment,
idPrest int not null,
idPet int not null,
idFunc int not null,
idRec int not null,
tipoServicoAgend text NOT NULL,
formaPagtAgend text,
ServAgend text not null,
DataAgend date not null,
HoraAgend text not null,
StatusAgend varchar(11) not null DEFAULT 'Pendente',

Primary Key(idAgend),
KEY agendIdPet (idPet),
KEY agendIdPrest (idPrest),
KEY agendIdFunc (idFunc),
KEY agendIdRec (idRec),
CONSTRAINT agendIdPrest FOREIGN KEY (idPrest) REFERENCES Prestadores (idPrest),
CONSTRAINT agendIdPet FOREIGN KEY (idPet) REFERENCES pet (idPet),
CONSTRAINT agendIdFunc FOREIGN KEY (idFunc) REFERENCES funcionario (idFunc),
CONSTRAINT agendIdRec FOREIGN KEY (idRec) REFERENCES recibo (idRec)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES agendamento WRITE;
UNLOCK TABLES;




create table denuncia(
idDen int not null auto_increment,
idCli int not null,
infoDen text not null,
fotoDen text not null,
enderecoDen text not null,
bairroDen text not null,
cidadeDen text not null,
nomeOngDen text not null,
contatoCliDen text not null,
statusDen text not null,
dataDen date not null,

Primary Key(idDen),
KEY idCli (idCli),
CONSTRAINT denunciaCliente FOREIGN KEY (idCli) REFERENCES cliente (idCli)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES denuncia WRITE;
UNLOCK TABLES;



create table PetPerdido(
idPetPerd int not null auto_increment,
idCli int not null,
nomePetPerd text not null,
emailPetPerd text not null,
dataPetPerd date not null,
caractPetPerd text not null,
infoPetPerd text not null,
fotoPetPerd text not null,
localPetPerd text not null,

Primary Key(idPetPerd),
KEY idCli (idCli),
CONSTRAINT PetPerdidoCli FOREIGN KEY (idCli) REFERENCES cliente (idCli)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES PetPerdido WRITE;
UNLOCK TABLES;

create table exames(
idExames int not null auto_increment,
idPrest int not null,
idPet int not null,
Fezes text not null,
RadiologiaSimples text not null,
RadiologiaContrastada text not null,
Eletrocardiograma text not null,
UltrassonografiAbdominal text not null,
HemogramaCompleto text not null,
PesquisaHemoparasitas text not null,
FuncaoHepatica text not null,
SorologicoFIVFELV text not null,
Urina text not null,
AcidoUrico text not null,
Albumina text not null,
ALT text not null,
Amilase text not null,
AST text not null,
Bilirrubina text not null,
CalcioSerico text not null,
Colesterol text not null,
Colinesterase text not null,
CreatinaQuinase text not null,
Creatinina text not null,
FerroSerico text not null,
FosfataseAlcalina text not null,
Fosforo text not null,
Gama text not null,
Glicose text not null,
Magnesio text not null,
ProteinasTotais text not null,
NAKCL text not null,
Triglicerideos text not null,
Ureia text not null,
ExameTumoral text not null,
ExameGinecologico text not null,
GlicemiaJejum text not null,
Biopsia text not null,
SexagemAves text not null,

primary key(idExames),
foreign key(idPrest) references prestadores(idPrest),
foreign key(idPet) references pet(idPet)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES exames WRITE;
UNLOCK TABLES;


create table consulta (
idConst int not null auto_increment,
idPrest int not null,
idFunc int not null,
idPet int not null,
idVacina text not null,
idExames int not null,
idMed text not null,
dataConst date NOT NULL,

primary key(idConst),
KEY idPrest (idPrest),
KEY idPet (idPet),
KEY idExames (idExames),
foreign key(idPrest) references prestadores(idPrest),
foreign key(idFunc) references funcionario(idFunc),
foreign key(idExames) references exames(idExames),
foreign key(idPet) references pet(idPet)
)ENGINE=InnoDB  DEFAULT CHARSET=latin1;
LOCK TABLES consulta WRITE;
UNLOCK TABLES;







create table vacina (
idVacina int not null auto_increment,
idPet int,
idPrest int,
idFunc int,
dataApliVacina date not null,
dataProxVacina date,
nomeVacina text not null,
qntDoseVacina text not null,
loteVacina text not null,
valorVacina text,
statusVacina varchar(8) DEFAULT 'Pentende',
confirmaVacina int,
nomeVetVacina text,
emailVetVacina text,
crmvVetVacina text,
observacaoVacina text,

primary key(idVacina),
KEY idPet (idPet),
KEY idPrest (idPrest),
KEY idFunc (idFunc),
CONSTRAINT vacinaPet foreign key(idPet) references pet (idPet),
CONSTRAINT vacinaPrest foreign key(idPrest) references prestadores (idPrest),
CONSTRAINT vacinaFunc foreign key(idFunc) references funcionario(idFunc)
)ENGINE=InnoDB DEFAULT CHARSET=latin1;
LOCK TABLES vacina WRITE;
UNLOCK TABLES;




